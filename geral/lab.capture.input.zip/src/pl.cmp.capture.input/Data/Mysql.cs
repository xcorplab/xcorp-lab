﻿using System;
using System.Collections.Generic;
using System.Text;
using Amazon.Lambda.Core;
using Amazon.Runtime;
using MySql.Data.MySqlClient;
using pl.cmp.capture.input.Model;
using pl.cmp.capture.input.Util;

namespace pl.cmp.capture.input.Data
{
    public class Mysql
    {
        public FileInput ListFileInput(Int32 idFileInput,ILambdaContext context)
        {
            try
            {
                Utility utility = new Utility();

                Dictionary<String, String> dictConnection = utility.GetSecret("connection");
                Dictionary<String,String> dictKeys = utility.GetSecret("key");
                BasicAWSCredentials awsCreds = new BasicAWSCredentials(dictKeys["access-key"], dictKeys["secret-key"]);
                FileInput fileInput = new FileInput();
                using (MySqlConnection connection = new MySqlConnection(dictConnection["aurora-controlfile-connection"]))
                {
                    connection.Open();

                    MySqlCommand command = new MySqlCommand($"select idFileInput,hash,name,aggregateName,sourceServer,sourceFolder,password from FileInput where idFileInput={idFileInput} ", connection);

                    MySqlDataReader reader = command.ExecuteReader();


                    while (reader.Read())
                    {
                        fileInput = new FileInput
                        {
                            IdFileInput = reader.GetInt32(0),
                            Hash = reader.GetString(1),
                            Name = reader.GetString(2),
                            AggregateName = reader.GetString(3),
                            SourceServer = reader.GetString(4),
                            SourceFolder = reader.GetString(5),
                            Password = reader.IsDBNull(6) ? "" : reader.GetString(6)
                        };
                    }
                    reader.Close();
                }
                return fileInput;
            }
            catch (Exception ex)
            {
                context.Logger.LogLine(ex.Message + " " + ex.StackTrace);
                throw ex;
            }


        }
    }
}
