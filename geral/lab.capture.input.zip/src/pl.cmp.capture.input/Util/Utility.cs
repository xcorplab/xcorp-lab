﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using Amazon;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using Amazon.SQS;
using Newtonsoft.Json;
using pl.cmp.capture.input.Model;

namespace pl.cmp.capture.input.Util
{
    public class Utility
    {
        public Dictionary<String, String> GetSecret(String secretName)
        {
            MemoryStream memoryStream = new MemoryStream();
            AmazonSecretsManagerConfig config = new AmazonSecretsManagerConfig();
            config.ProxyHost = "proxy";
            config.ProxyPort = 80;
            config.ProxyCredentials = CredentialCache.DefaultNetworkCredentials;
            config.RegionEndpoint = RegionEndpoint.SAEast1;
            IAmazonSecretsManager client = new AmazonSecretsManagerClient(config);

            GetSecretValueRequest request = new GetSecretValueRequest
            {
                SecretId = secretName,
                VersionStage = "AWSCURRENT"
            };

            try
            {
                return JsonConvert.DeserializeObject<Dictionary<string, string>>(client.GetSecretValueAsync(request).Result.SecretString);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public FTPData ParseFTP(String sourceServer)
        {
            String[] parameters = sourceServer.Split(new string[] { "|&" }, StringSplitOptions.RemoveEmptyEntries);
            if (parameters[0]!="FTP")
            {
                throw new Exception("Failed to parse " + parameters[0]);
            }

            FTPData fTPData = new FTPData
            {
                User = parameters[3],
                Pass = parameters[4],
                Port = parameters[2],
                Server = parameters[1]
            };
            return fTPData;
        }
    }
}
