using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Amazon;
using Amazon.Lambda.Core;
using Amazon.Lambda.SQSEvents;
using Amazon.Runtime;
using Amazon.SQS;
using Amazon.SQS.Model;
using Amazon.StorageGateway;
using Amazon.StorageGateway.Model;
using Newtonsoft.Json;
using pl.cmp.capture.input.Data;
using pl.cmp.capture.input.Model;
using pl.cmp.capture.input.Util;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace pl.cmp.capture.input
{
    public class Function
    {
        /// <summary>
        /// Default constructor. This constructor is used by Lambda to construct the instance. When invoked in a Lambda environment
        /// the AWS credentials will come from the IAM role associated with the function and the AWS region will be set to the
        /// region the Lambda function is executed in.
        /// </summary>
        public Function()
        {

        }


        /// <summary>
        /// This method is called for every Lambda invocation. This method takes in an SQS event object and can be used 
        /// to respond to SQS messages.
        /// </summary>
        /// <param name="evnt"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(SQSEvent evnt, ILambdaContext context)
        {
            Dictionary<String, String> keys = new Utility().GetSecret("key");
            BasicAWSCredentials awsCreds = new BasicAWSCredentials(keys["access-key"], keys["secret-key"]);

            AmazonSQSConfig config = new AmazonSQSConfig();
            config.ProxyHost = "proxy";
            config.ProxyPort = 80;
            config.ProxyCredentials = CredentialCache.DefaultNetworkCredentials;
            config.RegionEndpoint = RegionEndpoint.SAEast1;
            Amazon.SQS.AmazonSQSClient amazonSQSClient = new Amazon.SQS.AmazonSQSClient(awsCreds, config);
            foreach (var message in evnt.Records)
            {
                await ProcessMessageAsync(message, context);
                var delRequest = new DeleteMessageRequest
                {
                    QueueUrl = new Utility().GetSecret("queue")["pl-inputfile-in"],
                    ReceiptHandle = message.ReceiptHandle
                };
                var ret = amazonSQSClient.DeleteMessageAsync(delRequest).Result;
            }
        }

        private async Task ProcessMessageAsync(SQSEvent.SQSMessage message, ILambdaContext context)
        {
            String hashJob = null;
            Utility utility = new Utility();
            JobView jobView = null;
            Dictionary<String, String> keys = utility.GetSecret("api-upload-key");
            Dictionary<String, String> urls = utility.GetSecret("api-urls");
            try
            {

                FileInput fileInput = new Mysql().ListFileInput(Convert.ToInt32(message.Body), context);
                if (fileInput == null)
                {
                    context.Logger.Log("Failed to list idInputFile: " + message.Body);
                    throw new Exception("Failed to list idInputFile: " + message.Body);
                }
                

                FTPData ftpData = utility.ParseFTP(fileInput.SourceServer);

                

                jobView = new JobView
                {
                    AggregateName = fileInput.AggregateName,
                    Application = fileInput.Hash
                };
                

                String credentials = Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(keys["clientid"] + ":" + keys["secretid"]));
                HttpClient httpClient = new HttpClient();
                HttpContent body = new StringContent("", Encoding.UTF8, "application/json");


                httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", credentials);
                HttpResponseMessage httpResponseMessage = await httpClient.PostAsync(urls["url-token"], body);

                if (!httpResponseMessage.IsSuccessStatusCode)
                {
                    context.Logger.Log("Failed token authentication");
                    throw new Exception("Failed token authentication");
                }

                Token token = JsonConvert.DeserializeObject<Token>(httpResponseMessage.Content.ReadAsStringAsync().Result);

                httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", "Bearer " + token.Access_token);
                httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                body = new StringContent("", Encoding.UTF8, "application/json");
                httpResponseMessage = await httpClient.PostAsync(urls["url-ezpay-create-job"], new StringContent(JsonConvert.SerializeObject(jobView), Encoding.UTF8, "application/json"));
                if (!httpResponseMessage.IsSuccessStatusCode)
                {
                    context.Logger.Log("Failed create job " + fileInput.AggregateName);
                    throw new Exception("Failed create job " + fileInput.AggregateName);
                }

                hashJob = JsonConvert.DeserializeObject<JobReturn>(httpResponseMessage.Content.ReadAsStringAsync().Result).Job;
                jobView.JobId = hashJob;
                FtpWebRequest ftpWebRequest = (FtpWebRequest)WebRequest.Create($"ftp://{ftpData.Server}{fileInput.SourceFolder}{fileInput.Name}");
                ftpWebRequest.Credentials = new NetworkCredential(ftpData.User, ftpData.Pass);
                ftpWebRequest.Method = WebRequestMethods.Ftp.GetFileSize;
                FtpWebResponse response = (FtpWebResponse)ftpWebRequest.GetResponse();

                ftpWebRequest = (FtpWebRequest)WebRequest.Create($"ftp://{ftpData.Server}{fileInput.SourceFolder}{fileInput.Name}");
                ftpWebRequest.Credentials = new NetworkCredential(ftpData.User, ftpData.Pass);
                ftpWebRequest.Method = WebRequestMethods.Ftp.DownloadFile;
                ftpWebRequest.Timeout = -1;
                ftpWebRequest.UseBinary = true;
                ftpWebRequest.UsePassive = true;
                

                MemoryStream ms = new MemoryStream();

                int bufferSize = 1031072;
                int maxSize = 5242881;
                int currentPart = 0;
                String uploadId = null;
                using (response = (FtpWebResponse)ftpWebRequest.GetResponse())
                {
                    using (var responseStream = response.GetResponseStream())
                    {
                        int sumBytes;
                        byte[] buffer = new byte[bufferSize];
                        sumBytes = responseStream.ReadAsync(buffer, 0, bufferSize).Result;
                        while (sumBytes > 0)
                        {
                            ms.Write(buffer,0, sumBytes);

                            if (ms.Length > maxSize)
                            {
                                ms.Flush();
                                ms.Seek(0, 0);

                                currentPart++;
                                HttpRequestMessage httpRequestMessageUp = new HttpRequestMessage(HttpMethod.Post, urls["url-ezpay-uploadpart-job"] + $"?currentPart={currentPart}&identifier={fileInput.Name}&uploadId={uploadId}&jobId={hashJob}&lastPart={Boolean.FalseString}")
                                {
                                    Content = new StreamContent(ms)
                                };

                                httpClient = new HttpClient();

                                httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", "Bearer " + token.Access_token);
                                httpResponseMessage = httpClient.SendAsync(httpRequestMessageUp).Result;
                                if (!httpResponseMessage.IsSuccessStatusCode)
                                {
                                    context.Logger.Log("Failed upload part " + fileInput.AggregateName);
                                    throw new Exception("Failed upload part " + fileInput.AggregateName);
                                }                                
                                uploadId = JsonConvert.DeserializeObject<ResultInputViewModel>(httpResponseMessage.Content.ReadAsStringAsync().Result).UploadId;
                                ms = new MemoryStream();
                            }

                            sumBytes = responseStream.ReadAsync(buffer, 0, bufferSize).Result;
                        }
                    }
                }
                ms.Flush();
                ms.Seek(0, 0);

                if (currentPart > 0)
                {

                    if (ms.Length > 0)
                    {
                        currentPart++;
                        HttpRequestMessage httpRequestMessageUp = new HttpRequestMessage(HttpMethod.Post, urls["url-ezpay-uploadpart-job"] + $"?currentPart={currentPart}&identifier={fileInput.Name}&uploadId={uploadId}&jobId={hashJob}&lastPart={Boolean.TrueString}")
                        {
                            Content = new StreamContent(ms)
                        };

                        httpClient = new HttpClient();

                        httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", "Bearer " + token.Access_token);
                        httpResponseMessage = httpClient.SendAsync(httpRequestMessageUp).Result;
                        if (!httpResponseMessage.IsSuccessStatusCode)
                        {
                            context.Logger.Log("Failed upload part " + fileInput.AggregateName);
                            throw new Exception("Failed upload part " + fileInput.AggregateName);
                        }
                        uploadId = JsonConvert.DeserializeObject<ResultInputViewModel>(httpResponseMessage.Content.ReadAsStringAsync().Result).UploadId;
                    }

                    httpClient = new HttpClient();
                    httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", "Bearer " + token.Access_token);
                    httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                    body = new StringContent("", Encoding.UTF8, "application/json");
                    CompleteJob completeJob = new CompleteJob()
                    {
                        UploadId = uploadId,
                        identifier = fileInput.Name,
                        jobId = hashJob,
                        secret = fileInput.Password
                    };
                    httpResponseMessage = await httpClient.PutAsync(urls["url-ezpay-complete-job"], new StringContent(JsonConvert.SerializeObject(completeJob), Encoding.UTF8, "application/json"));
                    if (!httpResponseMessage.IsSuccessStatusCode)
                    {
                        context.Logger.Log("Failed complete job " + fileInput.AggregateName);
                        throw new Exception("Failed complete job " + fileInput.AggregateName);
                    }
                }
                else
                {

                    HttpRequestMessage httpRequestMessageUp = new HttpRequestMessage(HttpMethod.Post, urls["url-ezpay-upload-job"] + $"?identifier={fileInput.Name}&jobId={hashJob}&secret={fileInput.Password}")
                    {
                        Content = new StreamContent(ms)
                    };

                    httpClient = new HttpClient();

                    httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", "Bearer " + token.Access_token);
                    httpResponseMessage = httpClient.SendAsync(httpRequestMessageUp).Result;
                    if (!httpResponseMessage.IsSuccessStatusCode)
                    {
                        context.Logger.Log("Failed upload part " + fileInput.AggregateName);
                        throw new Exception("Failed upload part " + fileInput.AggregateName);
                    }
                    uploadId = JsonConvert.DeserializeObject<ResultInputViewModel>(httpResponseMessage.Content.ReadAsStringAsync().Result).UploadId;
                }

                

                httpResponseMessage = await httpClient.PutAsync(urls["url-ezpay-start-job"], new StringContent(JsonConvert.SerializeObject(jobView), Encoding.UTF8, "application/json"));
                if (!httpResponseMessage.IsSuccessStatusCode)
                {
                    context.Logger.Log("Failed start job " + fileInput.AggregateName);
                }


                context.Logger.LogLine($"Processed message {message.Body}");

                await Task.CompletedTask;
            }
            catch(Exception ex)
            {
                if (hashJob!=null)
                {
                    HttpResponseMessage httpResponseMessage = await new HttpClient().PutAsync(urls["url-ezpay-cancel-job"], new StringContent(JsonConvert.SerializeObject(jobView), Encoding.UTF8, "application/json"));
                    if (!httpResponseMessage.IsSuccessStatusCode)
                    {
                        context.Logger.Log("Failed cancel job " + jobView.AggregateName);
                    }
                }

                throw ex;
            }
        }
    }
}
