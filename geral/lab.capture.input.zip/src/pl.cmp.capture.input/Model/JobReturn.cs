﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pl.cmp.capture.input.Model
{
    public class JobReturn
    {
        public String Job { get; set; }
    }
}
