﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pl.cmp.capture.input.Model
{
    public class JobView
    {
        public String JobId { get; set; }
        public String AggregateName { get; set; }
        public String Application { get; set; }
    }
}
