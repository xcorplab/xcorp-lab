﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pl.cmp.capture.input.Model
{
    public class ResultInputViewModel
    {
        public string UploadId { get; set; }
        public int CurrentPart { get; set; }
        public int TotalParts { get; set; }
        public string Identifier { get; set; }
    }
}
