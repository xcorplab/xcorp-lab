﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pl.cmp.capture.input.Model
{
    public class FTPData
    {
        public String Server { get; set; }
        public String Port { get; set; }
        public String User { get; set; }
        public String Pass { get; set; }
    }
}
