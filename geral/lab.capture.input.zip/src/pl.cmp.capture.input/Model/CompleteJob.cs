﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pl.cmp.capture.input.Model
{
    public class CompleteJob
    {
        public String UploadId { get; set; }
        public String identifier { get; set; }
        public String jobId { get; set; }
        public String secret { get; set; }
    }
}
