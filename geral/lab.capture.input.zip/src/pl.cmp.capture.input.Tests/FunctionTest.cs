using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Xunit;
using Amazon.Lambda.TestUtilities;
using Amazon.Lambda.SQSEvents;

using pl.cmp.capture.input;
using Amazon.Runtime;
using pl.cmp.capture.input.Util;
using Amazon.SQS.Model;
using Amazon.StorageGateway.Model;
using Amazon.StorageGateway;
using Amazon.SQS;
using Amazon;
using System.Net;

namespace pl.cmp.capture.input.Tests
{
    public class FunctionTest
    {
        [Fact]
        public async Task TestSQSEventLambdaFunction()
        {
            string queueUrl = new Utility().GetSecret("queue")["pl-inputfile-in"];
            Dictionary<String, String> keys = new Utility().GetSecret("key");
            BasicAWSCredentials awsCreds = new BasicAWSCredentials(keys["access-key"], keys["secret-key"]);

            AmazonSQSConfig config = new AmazonSQSConfig();
            config.ProxyHost = "proxy";
            config.ProxyPort = 80;
            config.ProxyCredentials = CredentialCache.DefaultNetworkCredentials;
            config.RegionEndpoint = RegionEndpoint.SAEast1;
            Amazon.SQS.AmazonSQSClient amazonSQSClient = new Amazon.SQS.AmazonSQSClient(awsCreds, config);

            var request = new ReceiveMessageRequest
            {
                AttributeNames = { "SentTimestamp" },
                MaxNumberOfMessages = 1,
                MessageAttributeNames = { "All" },
                QueueUrl = queueUrl,
                WaitTimeSeconds = 20
            };


            var response = amazonSQSClient.ReceiveMessageAsync(request).Result;



            var sqsEvent = new SQSEvent
            {
                Records = new List<SQSEvent.SQSMessage>()
            };
            foreach (Message message in response.Messages)
            {
                sqsEvent.Records.Add(new SQSEvent.SQSMessage
                {
                    Attributes = message.Attributes,
                    Body = message.Body,
                    MessageId = message.MessageId,
                    ReceiptHandle = message.ReceiptHandle
                });
            }

            var logger = new TestLambdaLogger();
            var context = new TestLambdaContext
            {
                Logger = logger
            };

            var function = new Function();
            await function.FunctionHandler(sqsEvent, context);
            Assert.True(true);

            var delRequest = new DeleteMessageRequest
            {
                QueueUrl = queueUrl,
                ReceiptHandle = sqsEvent.Records[0].ReceiptHandle
            };
            var ret = amazonSQSClient.DeleteMessageAsync(delRequest).Result;

        }
    }
}
