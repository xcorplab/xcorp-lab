﻿using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using EzPay.Commons.Repository;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace EzPay.Commons.Data
{
    public class StorageContext
    {
        public AmazonS3Client ConnectS3Storage(bool useProxy, RegionEndpoint regionEndpoint)
        {
            SecretRepository secretRepository = new SecretRepository();

            AWSCredentials credentials = new BasicAWSCredentials(secretRepository.GetSecret("acess-key")["key"], secretRepository.GetSecret("secret-key")["key"]);
            AmazonS3Config config = new AmazonS3Config();

            //if (useProxy)
            //{
            //    config.ProxyHost = "proxy";
            //    config.ProxyPort = 80;
            //    config.ProxyCredentials = CredentialCache.DefaultNetworkCredentials;
            //}

            config.RegionEndpoint = regionEndpoint;

            return new AmazonS3Client(credentials, config);
        }
    }
}
