﻿using Amazon;
using Amazon.Runtime;
using Amazon.SQS;
using Amazon.SQS.Model;
using EzPay.ApplicationCore.Interfaces.Repository;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace EzPay.Commons.Repository
{
    public class QueueRepository : IQueueRepository
    {

        private IAmazonSQS _amazonSQS = null;

        public QueueRepository()
        {
            SecretRepository secretRepository = new SecretRepository();

            AWSCredentials credentials = new BasicAWSCredentials(secretRepository.GetSecret("key")["access-key"], secretRepository.GetSecret("key")["secret-key"]);
            AmazonSQSConfig config = new AmazonSQSConfig();

#if DEBUG
            //config.ProxyHost = "proxy";
            //config.ProxyPort = 80;
            //config.ProxyCredentials = CredentialCache.DefaultNetworkCredentials;
#endif

            config.RegionEndpoint = RegionEndpoint.SAEast1;
            _amazonSQS = new AmazonSQSClient(credentials, config);
        }

        public async Task SendMessageAsync(string nameQueue, string messageBody)
        {
            SendMessageRequest sendMessageRequest = new SendMessageRequest
            {
                MessageBody = messageBody,
                QueueUrl = new SecretRepository().GetSecret("queue")[nameQueue]
            };

            var sendMessageResponse = await _amazonSQS.SendMessageAsync(sendMessageRequest);

            if (sendMessageResponse.HttpStatusCode != HttpStatusCode.OK)
            {
                throw new Exception("Erro na gravação na fila");
            }
        }
    }
}
