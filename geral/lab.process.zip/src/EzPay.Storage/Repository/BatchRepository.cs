﻿using Amazon;
using Amazon.Batch;
using Amazon.Batch.Model;
using Amazon.Runtime;
using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository.Common;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace EzPay.Commons.Repository
{
    public class BatchRepository : IBatchRepository
    {
        private IAmazonBatch _amazonBatch = null;

        public BatchRepository()
        {
            SecretRepository secretRepository = new SecretRepository();

            AWSCredentials credentials = new BasicAWSCredentials(secretRepository.GetSecret("key")["access-key"], secretRepository.GetSecret("key")["secret-key"]);
            AmazonBatchConfig config = new AmazonBatchConfig();

#if DEBUG
            //config.ProxyHost = "proxy";
            //config.ProxyPort = 80;
            //config.ProxyCredentials = CredentialCache.DefaultNetworkCredentials;
#endif

            config.RegionEndpoint = RegionEndpoint.SAEast1;
            _amazonBatch = new AmazonBatchClient(credentials, config);
        }

        public async Task<MessageStep> StartProcessAsync(MessageStep step, MessageProcess message)
        {
            ContainerOverrides containerOverrides = new ContainerOverrides();

            step.commands.ToList().ForEach(c =>
            {
                containerOverrides.Command.Add(c.value);
            });

            containerOverrides.Environment.Add(new Amazon.Batch.Model.KeyValuePair()
            {
                Name = "message",
                Value = JsonConvert.SerializeObject(message)
            });

            message.parameters.ToList().ForEach(p =>
            {
                containerOverrides.Environment.Add(new Amazon.Batch.Model.KeyValuePair()
                {
                    Name = p.name,
                    Value = p.value
                });
            });

            SubmitJobRequest submitJobRequest = new SubmitJobRequest()
            {
                JobQueue = step.jobQueue,
                JobName = string.Format("{0}-{1}", step.name, message.jobId),
                JobDefinition = step.jobDefinition,
                ContainerOverrides = containerOverrides
            };

            var response = await _amazonBatch.SubmitJobAsync(submitJobRequest);

            step.identificador = response.JobId;

            return step;
        }

        public async Task<bool> FindBatchAsync(string process)
        {
            bool batchExist = false;
            string nextToken = null;

            do
            {
                ListJobsRequest listJobs = new ListJobsRequest()
                {
                    ArrayJobId = process,
                    JobQueue = "queue-ezpay-process",
                    //JobStatus = JobStatus.FAILED,
                    //MaxResults = 100,
                    NextToken = nextToken
                };

                var response = await _amazonBatch.ListJobsAsync(listJobs);
                nextToken = response.NextToken;

                response.JobSummaryList.ForEach(j =>
                {
                    //if (j.JobName == jobName)
                    //    batchExist = true;
                });
            }
            while (nextToken != null);

            return batchExist;
        }

        public async Task TerminateProcessAsync(string identificador, string mensagem)
        {
            var response = await _amazonBatch.TerminateJobAsync(new TerminateJobRequest()
            {
                JobId = identificador,
                Reason = mensagem
            });
        }
    }
}
