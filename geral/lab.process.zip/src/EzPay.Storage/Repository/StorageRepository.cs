﻿using EzPay.ApplicationCore.Interfaces.Repository;
using System;
using System.Collections.Generic;
using Amazon.S3;
using System.Text;
using System.Threading.Tasks;
using Amazon.Runtime;
using System.IO;
using Amazon;
using EzPay.ApplicationCore.Entity;
using Amazon.S3.Transfer;
using System.Net;
using EzPay.Commons.Data;
using Amazon.StorageGateway;

using Amazon.S3.Model;

namespace EzPay.Commons.Repository
{
    public class StorageRepository : IStorageRepository
    {
        private static IAmazonS3 _storageClient;
        private static IAmazonStorageGateway _storageGatewayClient;

        public StorageRepository()
        {
            SecretRepository secretRepository = new SecretRepository();
            AWSCredentials credentials = new BasicAWSCredentials(secretRepository.GetSecret("key")["access-key"], secretRepository.GetSecret("key")["secret-key"]);

            AmazonS3Config config = new AmazonS3Config();
            config.RegionEndpoint = RegionEndpoint.SAEast1;

            AmazonStorageGatewayConfig configStorageGateway = new AmazonStorageGatewayConfig();
            configStorageGateway.RegionEndpoint = RegionEndpoint.SAEast1;

#if DEBUG
            //config.ProxyHost = "proxy";
            //config.ProxyPort = 80;
            //config.ProxyCredentials = CredentialCache.DefaultNetworkCredentials;
#endif

            _storageClient = new AmazonS3Client(credentials, config);
            _storageGatewayClient = new AmazonStorageGatewayClient(credentials, configStorageGateway);
        }

        public async Task<StorageFile> InitiateMultipartUploadAsync(StorageFile storageFile)
        {

            InitiateMultipartUploadRequest initiateRequest = new InitiateMultipartUploadRequest
            {
                BucketName = storageFile.path,
                Key = storageFile.identifier
            };

            InitiateMultipartUploadResponse result = await _storageClient.InitiateMultipartUploadAsync(initiateRequest);
            storageFile.uploadId = result.UploadId;

            return storageFile;
        }

        public async Task<StorageFile> UploadPartAsync(StorageFile storageFile)
        {
            UploadPartRequest uploadRequest = new UploadPartRequest
            {
                BucketName = storageFile.path,
                Key = storageFile.identifier,
                UploadId = storageFile.uploadId,
                PartNumber = storageFile.currentPart,
                InputStream = new MemoryStream(storageFile.partFile)
            };

            UploadPartResponse result = await _storageClient.UploadPartAsync(uploadRequest);

            storageFile.partId = result.HttpStatusCode == HttpStatusCode.OK ? result.ETag : null;

            return storageFile;
        }

        public async Task<bool> UploadAsync(StorageFile storageFile, int daysExpiration)
        {

            List<Tag> tags = new List<Tag>() {
                new Tag {
                    Key = "expiration",
                    Value = "30"
                }
            };

            PutObjectRequest putObjectRequest = new PutObjectRequest
            {
                BucketName = storageFile.path,
                Key = storageFile.identifier,
                InputStream = new MemoryStream(storageFile.partFile),
                TagSet = tags
            };

            PutObjectResponse putObjectResponse = await _storageClient.PutObjectAsync(putObjectRequest);

            return putObjectResponse.HttpStatusCode == HttpStatusCode.OK ? true : false;
        }

        public async Task<ListPartsResponse> ListPartsUploadAsync(StorageFile storageFile)
        {
            ListPartsRequest listPartRequest = new ListPartsRequest
            {
                BucketName = storageFile.path,
                Key = storageFile.identifier,
                UploadId = storageFile.uploadId
            };

            return await _storageClient.ListPartsAsync(listPartRequest);
        }

        public async Task<bool> CompleteMultipartUploadAsync(StorageFile storageFile, int daysExpiration)
        {
            ListPartsResponse listPartsResponse = await ListPartsUploadAsync(storageFile);

            List<PartETag> partETags = new List<PartETag>();
            foreach (var part in listPartsResponse.Parts)
            {
                partETags.Add(new PartETag()
                {
                    ETag = part.ETag,
                    PartNumber = part.PartNumber
                });
            }

            CompleteMultipartUploadRequest compRequest = new CompleteMultipartUploadRequest
            {
                BucketName = storageFile.path,
                Key = storageFile.identifier,
                UploadId = storageFile.uploadId,
                PartETags = partETags
            };
            CompleteMultipartUploadResponse result = await _storageClient.CompleteMultipartUploadAsync(compRequest);

            Tagging tagging = new Tagging();

            tagging.TagSet = new List<Tag>() {
                new Tag {
                    Key = "expiration",
                    Value = "30"
                }
            };

            return result.HttpStatusCode == HttpStatusCode.OK ? true : false;
        }

        public async Task<bool> AbortMultipartUploadAsync(StorageFile storageFile)
        {
            AbortMultipartUploadRequest abortMPURequest = new AbortMultipartUploadRequest
            {
                BucketName = storageFile.path,
                Key = storageFile.identifier,
                UploadId = storageFile.uploadId
            };

            AbortMultipartUploadResponse result = await _storageClient.AbortMultipartUploadAsync(abortMPURequest);

            return result.HttpStatusCode == HttpStatusCode.OK ? true : false;
        }

        public async Task<long> CountLenghtUploadAsync(StorageFile storageFile)
        {
            ListPartsResponse listPartsResponse = await ListPartsUploadAsync(storageFile);

            long lenght = 0;

            listPartsResponse.Parts.ForEach(p =>
            {
                lenght += p.Size;
            });

            return lenght;
        }

        public async Task<bool> CreateRepositoryAsync(string repositoryName)
        {
            PutBucketRequest putBucketRequest = new PutBucketRequest
            {
                BucketName = repositoryName,
                UseClientRegion = true
            };

            PutBucketResponse result = await _storageClient.PutBucketAsync(putBucketRequest);



            return result.HttpStatusCode == HttpStatusCode.OK ? true : false;
        }

        public async Task<bool> DeleteRepositoryAsync(string repositoryName)
        {
            DeleteBucketResponse result = await _storageClient.DeleteBucketAsync(repositoryName);

            return result.HttpStatusCode == HttpStatusCode.OK ? true : false;
        }

        public async Task<bool> ResfreshStorage(string repositoryName)
        {
            var result = await _storageGatewayClient.RefreshCacheAsync(new Amazon.StorageGateway.Model.RefreshCacheRequest
            {
                FileShareARN = new SecretRepository().GetSecret("arn")["storagegateway-ez-storage"],
                FolderList = new List<string> { repositoryName },
                Recursive = true
            });

            return result.HttpStatusCode == HttpStatusCode.OK ? true : false;
        }

        public string GeneratePreSignedURL(string bucket, string objectKey)
        {
            GetPreSignedUrlRequest request = new GetPreSignedUrlRequest
            {
                BucketName = bucket,
                Key = objectKey,
                Expires = DateTime.Now.AddMinutes(3000)
            };
            return _storageClient.GetPreSignedURL(request);
        }
    }
}
