﻿using Amazon;
using Amazon.S3;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using EzPay.ApplicationCore.Interfaces.Repository.Common;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;

namespace EzPay.Commons.Repository
{
    public class SecretRepository : ISecretRepository
    {
        public Dictionary<String, String> GetSecret(string secretName)
        {
            secretName = "ezpay-" + StageRepository.stage() + "-" + secretName;

            MemoryStream memoryStream = new MemoryStream();
            AmazonSecretsManagerConfig config = new AmazonSecretsManagerConfig();

            config.RegionEndpoint = RegionEndpoint.USEast1;

            IAmazonSecretsManager client = new AmazonSecretsManagerClient(config);

            GetSecretValueRequest request = new GetSecretValueRequest
            {
                SecretId = secretName,
                VersionStage = "AWSCURRENT"
            };

            //var a = JsonConvert.DeserializeObject<Dictionary<string, string>>(client.GetSecretValueAsync(request).Result.SecretString);
            return JsonConvert.DeserializeObject<Dictionary<string, string>>(client.GetSecretValueAsync(request).Result.SecretString);
        }
    }
}
