﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Commons.Repository
{
    public class StageRepository
    {
        public static string stage()
        {
            return "dev";
            //return "prd";
        }
    }
}
