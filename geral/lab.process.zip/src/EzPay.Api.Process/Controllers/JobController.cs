using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using EzPay.Api.Process.ViewModel;
using EzPay.ApplicationCore.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Net.Http.Headers;
using System.IO;
using EzPay.Commons.Repository;
using EzPay.ApplicationCore.Entity;
using Microsoft.Extensions.Configuration;
using Amazon.Lambda.Core;
using System.Text;
using Newtonsoft.Json;
using EzPay.IoC;
using EzPay.ApplicationCore.Interfaces.Services.Common;
using EzPay.ApplicationCore.Services;
using Microsoft.Extensions.DependencyInjection;

//[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace EzPay.Api.Process.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize()]
    public class JobController : ControllerBase
    {
        private IConfiguration _configuration = null;

        //public static IServiceProvider db = new InfrastructureContainerBuilder()
        //                                         .RegisterModule(new InfrastructureFactory())
        //                                         .Build();

        private readonly IJobService _jobService = null;
        private readonly IApplicationService _applicationService = null;
        private readonly IInputService _inputService = null;
        private readonly IHistoryJobService _historyJobService = null;
        private readonly IWorkFlowService _workFlowService = null;
        private readonly IStorageService _storageService = null;
        private readonly IQueueService _queueService = null;
        private readonly IBatchService _batchService = null;
        private readonly IProcessService _processService = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="jobService"></param>
        /// <param name="applicationService"></param>
        /// <param name="inputService"></param>
        /// <param name="historyJobService"></param>
        /// <param name="workFlowService"></param>
        /// <param name="storageService"></param>
        /// <param name="queueService"></param>
        /// <param name="batchService"></param>
        /// <param name="processService"></param>
        public JobController(IConfiguration configuration, 
            IJobService jobService, 
            IApplicationService applicationService, 
            IInputService inputService,
            IHistoryJobService historyJobService,
            IWorkFlowService workFlowService,
            IStorageService storageService,
            IQueueService queueService,
            IBatchService batchService,
            IProcessService processService)
        {
            _configuration = configuration;
            _jobService = jobService;
            _applicationService = applicationService;
            _inputService = inputService;
            _historyJobService = historyJobService;
            _workFlowService = workFlowService;
            _storageService = storageService;
            _queueService = queueService;
            _batchService = batchService;
            _processService = processService;
        }

        /// <summary>
        /// Retorna o status do processamento.
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetJob")]
        [AllowAnonymous]
        public IActionResult GetJob(string jobId)
        {
            try
            {
                Job job = _jobService.SelectByHash(jobId);

                string json = JsonConvert.SerializeObject(job, new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                    //PreserveReferencesHandling = PreserveReferencesHandling.Objects,
                    //Formatting = Formatting.Indented
                });

                return Ok(JsonConvert.DeserializeObject(json));
            }
            catch (Exception ex)
            {
                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = "N�o foi poss�vel recuperar o job.",
                    level = "error",
                    source = ex.Message,
                    jobId = _jobService.SelectByHash(jobId).jobId
                });

                return BadRequest(new MessageReturnViewModel()
                {
                    date = DateTime.Now,
                    message = string.Format("N�o foi poss�vel recuperar o job.")
                });
            }
        }

        /// <summary>
        /// Cria uma requisi��o de processamento.
        /// </summary>
        /// <param name="jobViewModel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CreateJobAsync")]
        //[AllowAnonymous]
        public async Task<IActionResult> CreateJobAsync([FromBody] JobViewModel jobViewModel)
        {
            string jobId = Guid.NewGuid().ToString();

            try
            {
                if (string.IsNullOrEmpty(jobViewModel.application.Trim()))
                    return BadRequest("Application n�o informado!");

                var identity = User.Identity as ClaimsIdentity;

                var resultApplication = _applicationService.SelectByHash(jobViewModel.application);

                if (resultApplication == null)
                    return BadRequest("Application n�o localizado!");

                _jobService.Insert(new Job()
                {
                    aggregateName = jobViewModel.aggregateName,
                    hash = jobId,
                    statusRow = 1,
                    created = DateTime.Now,
                    //updated = DateTime.Now,
                    expiration = DateTime.Now.AddDays(resultApplication.daysExpiration),
                    applicationId = resultApplication.applicationId,
                    statusId = 1
                });

                await _storageService.CreateRepositoryAsync(string.Format("{0}/{1}/{2}/{3}/input/",
                    _configuration.GetSection("StoragePath").Value,
                    resultApplication.client.hash,
                    resultApplication.hash,
                    jobId));

                //await _storageService.CreateRepositoryAsync(string.Format("{0}/{1}/{2}/{3}/output/",
                //   _configuration.GetSection("StoragePath").Value,
                //   resultApplication.client.hash,
                //   resultApplication.hash,
                //   jobId));

                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = "Job criado com sucesso",
                    level = "info",
                    source = "",
                    jobId = _jobService.SelectByHash(jobId).jobId
                });

                return Ok(new ResultJobViewModel()
                {
                    job = jobId,
                    execution = DateTime.Now
                });
            }
            catch (Exception ex)
            {
                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = "N�o foi poss�vel criar o job.",
                    level = "error",
                    source = ex.Message,
                    jobId = _jobService.SelectByHash(jobId).jobId
                });

                return BadRequest(new MessageReturnViewModel()
                {
                    date = DateTime.Now,
                    message = string.Format("N�o foi poss�vel criar o job.")
                });
            }
        }

        /// <summary>
        /// Efetua o upload de um arquivo em partes.
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="currentPart"></param>
        /// <param name="lastPart"></param>
        /// <param name="uploadId"></param>
        /// <param name="identifier"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UploadInputPartAsync")]
        //[AllowAnonymous]
        public async Task<IActionResult> UploadInputPartAsync(string jobId, int currentPart, bool lastPart, string uploadId, string identifier)
        {
            try
            {
                int maxSize = Convert.ToInt32(_configuration.GetSection("MaxSizeStream").Value) * 1024 * 1024;
                int minSize = Convert.ToInt32(_configuration.GetSection("MinSizeStream").Value) * 1024 * 1024;

                if (Request.ContentLength > maxSize)
                    return BadRequest(string.Format("Tamanho da parte maior que o permitido, favor enviar partes de at� {0} MB / {1} Bytes", _configuration.GetSection("MaxSizeStream").Value, maxSize));

                if (Request.ContentLength < minSize && !lastPart)
                    return BadRequest(string.Format("Tamanho da parte menor que o permitido, favor enviar partes maiores que {0} MB / {1} Bytes", _configuration.GetSection("MinSizeStream").Value, minSize));

                if (string.IsNullOrEmpty(jobId))
                    return BadRequest("JobId n�o informado.");

                Job job = _jobService.SelectByHash(jobId);

                if (job == null)
                    return BadRequest("JobId inv�lido.");

                var memoryStream = new MemoryStream();
                Request.Body.CopyTo(memoryStream);
                var bytes = memoryStream.ToArray();

                StorageFile storageFile = new StorageFile()
                {
                    currentPart = currentPart,
                    identifier = identifier,
                    partFile = bytes,
                    path = string.Format("{0}/{1}/{2}/{3}/input",
                        _configuration.GetSection("StoragePath").Value,
                        job.application.client.hash,
                        job.application.hash,
                        jobId)
                };

                storageFile.uploadId = uploadId;

                var uploadResult = await _storageService.UploadPartAsync(storageFile);

                if (string.IsNullOrEmpty(uploadResult.partId))
                {
                    _historyJobService.Insert(new HistoryJob()
                    {
                        created = DateTime.Now,
                        info = string.Format("Falha ao enviar a parte {0}!", storageFile.currentPart),
                        jobId = job.jobId,
                        level = "error",
                        source = ""
                    });

                    return BadRequest(string.Format("Falha ao efetuar o upload da part {0}.", storageFile.currentPart));
                }

                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = string.Format("A parte {0} do arquivo {1}, com o tamanho de {2} foi enviada com sucesso!", storageFile.currentPart, storageFile.identifier, Request.ContentLength),
                    jobId = job.jobId,
                    level = "info",
                    source = ""
                });

                return Ok(new ResultInputViewModel()
                {
                    currentPart = storageFile.currentPart,
                    identifier = storageFile.identifier,
                    totalParts = storageFile.totalParts,
                    uploadId = storageFile.uploadId
                });
            }
            catch (Exception ex)
            {
                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = string.Format("N�o foi poss�vel efetuar o upload - parte {0}.", currentPart),
                    level = "error",
                    source = ex.Message,
                    jobId = _jobService.SelectByHash(jobId).jobId
                });

                return BadRequest(new MessageReturnViewModel()
                {
                    date = DateTime.Now,
                    message = string.Format("N�o foi poss�vel efetuar o upload - parte {0}.", currentPart)
                });
            }
        }

        /// <summary>
        /// Efetua o upload completo do arquivo.
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="identifier"></param>
        /// <param name="secret"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UploadInputAsync")]
        //[AllowAnonymous]
        public async Task<IActionResult> UploadInputAsync(string jobId, string identifier, string secret)
        {
            try
            {
                int maxSize = Convert.ToInt32(_configuration.GetSection("MaxSizeStream").Value) * 1024 * 1024;

                if (Request.ContentLength > maxSize)
                    return BadRequest(string.Format("Tamanho da parte maior que o permitido, favor enviar partes de at� {0} MB / {1} Bytes", _configuration.GetSection("MaxSizeStream").Value, maxSize));

                if (string.IsNullOrEmpty(jobId))
                    return BadRequest("JobId n�o informado.");

                Job job = _jobService.SelectByHash(jobId);

                if (job == null)
                    return BadRequest("JobId inv�lido.");

                var memoryStream = new MemoryStream();
                Request.Body.CopyTo(memoryStream);
                var bytes = memoryStream.ToArray();

                StorageFile storageFile = new StorageFile()
                {
                    currentPart = 0,
                    identifier = identifier,
                    partFile = bytes,
                    path = string.Format("{0}/{1}/{2}/{3}/input",
                        _configuration.GetSection("StoragePath").Value,
                        job.application.client.hash,
                        job.application.hash,
                        jobId)
                };

                bool result = await _storageService.UploadAsync(storageFile, job.application.daysExpiration);

                string inputId = Guid.NewGuid().ToString();

                if (result)
                {
                    //await _storageService.ResfreshStorage(string.Format("/{0}/{1}",
                    //    job.application.client.hash,
                    //    job.application.hash));

                    _inputService.Insert(new Input()
                    {
                        created = DateTime.Now,
                        hash = inputId,
                        jobId = job.jobId,
                        name = identifier,
                        secret = secret,
                        size = bytes.Length,
                        statusRow = 1
                    });

                    _historyJobService.Insert(new HistoryJob()
                    {
                        created = DateTime.Now,
                        info = "Arquivo enviado com sucesso.",
                        level = "info",
                        source = "",
                        jobId = _jobService.SelectByHash(jobId).jobId
                    });

                    return Ok(new ResultInputViewModel()
                    {
                        identifier = storageFile.identifier,
                        uploadId = storageFile.uploadId
                    });
                }
                else
                {
                    _historyJobService.Insert(new HistoryJob()
                    {
                        created = DateTime.Now,
                        info = "Erro ao efetuar o upload do arquivo.",
                        level = "erro",
                        source = "",
                        jobId = _jobService.SelectByHash(jobId).jobId
                    });

                    return BadRequest("falha ao efetuar o upload do arquivo");
                }
            }
            catch (Exception ex)
            {
                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = "N�o foi poss�vel efetuar o upload do arquivo.",
                    level = "error",
                    source = ex.Message,
                    jobId = _jobService.SelectByHash(jobId).jobId
                });

                return BadRequest(new MessageReturnViewModel()
                {
                    date = DateTime.Now,
                    message = string.Format("N�o foi poss�vel efetuar o upload do arquivo.")
                });
            }
        }

        /// <summary>
        /// Completa o upload em partes.
        /// </summary>
        /// <param name="completeInput"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("CompleteInputAsync")]
        //[AllowAnonymous]
        public async Task<IActionResult> CompleteInputAsync([FromBody] CompleteInputViewModel completeInput)
        {
            try
            {
                if (string.IsNullOrEmpty(completeInput.jobId))
                    return BadRequest("JobId n�o informado.");

                Job job = _jobService.SelectByHash(completeInput.jobId);

                if (job == null)
                    return BadRequest("JobId inv�lido.");

                StorageFile storageFile = new StorageFile()
                {
                    uploadId = completeInput.uploadId,
                    identifier = completeInput.identifier,
                    path = string.Format("{0}/{1}/{2}/{3}/input",
                        _configuration.GetSection("StoragePath").Value,
                        job.application.client.hash,
                        job.application.hash,
                        job.hash)
                };

                long totalUpload = await _storageService.CountLenghtUploadAsync(storageFile);

                try
                {
                    var uploadComplete = await _storageService.CompleteMultipartUploadAsync(storageFile, job.application.daysExpiration);

                    if (!uploadComplete)
                        return BadRequest("Falha ao completar o upload!");
                }
                catch (Exception ex)
                {
                    //var abortUpload = await _storageService.AbortMultipartUploadAsync(storageFile);
                    return BadRequest(ex.Message);
                }

                try
                {
                    List<Input> inputs = new List<Input>();
                    List<HistoryJob> historyJobs = new List<HistoryJob>();

                    string inputId = Guid.NewGuid().ToString();

                    //await _storageService.ResfreshStorage(string.Format("/{0}/{1}",
                    //  job.application.client.hash,
                    //  job.application.hash));

                    _inputService.Insert(new Input()
                    {
                        hash = inputId,
                        created = DateTime.Now,
                        jobId = job.jobId,
                        name = storageFile.identifier,
                        size = totalUpload,
                        secret = completeInput.secret,
                        statusRow = 1
                    });

                    _historyJobService.Insert(new HistoryJob()
                    {
                        created = DateTime.Now,
                        info = string.Format("O arquivo {0}, foi enviado com sucesso.", storageFile.identifier),
                        jobId = job.jobId,
                        level = "info",
                        source = ""
                    });
                }
                catch (Exception ex)
                {
                    return BadRequest("Falha ao inserir controles!");
                }

                return Ok();
            }
            catch (Exception ex)
            {
                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = "N�o foi poss�vel finalizar o upload do arquivo.",
                    level = "error",
                    source = ex.Message,
                    jobId = _jobService.SelectByHash(completeInput.jobId).jobId
                });

                return BadRequest(new MessageReturnViewModel()
                {
                    date = DateTime.Now,
                    message = string.Format("N�o foi poss�vel finalizar o upload do arquivo.")
                });
            }
        }

        /// <summary>
        /// Inicia o processamento do job.
        /// </summary>
        /// <param name="jobViewModel"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("StartJobAsync")]
        [AllowAnonymous]
        public async Task<IActionResult> StartJobAsync([FromBody] JobViewModel jobViewModel)
        {
            try
            {
                if (string.IsNullOrEmpty(jobViewModel.jobId))
                    return BadRequest("JobId n�o informado.");

                Job job = _jobService.SelectByHash(jobViewModel.jobId);

                if (job == null)
                    return BadRequest("JobId inv�lido.");

                if (job.statusId != 1)
                    return BadRequest("JobId em processamento.");

                WorkFlow workFlow = _workFlowService.findById(job.application.workFlow.workFlowId);

                if (workFlow == null)
                    return BadRequest("workFlow n�o cadastrado.");

                List<MessageParameter> parameters = new List<MessageParameter>();
                List<MessageStep> steps = new List<MessageStep>();

                workFlow.parameters.ToList().ForEach(p =>
                {
                    parameters.Add(new MessageParameter()
                    {
                        name = p.name,
                        value = p.value
                    });
                });

                workFlow.workFlowSteps.OrderBy(o => o.order).ToList().ForEach(w =>
                {
                    List<MessageCommand> commands = new List<MessageCommand>();
                    w.step.commands.OrderBy(o => o.commandId).ToList().ForEach(c =>
                    {
                        commands.Add(new MessageCommand()
                        {
                            value = c.value
                        });
                    });

                    steps.Add(new MessageStep()
                    {
                        status = 1,
                        start = DateTime.MinValue,
                        end = DateTime.MinValue,
                        jobDefinition = w.step.jobDefinition,
                        jobName = w.step.jobName,
                        jobQueue = w.step.jobQueue,
                        name = w.step.name,
                        order = w.order,
                        stepId = w.stepId,
                        commands = commands
                    });
                });

                List<MessageInput> inputs = new List<MessageInput>();

                job.inputs.ToList().ForEach(i =>
                {
                    inputs.Add(new MessageInput()
                    {
                        name = i.name,
                        secret = i.secret
                    });
                });

                MessageProcess message = new MessageProcess()
                {
                    jobId = job.hash,
                    basePath = string.Format("/{0}/{1}/{2}/{3}",
                        _configuration.GetSection("StoragePath").Value,
                        job.application.client.hash,
                        job.application.hash,
                        job.hash),
                    start = DateTime.MinValue,
                    end = DateTime.MinValue,
                    parameters = parameters,
                    steps = steps.OrderBy(o => o.order),
                    inputs = inputs
                };

                //await _storageService.ResfreshStorage(string.Format("/{0}/{1}",
                //       job.application.client.hash,
                //       job.application.hash));

                await _queueService.SendMessageAsync(string.Format("ezpay-{0}-in", steps.Where(w => w.order == 1).FirstOrDefault().name), JsonConvert.SerializeObject(message));

                job.statusId = 2;
                job.startDate = DateTime.Now;
                job.updated = DateTime.Now;
                _jobService.Update(job);

               

                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = string.Format("Job enviado para processamento."),
                    jobId = job.jobId,
                    level = "info",
                    source = ""
                });

                return Ok();
            }
            catch (Exception ex)
            {
                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = "N�o foi poss�vel iniciar o processamento do job.",
                    level = "error",
                    source = ex.Message,
                    jobId = _jobService.SelectByHash(jobViewModel.jobId).jobId
                });

                return BadRequest(new MessageReturnViewModel()
                {
                    date = DateTime.Now,
                    message = string.Format("N�o foi poss�vel iniciar o processamento do job.")
                });
            }
        }

        /// <summary>
        /// Reinicia o processamento do job.
        /// </summary>
        /// <param name="jobViewModel"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("ResumeJobAsync")]
        [AllowAnonymous]
        public async Task<IActionResult> ResumeJobAsync([FromBody] JobViewModel jobViewModel)
        {
            try
            {
                if (string.IsNullOrEmpty(jobViewModel.jobId))
                    return BadRequest("JobId n�o informado.");

                Job job = _jobService.SelectByHash(jobViewModel.jobId);

                if (job == null)
                    return BadRequest("JobId inv�lido.");

                if (job.statusId != 5 && job.statusId != 4)
                    return BadRequest("Processamento n�o abortado.");

                WorkFlow workFlow = _workFlowService.findById(job.application.workFlow.workFlowId);

                if (workFlow == null)
                    return BadRequest("workFlow n�o cadastrado.");

                List<MessageParameter> parameters = new List<MessageParameter>();
                List<MessageStep> steps = new List<MessageStep>();

                workFlow.parameters.ToList().ForEach(p =>
                {
                    parameters.Add(new MessageParameter()
                    {
                        name = p.name,
                        value = p.value
                    });
                });

                workFlow.workFlowSteps.OrderBy(o => o.order).ToList().ForEach(w =>
                {
                    List<MessageCommand> commands = new List<MessageCommand>();
                    w.step.commands.OrderBy(o => o.commandId).ToList().ForEach(c =>
                    {
                        commands.Add(new MessageCommand()
                        {
                            value = c.value
                        });
                    });

                    int lastStep = job.processes.OrderBy(o => o.created).LastOrDefault().stepId;

                    steps.Add(new MessageStep()
                    {
                        status = w.stepId < lastStep ? 3 : 1,
                        start = DateTime.MinValue,
                        end = DateTime.MinValue,
                        jobDefinition = w.step.jobDefinition,
                        jobName = w.step.jobName,
                        jobQueue = w.step.jobQueue,
                        name = w.step.name,
                        order = w.order,
                        stepId = w.stepId,
                        commands = commands
                    });
                });

                List<MessageInput> inputs = new List<MessageInput>();

                job.inputs.ToList().ForEach(i =>
                {
                    inputs.Add(new MessageInput()
                    {
                        name = i.name,
                        secret = i.secret
                    });
                });

                MessageProcess message = new MessageProcess()
                {
                    jobId = job.hash,
                    basePath = string.Format("/{0}/{1}/{2}/{3}",
                        _configuration.GetSection("StoragePath").Value,
                        job.application.client.hash,
                        job.application.hash,
                        job.hash),
                    start = DateTime.MinValue,
                    end = DateTime.MinValue,
                    parameters = parameters,
                    steps = steps.OrderBy(o => o.order),
                    inputs = inputs
                };

                await _queueService.SendMessageAsync(string.Format("ezpay-{0}-in", steps.Where(w => w.order == 1).FirstOrDefault().name), JsonConvert.SerializeObject(message));

                job.statusId = 2;
                job.startDate = DateTime.Now;
                job.updated = DateTime.Now;
                job.endDate = null;
                _jobService.Update(job);

                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = string.Format("Job enviado para processamento."),
                    jobId = job.jobId,
                    level = "info",
                    source = ""
                });

                return Ok();
            }
            catch (Exception ex)
            {
                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = "N�o foi poss�vel reiniciar o processamento do job.",
                    level = "error",
                    source = ex.Message,
                    jobId = _jobService.SelectByHash(jobViewModel.jobId).jobId
                });

                return BadRequest(new MessageReturnViewModel()
                {
                    date = DateTime.Now,
                    message = string.Format("N�o foi poss�vel reiniciar o processamento do job.")
                });
            }
        }

        /// <summary>
        /// Aborta o processamento do job informado.
        /// </summary>
        /// <param name="jobViewModel"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("AbortProcessJobAsync")]
        [AllowAnonymous]
        public async Task<IActionResult> AbortProcessJobAsync([FromBody] JobViewModel jobViewModel)
        {
            try
            {
                if (string.IsNullOrEmpty(jobViewModel.jobId))
                    return BadRequest("JobId n�o informado.");

                Job job = _jobService.SelectByHash(jobViewModel.jobId);

                if (job == null)
                    return BadRequest("JobId inv�lido.");

                await _batchService.TerminateProcessAsync(
                    job.processes.OrderBy(o => o.created).LastOrDefault().identifier,
                    string.Format("Abort batch {0}, job {1}",
                    job.processes.OrderBy(o => o.created).LastOrDefault().identifier,
                    job.hash));

                job.statusId = 5;
                job.updated = DateTime.Now;
                _jobService.Update(job);

                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = string.Format("Job abortado."),
                    jobId = job.jobId,
                    level = "info",
                    source = ""
                });

                return Ok();
            }
            catch (Exception ex)
            {
                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = "N�o foi poss�vel abortar o processamento do job.",
                    level = "error",
                    source = ex.Message,
                    jobId = _jobService.SelectByHash(jobViewModel.jobId).jobId
                });

                return BadRequest(new MessageReturnViewModel()
                {
                    date = DateTime.Now,
                    message = string.Format("N�o foi poss�vel abortar o processamento do job.")
                });
            }
        }

        /// <summary>
        /// Exclui o processamento da fila.
        /// </summary>
        /// <param name="jobViewModel"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("CancelProcessJobAsync")]
        [AllowAnonymous]
        public async Task<IActionResult> CancelProcessJobAsync([FromBody] JobViewModel jobViewModel)
        {
            try
            {
                if (string.IsNullOrEmpty(jobViewModel.jobId))
                    return BadRequest("JobId n�o informado.");

                Job job = _jobService.SelectByHash(jobViewModel.jobId);

                if (job == null)
                    return BadRequest("JobId inv�lido.");

                if (job.processes.Count() > 0)
                    await _batchService.TerminateProcessAsync(
                          job.processes.OrderBy(o => o.created).LastOrDefault().identifier,
                          string.Format("Abort batch {0}, job {1}",
                          job.processes.OrderBy(o => o.created).LastOrDefault().identifier,
                          job.hash));
               
                await _storageService.DeleteRepositoryAsync(string.Format("{0}/{1}/{2}/{3}/",
                    _configuration.GetSection("StoragePath").Value,
                        job.application.client.hash,
                        job.application.hash,
                        job.hash));

                //_processService.DeleteMany(job.processes);

                job.statusId = 6;
                job.updated = DateTime.Now;
                _jobService.Update(job);

                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = string.Format("Job cancelado."),
                    jobId = job.jobId,
                    level = "info",
                    source = ""
                });

                return Ok();
            }
            catch (Exception ex)
            {
                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = "N�o foi poss�vel cancelar o processamento do job.",
                    level = "error",
                    source = ex.Message,
                    jobId = _jobService.SelectByHash(jobViewModel.jobId).jobId
                });

                return BadRequest(new MessageReturnViewModel()
                {
                    date = DateTime.Now,
                    message = string.Format("N�o foi poss�vel cancelar o processamento do job.")
                });
            }
        }
    }
}
