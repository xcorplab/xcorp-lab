﻿using System;

namespace EzPay.Api.Process.ViewModel
{
    public class ResultInputViewModel
    {
        public string uploadId { get; set; }
        public int currentPart { get; set; }
        public int totalParts { get; set; }
        public string identifier { get; set; }
    }
}
