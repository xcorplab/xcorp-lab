﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EzPay.Api.Process.ViewModel
{
    public class JobViewModel
    {
        public string jobId { get; set; }
        public string aggregateName { get; set; }
        public string application { get; set; }
    }
}
