﻿using System;

namespace EzPay.Api.Process.ViewModel
{
    public class ResultJobViewModel
    {
        //public string identifier { get; set; }
        public string job { get; set; }
        public DateTime execution { get; set; }
    }
}
