﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EzPay.Api.Process.ViewModel
{
    public class CompleteInputViewModel
    {
        public string uploadId { get; set; }
        public string identifier { get; set; }  
        public string jobId { get; set; }
        public string secret { get; set; }
    }
}
