docker build -t  057616853458.dkr.ecr.sa-east-1.amazonaws.com/ezpay-process-api:latest .
Invoke-Expression -Command (aws ecr get-login --no-include-email)
docker push 057616853458.dkr.ecr.sa-east-1.amazonaws.com/ezpay-process-api:latest
pause