using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Amazon.Lambda.Core;
using Amazon.Lambda.SQSEvents;
using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Services;
using EzPay.ApplicationCore.Interfaces.Services.Common;
using EzPay.ApplicationCore.Services;
using EzPay.IoC;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;


// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace EzPay.Lambda.Orchestrator.In
{
    public class Function
    {
        public static IServiceProvider infrastructure = new InfrastructureContainerBuilder()
                                                      .RegisterModule(new InfrastructureFactory())
                                                      .Build();

        public static IServiceProvider common = new CommonContainerBuilder()
                                         .RegisterModule(new CommonFactory())
                                         .Build();

        private readonly IJobService _jobService = null;
        private readonly IHistoryJobService _historyJobService = null;
        private readonly IQueueService _queueService = null;
        private readonly IBatchService _batchService = null;
        private readonly IProcessService _processService = null;
        private readonly IStorageService _storageService = null;

        /// <summary>
        /// Default constructor. This constructor is used by Lambda to construct the instance. When invoked in a Lambda environment
        /// the AWS credentials will come from the IAM role associated with the function and the AWS region will be set to the
        /// region the Lambda function is executed in.
        /// </summary>
        public Function()
        {
            _jobService = infrastructure.GetService<IJobService>();
            _historyJobService = infrastructure.GetService<IHistoryJobService>();
            _processService = infrastructure.GetService<IProcessService>();
            _queueService = common.GetService<IQueueService>();
            _batchService = common.GetService<IBatchService>();
            _storageService = common.GetService<IStorageService>();
        }

        /// <summary>
        /// This method is called for every Lambda invocation. This method takes in an SQS event object and can be used 
        /// to respond to SQS messages.
        /// </summary>
        /// <param name="evnt"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(SQSEvent evnt, ILambdaContext context)
        {
            foreach (var message in evnt.Records)
            {
                await ProcessMessageAsync(message, context);
            }
        }

        private async Task ProcessMessageAsync(SQSEvent.SQSMessage message, ILambdaContext context)
        {
            MessageProcess messageQueue = JsonConvert.DeserializeObject<MessageProcess>(message.Body);

            try
            {
                if (messageQueue.start == DateTime.MinValue)
                    messageQueue.start = DateTime.Now;

                Job job = _jobService.SelectByHash(messageQueue.jobId);

                MessageStep step = new MessageStep();
                step = messageQueue.steps.OrderBy(o => o.order).Where(w => w.status == 1).ToList().FirstOrDefault();

                //bool findBatch = await _batchService.FindBatchAsync(job.processes.OrderBy(o => o.processId).LastOrDefault().identifier);

                //if (!findBatch)
                //{
                MessageStep stepResponse = await _batchService.StartProcessAsync(messageQueue);

                _processService.Insert(new Process()
                {
                    created = DateTime.Now,
                    identifier = stepResponse.identificador,
                    jobId = job.jobId,
                    stepId = stepResponse.stepId
                });

                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = string.Format("Etapa {0} iniciado.", step.jobName),
                    jobId = job.jobId,
                    level = "info",
                    source = ""
                });

                //MOCK TESTES
                //messageQueue.steps.OrderBy(o => o.order).Where(w => w.status == 1).ToList().FirstOrDefault().start = DateTime.Now;
                //messageQueue.steps.OrderBy(o => o.order).Where(w => w.status == 1).ToList().FirstOrDefault().end = DateTime.Now.AddMinutes(1);
                //string queue = string.Format("ezpay-{0}-out", messageQueue.steps.OrderBy(o => o.order).Where(w => w.status == 1).ToList().FirstOrDefault().name);
                //messageQueue.steps.OrderBy(o => o.order).Where(w => w.status == 1).ToList().FirstOrDefault().status = 3;
                //await _factoryCommon.queueService.SendMessageAsync(queue, JsonConvert.SerializeObject(messageQueue));
                //MOCK TESTES
                //}
            }
            catch (Exception ex)
            {
                Job job = _jobService.SelectByHash(messageQueue.jobId);

                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = string.Format("Falha no processamento do batch {0} In.", messageQueue.steps.OrderBy(o => o.order).Where(w => w.status == 1).ToList().FirstOrDefault().name),
                    jobId = job.jobId,
                    level = "info",
                    source = ex.StackTrace
                });

                string queue = string.Format("ezpay-{0}-fail", messageQueue.steps.OrderBy(o => o.order).Where(w => w.status == 1).ToList().FirstOrDefault().name);
                await _queueService.SendMessageAsync(queue, message.Body);
            }

            await Task.CompletedTask;
        }
    }
}
