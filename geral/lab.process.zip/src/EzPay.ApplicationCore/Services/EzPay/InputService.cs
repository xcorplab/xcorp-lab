﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.ApplicationCore.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Services
{
    public class InputService : IInputService
    {
        private readonly IInputRepository _inputRepository;

        public InputService(IInputRepository inputRepository)
        {
            _inputRepository = inputRepository;
        }

        public void Cancel(string hash)
        {
            _inputRepository.Cancel(hash);
        }

        public IEnumerable<Input> Find(Expression<Func<Input, bool>> expression)
        {
            return _inputRepository.find(expression);
        }

        public Input Insert(Input entity)
        {
            //Regra de negocio
            return _inputRepository.Insert(entity);
        }

        public IEnumerable<Input> InsertMany(IEnumerable<Input> entity)
        {
            //Regra de negocio
            return _inputRepository.InsertMany(entity);
        }

        public IEnumerable<Input> SelectAll()
        {
            return _inputRepository.SelectAll();
        }

        public void Update(Input entity)
        {
            _inputRepository.Update(entity);
        }

    }
}
