﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.ApplicationCore.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Services
{
    public class ProcessService : IProcessService
    {
        private readonly IProcessRepository _processRepository;

        public ProcessService(IProcessRepository processRepository)
        {
            _processRepository = processRepository;
        }

        public void DeleteMany(IEnumerable<Process> entities)
        {
            _processRepository.DeleteMany(entities);
        }

        public Process Insert(Process entity)
        {
            return _processRepository.Insert(entity);
        }

        public Process SelectByIdentificador(string identificador)
        {
            return _processRepository.SelectByIdentificador(identificador);
        }
    }
}
