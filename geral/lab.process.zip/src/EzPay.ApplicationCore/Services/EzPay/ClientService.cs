﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.ApplicationCore.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Services
{
    public class ClientService : IClientService
    {
        private readonly IClientRepository _clientRepository;

        public ClientService(IClientRepository clientRepository)
        {
            _clientRepository = clientRepository;
        }

        public IEnumerable<Client> Find(Expression<Func<Client, bool>> expression)
        {
            return _clientRepository.find(expression);
        }

        public Client Insert(Client entity)
        {
            //Regra de negocio
            return _clientRepository.Insert(entity);
        }

        public IEnumerable<Client> SelectAll()
        {
            return _clientRepository.SelectAll();
        }

        public Client SelectByHash(string hash)
        {
           return _clientRepository.SelectByHash(hash);
        }

        public void Update(Client entity)
        {
            _clientRepository.Update(entity);
        }
    }
}
