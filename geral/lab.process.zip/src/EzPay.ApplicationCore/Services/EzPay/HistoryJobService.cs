﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.ApplicationCore.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Services
{
    public class HistoryJobService : IHistoryJobService
    {
        private readonly IHistoryJobRepository _historyJobRepository;

        public HistoryJobService(IHistoryJobRepository historyJobRepository)
        {
            _historyJobRepository = historyJobRepository;
        }

        public IEnumerable<HistoryJob> Find(Expression<Func<HistoryJob, bool>> expression)
        {
            return _historyJobRepository.find(expression);
        }

        public HistoryJob Insert(HistoryJob entity)
        {
            //Regra de negocio
            return _historyJobRepository.Insert(entity);
        }

        public IEnumerable<HistoryJob> InsertMany(IEnumerable<HistoryJob> entity)
        {
            //Regra de negocio
            return _historyJobRepository.InsertMany(entity);
        }

        public IEnumerable<HistoryJob> SelectAll()
        {
            return _historyJobRepository.SelectAll();
        }

        public void Update(HistoryJob entity)
        {
            _historyJobRepository.Update(entity);
        }
    }
}
