﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.ApplicationCore.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Services
{
    public class WorkFlowService : IWorkFlowService
    {
        private readonly IWorkFlowRepository _workFlowRepository;

        public WorkFlowService(IWorkFlowRepository workFlowRepository)
        {
            _workFlowRepository = workFlowRepository;
        }

        public WorkFlow findById(int workFlowId)
        {
            return _workFlowRepository.findById(workFlowId);
        }
    }
}
