﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.ApplicationCore.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Services
{
    public class ApplicationService : IApplicationService
    {
        private readonly IApplicationRepository _applicationRepository;

        public ApplicationService(IApplicationRepository applicationRepository)
        {
            _applicationRepository = applicationRepository;
        }

        public IEnumerable<Application> Find(Expression<Func<Application, bool>> expression)
        {
            return _applicationRepository.find(expression);
        }

        public Application Insert(Application entity)
        {
            //Regra de negocio
            return _applicationRepository.Insert(entity);
        }

        public IEnumerable<Application> SelectAll()
        {
            return _applicationRepository.SelectAll();
        }

        public Application SelectByHash(string hash)
        {
           return _applicationRepository.SelectByHash(hash);
        }

        public void Update(Application entity)
        {
            _applicationRepository.Update(entity);
        }
    }
}
