﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Entity.EzPay;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.ApplicationCore.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Services
{
    public class DocumentService : IDocumentService
    {
        private readonly IDocumentRepository _documentRepository;

        public DocumentService(IDocumentRepository documentRepository)
        {
            _documentRepository = documentRepository;
        }

        public IEnumerable<Document> Find(Expression<Func<Document, bool>> expression)
        {
            return _documentRepository.find(expression);
        }

        public Document Insert(Document entity)
        {
            return _documentRepository.Insert(entity);
        }

        public void InsertMany(IEnumerable<Document> entities)
        {
            _documentRepository.InsertMany(entities);
        }

        public IEnumerable<Document> SelectAll()
        {
            return _documentRepository.SelectAll();
        }

        public Document SelectById(int documentId)
        {
            return _documentRepository.SelectById(documentId);
        }

        public IEnumerable<Document> SelectByIdentifier(string identifier)
        {
            return _documentRepository.SelectByIdentifier(identifier);
        }

        public IEnumerable<Document> SelectPaidByIdentifier(string identifier)
        {
            return _documentRepository.SelectPaidByIdentifier(identifier);
        }

        public IEnumerable<Document> SelectUnpaidByIdentifier(string identifier)
        {
            return _documentRepository.SelectUnpaidByIdentifier(identifier);
        }

        public void Update(Document entity)
        {
            _documentRepository.Update(entity);
        }

        public IEnumerable<Document> SelectByIdRange(int documentId,int size)
        {
            return _documentRepository.SelectByIdRange(documentId, size);
        }

    }
}
