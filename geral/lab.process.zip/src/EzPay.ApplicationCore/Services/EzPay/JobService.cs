﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.ApplicationCore.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Services
{
    public class JobService : IJobService
    {
        private readonly IJobRepository _jobRepository;

        public JobService(IJobRepository jobRepository)
        {
            _jobRepository = jobRepository;
        }

        public void Cancel(string hash)
        {
            _jobRepository.Cancel(hash);
        }

        public IEnumerable<Job> Find(Expression<Func<Job, bool>> expression)
        {
            return _jobRepository.find(expression);
        }

        public Job Insert(Job entity)
        {
            //Regra de negocio
            return _jobRepository.Insert(entity);
        }

        public IEnumerable<Job> SelectAll()
        {
            return _jobRepository.SelectAll();
        }

        public Job SelectByHash(string hash)
        {
           return _jobRepository.SelectByHash(hash);
        }

        public void Update(Job entity)
        {
            _jobRepository.Update(entity);
        }
    }
}
