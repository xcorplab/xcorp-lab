﻿using EzPay.ApplicationCore.Interfaces.Repository.Common;
using EzPay.ApplicationCore.Interfaces.Services.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Services.Common
{
    public class SecretService : ISecretService
    {
        ISecretRepository _secretRepository = null;
        public SecretService(ISecretRepository secretRepository)
        {
            _secretRepository = secretRepository;
        }

        public Dictionary<string, string> GetSecret(string secretName)
        {
            return _secretRepository.GetSecret(secretName);
        }
    }
}
