﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.ApplicationCore.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace EzPay.ApplicationCore.Services
{
    public class StorageService : IStorageService
    {
        private readonly IStorageRepository _storageRepository;

        public StorageService(IStorageRepository storageRepository)
        {
            _storageRepository = storageRepository;
        }

        public async Task<bool> AbortMultipartUploadAsync(StorageFile storageFile)
        {
            return await _storageRepository.AbortMultipartUploadAsync(storageFile);
        }

        public async Task<bool> CompleteMultipartUploadAsync(StorageFile storageFile, int daysExpiration)
        {
            return await _storageRepository.CompleteMultipartUploadAsync(storageFile, daysExpiration);
        }

        public async Task<long> CountLenghtUploadAsync(StorageFile storageFile)
        {
            return await _storageRepository.CountLenghtUploadAsync(storageFile);
        }

        public async Task<bool> CreateRepositoryAsync(string repositoryName)
        {
            return await _storageRepository.CreateRepositoryAsync(repositoryName);
        }

        public async Task<bool> DeleteRepositoryAsync(string repositoryName)
        {
            return await _storageRepository.DeleteRepositoryAsync(repositoryName);
        }

        public string GeneratePreSignedURL(string bucket, string objectKey)
        {
            return _storageRepository.GeneratePreSignedURL(bucket, objectKey);
        }

        public async Task<StorageFile> InitiateMultipartUploadAsync(StorageFile storageFile)
        {
            return await _storageRepository.InitiateMultipartUploadAsync(storageFile);
        }

        public async Task<bool> ResfreshStorage(string repositoryName)
        {
            return await _storageRepository.ResfreshStorage(repositoryName);
        }

        public async Task<bool> UploadAsync(StorageFile storageFile, int daysExpiration)
        {
            return await _storageRepository.UploadAsync(storageFile, daysExpiration);
        }

        public async Task<StorageFile> UploadPartAsync(StorageFile storageFile)
        {
            if (storageFile.currentPart == 1)
                storageFile = await _storageRepository.InitiateMultipartUploadAsync(storageFile);

            return await _storageRepository.UploadPartAsync(storageFile);
        }
    }
}
