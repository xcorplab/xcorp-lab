﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.ApplicationCore.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace EzPay.ApplicationCore.Services
{
    public class QueueService : IQueueService
    {
        private readonly IQueueRepository _queueRepository;

        public QueueService(IQueueRepository queueRepository)
        {
            _queueRepository = queueRepository;
        }

        public async Task SendMessageAsync(string nameQueue, string messageBody)
        {
            await _queueRepository.SendMessageAsync(nameQueue, messageBody);
        }
    }
}
