﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.ApplicationCore.Interfaces.Repository.Common;
using EzPay.ApplicationCore.Interfaces.Services.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EzPay.ApplicationCore.Services.Common
{
    public class BatchService : IBatchService
    {
        private readonly IBatchRepository _batchRepository;

        public BatchService(IBatchRepository batchRepository)
        {
            _batchRepository = batchRepository;
        }

        public async Task TerminateProcessAsync(string identificador, string mensagem)
        {
            await _batchRepository.TerminateProcessAsync(identificador, mensagem);
        }

        public async Task<MessageStep> StartProcessAsync(MessageProcess message)//MessageStep step, List<MessageParameter> parameter)
        {
            MessageStep step = new MessageStep();
            step = message.steps.OrderBy(o => o.order).Where(w => w.status == 1).ToList().FirstOrDefault();

            return await _batchRepository.StartProcessAsync(step, message);
        }

        public Task<bool> FindBatchAsync(string process)
        {
            return _batchRepository.FindBatchAsync(process);
        }
    }
}
