﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Interfaces.Repository.Common
{
    public interface ISecretRepository
    {
        Dictionary<String, String> GetSecret(string secretName);
    }
}
