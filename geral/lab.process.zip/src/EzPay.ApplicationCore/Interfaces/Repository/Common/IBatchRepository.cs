﻿using EzPay.ApplicationCore.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EzPay.ApplicationCore.Interfaces.Repository.Common
{
    public interface IBatchRepository
    {
        Task<MessageStep> StartProcessAsync(MessageStep step, MessageProcess message);
        Task TerminateProcessAsync(string identificador, string mensagem);
        Task<bool> FindBatchAsync(string process);
    }
}
