﻿using EzPay.ApplicationCore.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Interfaces.Repository
{
    public interface IClientRepository : IEzPayRepository<Client>
    {
        Client SelectByHash(string hash);
    }
}
