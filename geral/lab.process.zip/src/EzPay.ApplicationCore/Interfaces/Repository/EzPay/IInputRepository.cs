﻿using EzPay.ApplicationCore.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Interfaces.Repository
{
    public interface IInputRepository : IEzPayRepository<Input>
    {
        void Cancel(string hash);
    }
}
