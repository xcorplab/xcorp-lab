﻿using EzPay.ApplicationCore.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EzPay.ApplicationCore.Interfaces.Repository
{
    public interface IProcessRepository : IEzPayRepository<Process>
    {
        Process SelectByIdentificador(string identificador);
    }
}
