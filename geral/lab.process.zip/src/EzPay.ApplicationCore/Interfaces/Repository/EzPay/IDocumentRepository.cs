﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Entity.EzPay;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Interfaces.Repository
{
    public interface IDocumentRepository : IEzPayRepository<Document>
    {
        IEnumerable<Document> SelectByIdentifier(string identifier);
        Document SelectById(int documentId);
        IEnumerable<Document> SelectPaidByIdentifier(string identifier);
        IEnumerable<Document> SelectUnpaidByIdentifier(string identifier);
        IEnumerable<Document> SelectByIdRange(int documentId,int size);
    }
}
