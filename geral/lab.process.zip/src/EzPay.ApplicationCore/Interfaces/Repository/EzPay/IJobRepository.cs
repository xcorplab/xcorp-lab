﻿using EzPay.ApplicationCore.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Interfaces.Repository
{
    public interface IJobRepository : IEzPayRepository<Job>
    {
        Job SelectByHash(string hash);
        void Cancel(string hash);
    }
}
