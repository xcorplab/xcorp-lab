﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Interfaces.Repository
{
    public interface IEzPayRepository<TEntity> where TEntity : class
    {
        TEntity Insert(TEntity entity);
        IEnumerable<TEntity> InsertMany(IEnumerable<TEntity> entity);
        void Update(TEntity entity);
        IEnumerable<TEntity> SelectAll();
        IEnumerable<TEntity> find(Expression<Func<TEntity, bool>> expression);
        void DeleteMany(IEnumerable<TEntity> entities);
    }
}
