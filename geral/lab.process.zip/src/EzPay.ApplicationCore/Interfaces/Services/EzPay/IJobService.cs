﻿using EzPay.ApplicationCore.Entity;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Interfaces.Services
{
    public interface IJobService
    {
        Job Insert(Job entity);
        void Update(Job entity);
        IEnumerable<Job> SelectAll();
        IEnumerable<Job> Find(Expression<Func<Job, bool>> expression);
        Job SelectByHash(string hash);
        void Cancel(string hash);
    }
}
