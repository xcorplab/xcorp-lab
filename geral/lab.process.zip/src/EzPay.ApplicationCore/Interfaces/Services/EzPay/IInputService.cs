﻿using EzPay.ApplicationCore.Entity;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Interfaces.Services
{
    public interface IInputService
    {
        Input Insert(Input entity);
        IEnumerable<Input> InsertMany(IEnumerable<Input> entity);
        void Update(Input entity);
        IEnumerable<Input> SelectAll();
        IEnumerable<Input> Find(Expression<Func<Input, bool>> expression);
        void Cancel(string hash);
    }
}
