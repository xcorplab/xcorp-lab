﻿using EzPay.ApplicationCore.Entity;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Interfaces.Services
{
    public interface IApplicationService
    {
        Application Insert(Application entity);
        void Update(Application entity);
        IEnumerable<Application> SelectAll();
        IEnumerable<Application> Find(Expression<Func<Application, bool>> expression);
        Application SelectByHash(string hash);
    }
}
