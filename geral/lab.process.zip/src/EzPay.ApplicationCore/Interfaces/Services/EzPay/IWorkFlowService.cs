﻿using EzPay.ApplicationCore.Entity;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Interfaces.Services
{
    public interface IWorkFlowService
    {
       WorkFlow findById(int workFlowId);

    }
}
