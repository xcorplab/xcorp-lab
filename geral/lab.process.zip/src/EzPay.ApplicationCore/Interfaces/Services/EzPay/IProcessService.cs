﻿using EzPay.ApplicationCore.Entity;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Interfaces.Services
{
    public interface IProcessService
    {
        Process Insert(Process entity);
        Process SelectByIdentificador(string identificador);
        void DeleteMany(IEnumerable<Process> entities);
    }
}
