﻿using EzPay.ApplicationCore.Entity;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Interfaces.Services
{
    public interface IHistoryJobService
    {
        HistoryJob Insert(HistoryJob entity);
        IEnumerable<HistoryJob> InsertMany(IEnumerable<HistoryJob> entity);
        void Update(HistoryJob entity);
        IEnumerable<HistoryJob> SelectAll();
        IEnumerable<HistoryJob> Find(Expression<Func<HistoryJob, bool>> expression);
    }
}
