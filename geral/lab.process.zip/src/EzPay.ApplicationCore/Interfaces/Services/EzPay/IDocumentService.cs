﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Entity.EzPay;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.ApplicationCore.Interfaces.Services
{
    public interface IDocumentService
    {
        Document Insert(Document entity);
        void InsertMany(IEnumerable<Document> entities);
        void Update(Document entity);
        IEnumerable<Document> SelectAll();
        IEnumerable<Document> Find(Expression<Func<Document, bool>> expression);
        IEnumerable<Document> SelectByIdentifier(string identifier);
        IEnumerable<Document> SelectPaidByIdentifier(string identifier);
        IEnumerable<Document> SelectUnpaidByIdentifier(string identifier);
        Document SelectById(int documentId);
        IEnumerable<Document> SelectByIdRange(int documentId,int size);
    }
}
