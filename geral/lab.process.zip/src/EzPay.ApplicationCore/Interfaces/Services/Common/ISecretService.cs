﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Interfaces.Services.Common
{
    public interface ISecretService
    {
        Dictionary<String, String> GetSecret(string secretName);

    }
}
