﻿using EzPay.ApplicationCore.Entity;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace EzPay.ApplicationCore.Interfaces.Services
{
    public interface IStorageService
    {
        Task<StorageFile> InitiateMultipartUploadAsync(StorageFile storageFile);
        Task<StorageFile> UploadPartAsync(StorageFile storageFile);
        Task<bool> UploadAsync(StorageFile storageFile, int daysExpiration);
        Task<bool> CompleteMultipartUploadAsync(StorageFile storageFile, int daysExpiration);
        Task<bool> AbortMultipartUploadAsync(StorageFile storageFile);
        Task<long> CountLenghtUploadAsync(StorageFile storageFile);
        Task<bool> CreateRepositoryAsync(string repositoryName);
        Task<bool> DeleteRepositoryAsync(string repositoryName);
        Task<bool> ResfreshStorage(string repositoryName);
        string GeneratePreSignedURL(string bucket, string objectKey);
    }
}
