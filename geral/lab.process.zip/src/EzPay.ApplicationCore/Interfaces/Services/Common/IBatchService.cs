﻿using EzPay.ApplicationCore.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EzPay.ApplicationCore.Interfaces.Services.Common
{
    public interface IBatchService
    {
        Task<MessageStep> StartProcessAsync(MessageProcess message);//MessageStep step, List<MessageParameter> parameter);
        Task TerminateProcessAsync(string identificador, string mensagem);
        Task<bool> FindBatchAsync(string process);
    }
}
