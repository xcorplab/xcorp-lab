﻿using System.Threading.Tasks;

namespace EzPay.ApplicationCore.Interfaces.Services
{
    public interface IQueueService
    {
        Task SendMessageAsync(string nameQueue, string messageBody);
    }
}
