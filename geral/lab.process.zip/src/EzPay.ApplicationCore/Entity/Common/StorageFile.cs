﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace EzPay.ApplicationCore.Entity
{
    public class StorageFile
    {
        public string uploadId { get; set; }
        public string partId { get; set; }
        public int currentPart { get; set; }
        public int totalParts { get; set; }
        public string identifier { get; set; }
        public string path { get; set; }
        public byte[] partFile { get; set; }
        //public Stream partFile { get; set; }
    }
}
