﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Entity
{
    public class MessageProcess
    {
        public string jobId { get; set; }
        public string basePath { get; set; }
        public DateTime start { get; set; }
        public DateTime end { get; set; }
        public IEnumerable<MessageStep> steps { get; set; }
        public IEnumerable<MessageParameter> parameters { get; set; }
        public IEnumerable<MessageInput> inputs { get; set; }
    }

    public class MessageStep
    {
        public string name { get; set; }
        public int order { get; set; }
        public int stepId { get; set; }
        public string jobQueue { get; set; }
        public string jobName { get; set; }
        public string jobDefinition { get; set; }
        public string identificador { get; set; }
        public int status { get; set; }
        public DateTime start { get; set; }
        public DateTime end { get; set; }
        public IEnumerable<MessageCommand> commands { get; set; }
    }

    public class MessageCommand
    {
        public string value { get; set; }
    }

    public class MessageParameter
    {
        public string name { get; set; }
        public string value { get; set; }
    }

    public class MessageInput
    {
        public string name { get; set; }
        public string secret { get; set; }
    }
}
