﻿using EzPay.ApplicationCore.Entity.EzPay;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EzPay.ApplicationCore.Entity
{
    public class Job
    {
        public int jobId { get; set; }
        public int applicationId { get; set; }
        public int statusId { get; set; }
        public string aggregateName { get; set; }
        public string hash { get; set; }
        public DateTime? startDate { get; set; }
        public DateTime? endDate { get; set; }
        public DateTime expiration { get; set; }
        public int statusRow { get; set; }
        public DateTime created { get; set; }
        public DateTime? updated { get; set; }

        #region --Relacionamentos--
        public Status status { get; set; }
        public IEnumerable<HistoryJob> historyJobs { get; set; }
        public IEnumerable<Input> inputs { get; set; }
        public IEnumerable<Process> processes { get; set; }
        public IEnumerable<Document> documents { get; set; }
        public Application application { get; set; }
        #endregion
    }
}
