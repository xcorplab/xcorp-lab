﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Entity
{
    public class Process
    {
        public int processId { get; set; }
        public int jobId { get; set; }
        public int stepId { get; set; }
        public string identifier { get; set; }
        public DateTime created { get; set; }

        public Job job { get; set; }
    }
}
