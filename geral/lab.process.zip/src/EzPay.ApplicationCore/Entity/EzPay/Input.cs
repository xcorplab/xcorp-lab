﻿using System;

namespace EzPay.ApplicationCore.Entity
{
    public class Input
    {
        public int inputId { get; set; }
        public int jobId { get; set; }
        public string hash { get; set; }
        public string name { get; set; }
        public long size { get; set; }
        public string secret { get; set; }
        public int statusRow { get; set; }
        public DateTime created { get; set; }
        public DateTime? updated { get; set; }

        #region --Relacionamentos--
        public Job job { get; set; }
        #endregion
    }
}
