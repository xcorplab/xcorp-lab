﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Entity.EzPay
{
    public class Dealership
    {
        public int dealershipId { get; set; }
        public string name { get; set; }
        public string image { get; set; }
        public DateTime created { get; set; }

        #region --Relacionamentos--
        public IEnumerable<Application> applications { get; set; }
        #endregion
    }
}
