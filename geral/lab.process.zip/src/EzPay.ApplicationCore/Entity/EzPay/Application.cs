﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Entity.EzPay;
using System;
using System.Collections.Generic;

namespace EzPay.ApplicationCore.Entity
{
    public class Application
    {
        public int applicationId { get; set; }
        public int clientId { get; set; }
        public int dealershipId { get; set; }
        public string name { get; set; }
        public string hash { get; set; }
        public int daysExpiration { get; set; }
        public int statusRow { get; set; }
        public DateTime created { get; set; }
        public DateTime? updated { get; set; }

        #region --Relacionamentos--
        public Client client { get; set; }
        public Dealership dealership { get; set; }
        public IEnumerable<Job> jobs { get; set; }
        public WorkFlow workFlow { get; set; }
        #endregion
    }
}
