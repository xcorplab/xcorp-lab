﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Entity
{
    public class WorkFlowStep
    {
        public int workFlowId { get; set; }
        public WorkFlow workFlow { get; set; }
        public int stepId { get; set; }
        public Step step { get; set; }
        public int order { get; set; }
    }
}
