﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Entity
{
    public class Parameter
    {
        public int parameterId { get; set; }
        public int workFlowId { get; set; }
        public string name { get; set; }
        public string value { get; set; }
        public DateTime created { get; set; }
        public DateTime? updated { get; set; }

        #region --Relacionamentos--
        public WorkFlow workFlow { get; set; }
        #endregion
    }
}
