﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Entity.EzPay
{
    public class Status
    {
        public int statusId { get; set; }
        public string name { get; set; }
        public DateTime created { get; set; }

        #region --Relacionamentos--
        public IEnumerable<Job> jobs { get; set; }
        #endregion
    }
}
