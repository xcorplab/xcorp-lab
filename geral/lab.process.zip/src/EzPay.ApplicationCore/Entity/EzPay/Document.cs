﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Entity.EzPay
{
    public class Document
    {
        public int documentId { get; set; }
        public int jobId { get; set; }
        public string identifier { get; set; }
        public string name { get; set; }
        public string file { get; set; }
        public string value { get; set; }
        public string barCode { get; set; }
        public DateTime dueDateInvoice { get; set; }
        public int paymentStatus { get; set; }
        public DateTime payDate { get; set; }
        public int statusRow { get; set; }
        public DateTime created { get; set; }
        public DateTime updated { get; set; }

        #region --Relacionamentos--
        public Job job { get; set; }
        #endregion
    }
}
