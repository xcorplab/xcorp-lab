﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Entity
{
    public class Step
    {
        public int stepId { get; set; }
        public string name { get; set; }
        public int order { get; set; }
        public string jobQueue { get; set; }
        public string jobName { get; set; }
        public string jobDefinition { get; set; }
        public int status { get; set; }
        public DateTime start { get; set; }
        public DateTime end { get; set; }
        public DateTime created { get; set; }

        #region --Relacionamentos--
        public IEnumerable<Command> commands { get; set; }
        public IEnumerable<WorkFlowStep> workFlowSteps { get; set; }
        #endregion
    }
}
