﻿using System;
using System.Collections;

namespace EzPay.ApplicationCore.Entity
{
    public class HistoryJob
    {
        public int historyJobId { get; set; }
        public int jobId { get; set; }
        public string info { get; set; }
        public string level { get; set; }
        public string source { get; set; }
        public DateTime created { get; set; }

        #region --Relacionamentos--
        public Job job { get; set; }
        #endregion
    }
}
