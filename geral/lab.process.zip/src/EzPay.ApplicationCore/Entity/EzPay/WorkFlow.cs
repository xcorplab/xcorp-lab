﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Entity
{
    public class WorkFlow
    {
        public int workFlowId { get; set; }
        //public int jobId { get; set; }
        public int applicationId { get; set; }
        //public string orderProcess { get; set; }
        public DateTime created { get; set; }
        //public int nextStep { get; set; }

        #region --Relacionamentos--
        public Application application { get; set; }
        public IEnumerable<Parameter> parameters { get; set; }
        public IEnumerable<WorkFlowStep> workFlowSteps { get; set; }
        #endregion
    }
}
