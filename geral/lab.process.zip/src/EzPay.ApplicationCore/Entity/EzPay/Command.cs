﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.ApplicationCore.Entity
{
    public class Command
    {
        public int commandId { get; set; }
        public int stepId { get; set; }
        public string value { get; set; }
        public DateTime created { get; set; }

        #region --Relacionamentos--
        public Step step { get; set; }
        #endregion
    }
}
