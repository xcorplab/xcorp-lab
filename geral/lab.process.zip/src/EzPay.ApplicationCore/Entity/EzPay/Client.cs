﻿using System;
using System.Collections.Generic;

namespace EzPay.ApplicationCore.Entity
{
    public class Client
    {
        public int clientId { get; set; }
        public string name { get; set; }
        public string hash { get; set; }
        public int statusRow { get; set; }
        public DateTime created { get; set; }
        public DateTime? updated { get; set; }

        #region --Relacionamentos--
        public IEnumerable<Application> applications{ get; set; }
        #endregion
    }
}
