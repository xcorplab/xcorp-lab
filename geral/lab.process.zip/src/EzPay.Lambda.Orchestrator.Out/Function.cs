using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon.Lambda.Core;
using Amazon.Lambda.SQSEvents;
using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Services;
using EzPay.ApplicationCore.Interfaces.Services.Common;
using EzPay.IoC;
using Newtonsoft.Json;
using Microsoft.Extensions.DependencyInjection;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]

namespace EzPay.Lambda.Orchestrator.Out
{
    public class Function
    {
        public static IServiceProvider infrastructure = new InfrastructureContainerBuilder()
                                            .RegisterModule(new InfrastructureFactory())
                                            .Build();

        public static IServiceProvider common = new CommonContainerBuilder()
                                         .RegisterModule(new CommonFactory())
                                         .Build();

        private readonly IJobService _jobService = null;
        private readonly IHistoryJobService _historyJobService = null;
        private readonly IQueueService _queueService = null;
        private readonly IBatchService _batchService = null;
        private readonly IProcessService _processService = null;
        private readonly IStorageService _storageService = null;

        /// <summary>
        /// Default constructor. This constructor is used by Lambda to construct the instance. When invoked in a Lambda environment
        /// the AWS credentials will come from the IAM role associated with the function and the AWS region will be set to the
        /// region the Lambda function is executed in.
        /// </summary>
        public Function()
        {
            _jobService = infrastructure.GetService<IJobService>();
            _historyJobService = infrastructure.GetService<IHistoryJobService>();
            _processService = infrastructure.GetService<IProcessService>();
            _queueService = common.GetService<IQueueService>();
            _batchService = common.GetService<IBatchService>();
            _storageService = common.GetService<IStorageService>();
        }


        /// <summary>
        /// This method is called for every Lambda invocation. This method takes in an SQS event object and can be used 
        /// to respond to SQS messages.
        /// </summary>
        /// <param name="evnt"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task FunctionHandler(SQSEvent evnt, ILambdaContext context)
        {
            foreach (var message in evnt.Records)
            {
                await ProcessMessageAsync(message, context);
            }
        }

        private async Task ProcessMessageAsync(SQSEvent.SQSMessage message, ILambdaContext context)
        {
            MessageProcess messageQueue = JsonConvert.DeserializeObject<MessageProcess>(message.Body);
            try
            {
                Job job = _jobService.SelectByHash(messageQueue.jobId);
                if (job.statusId != 5 && job.statusId != 6)
                {
                    if (messageQueue.steps.Where(w => w.status == 4).OrderBy(o => o.order).ToList().Count() > 0)
                    {
                        MessageStep step = new MessageStep();
                        step = messageQueue.steps.OrderBy(o => o.order).Where(w => w.status == 4).ToList().FirstOrDefault();

                        string queue = string.Format("ezpay-{0}-fail", step.name);
                        await _queueService.SendMessageAsync(queue, message.Body);

                        job.statusId = 4;
                        job.endDate = DateTime.Now;
                        job.updated = DateTime.Now;
                        _jobService.Update(job);

                        _historyJobService.Insert(new HistoryJob()
                        {
                            created = DateTime.Now,
                            info = string.Format("Etapa {0} com erro.", step.jobName),
                            jobId = job.jobId,
                            level = "error",
                            source = ""
                        });
                    }
                    else if (messageQueue.steps.Where(w => w.status == 3).OrderBy(o => o.order).ToList().Count() == messageQueue.steps.Count())
                    {
                        MessageStep step = new MessageStep();
                        step = messageQueue.steps.OrderBy(o => o.order).Where(w => w.status == 3).ToList().LastOrDefault();

                        _historyJobService.Insert(new HistoryJob()
                        {
                            created = DateTime.Now,
                            info = string.Format("Etapa {0} finalizado.", step.jobName),
                            jobId = job.jobId,
                            level = "info",
                            source = ""
                        });

                        job.statusId = 3;
                        job.endDate = DateTime.Now;
                        job.updated = DateTime.Now;
                        _jobService.Update(job);

                        _historyJobService.Insert(new HistoryJob()
                        {
                            created = DateTime.Now,
                            info = string.Format("Processamento finalizado.", step.jobName),
                            jobId = job.jobId,
                            level = "info",
                            source = ""
                        });
                    }
                    else if (messageQueue.steps.Where(w => w.status == 1).OrderBy(o => o.order).ToList().Count() > 0)
                    {
                        //await _storageService.ResfreshStorage(string.Format("//"));

                        MessageStep step = new MessageStep();
                        step = messageQueue.steps.OrderBy(o => o.order).Where(w => w.status == 3).ToList().LastOrDefault();

                        _historyJobService.Insert(new HistoryJob()
                        {
                            created = DateTime.Now,
                            info = string.Format("Etapa {0} finalizado.", step.jobName),
                            jobId = job.jobId,
                            level = "info",
                            source = ""
                        });

                        string queue = string.Format("ezpay-{0}-in", messageQueue.steps.Where(w => w.status == 1).OrderBy(o => o.order).ToList().FirstOrDefault().name);
                        await _queueService.SendMessageAsync(queue, JsonConvert.SerializeObject(messageQueue));
                    }
                }
                else
                {
                    _historyJobService.Insert(new HistoryJob()
                    {
                        created = DateTime.Now,
                        info = string.Format("Processamento do job {0} foi parado.", job.hash),
                        jobId = job.jobId,
                        level = "info",
                        source = ""
                    });
                }
            }
            catch (Exception ex)
            {
                Job job = _jobService.SelectByHash(messageQueue.jobId);

                _historyJobService.Insert(new HistoryJob()
                {
                    created = DateTime.Now,
                    info = string.Format("Falha no processamento do batch {0} Out.", messageQueue.steps.OrderBy(o => o.order).Where(w => w.status == 1).ToList().FirstOrDefault().name),
                    jobId = job.jobId,
                    level = "info",
                    source = ex.StackTrace
                });

                string queue = string.Format("ezpay-{0}-fail", messageQueue.steps.OrderBy(o => o.order).Where(w => w.status == 1).ToList().FirstOrDefault().name);
                await _queueService.SendMessageAsync(queue, message.Body);
            }

            // TODO: Do interesting work based on the new message
            await Task.CompletedTask;
        }
    }
}
