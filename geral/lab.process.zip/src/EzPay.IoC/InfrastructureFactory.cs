﻿using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.ApplicationCore.Interfaces.Services;
using EzPay.ApplicationCore.Services;
using EzPay.Infrastructure.Data;
using EzPay.Infrastructure.Repository;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.IoC
{
    public class InfrastructureFactory : Module
    {
        public override void Load(IServiceCollection services)
        {
            services.AddDbContext<EzPayContext>();

            services.AddTransient<IClientService, ClientService>();
            services.AddTransient<IClientRepository, ClientRepository>();
            
            services.AddTransient<IApplicationService, ApplicationService>();
            services.AddTransient<IApplicationRepository, ApplicationRepository>();

            services.AddTransient<IJobService, JobService>();
            services.AddTransient<IJobRepository, JobRepository>();

            services.AddTransient<IInputService, InputService>();
            services.AddTransient<IInputRepository, InputRepository>();

            services.AddTransient<IHistoryJobService, HistoryJobService>();
            services.AddTransient<IHistoryJobRepository, HistoryJobRepository>();

            services.AddTransient<IWorkFlowService, WorkFlowService>();
            services.AddTransient<IWorkFlowRepository, WorkFlowRepository>();

            services.AddTransient<IProcessService, ProcessService>();
            services.AddTransient<IProcessRepository, ProcessRepository>();

            services.AddTransient<IDocumentService, DocumentService>();
            services.AddTransient<IDocumentRepository, DocumentRepository>();

            //services.AddSingleton<IJobService>();

        }
    }
}
