﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.IoC
{
    public interface ICommonContainerBuilder
    {
        ICommonContainerBuilder RegisterModule(IModule module = null);
        IServiceProvider Build();
    }
}
