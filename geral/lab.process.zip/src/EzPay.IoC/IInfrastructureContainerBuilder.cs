﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.IoC
{
    public interface IInfrastructureContainerBuilder
    {
        IInfrastructureContainerBuilder RegisterModule(IModule module = null);
        IServiceProvider Build();
    }
}
