﻿using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.ApplicationCore.Interfaces.Repository.Common;
using EzPay.ApplicationCore.Interfaces.Services;
using EzPay.ApplicationCore.Interfaces.Services.Common;
using EzPay.ApplicationCore.Services;
using EzPay.ApplicationCore.Services.Common;
using EzPay.Commons.Repository;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.IoC
{
    public class CommonFactory : Module
    {
        public override void Load(IServiceCollection services)
        {
            services.AddTransient<IStorageService, StorageService>();
            services.AddTransient<IStorageRepository, StorageRepository>();

            services.AddTransient<IQueueService, QueueService>();
            services.AddTransient<IQueueRepository, QueueRepository>();

            services.AddTransient<IBatchService, BatchService>();
            services.AddTransient<IBatchRepository, BatchRepository>();
        }
    }
}
