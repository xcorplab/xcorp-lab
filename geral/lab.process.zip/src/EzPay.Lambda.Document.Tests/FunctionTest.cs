using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Xunit;
using Amazon.Lambda.TestUtilities;
using Amazon.Lambda.SQSEvents;

using EzPay.Lambda.Document;
using Amazon.SecretsManager;
using System.IO;
using Amazon;
using Amazon.SecretsManager.Model;
using Newtonsoft.Json;
using Amazon.SQS.Model;
using Amazon.SQS;
using Amazon.Runtime;
using System.Net;

namespace EzPay.Lambda.Document.Tests
{
    public class FunctionTest
    {
        [Fact]
        public async Task TestSQSEventLambdaFunction()
        {
            var sqsEvent = new SQSEvent
            {
                Records = new List<SQSEvent.SQSMessage>
                {
                    new SQSEvent.SQSMessage
                    {
                        Body = "foobar"
                    }
                }
            };

            var logger = new TestLambdaLogger();
            var context = new TestLambdaContext
            {
                Logger = logger
            };

            var function = new Function();
            await function.FunctionHandler(sqsEvent, context);

            Assert.Contains("Processed message foobar", logger.Buffer.ToString());
        }
        [Fact]
        public async Task TestSQSEventLambdaFunctionRead()
        {
            try
            {
                string queueUrl = GetSecret("queue")["ezpay-document-in"];
                //string queueUrl = GetSecret("queue")["ezpay-dataprocessing-in"];
                BasicAWSCredentials awsCreds = new BasicAWSCredentials(GetSecret("key")["access-key"], GetSecret("key")["secret-key"]);

                AmazonSQSConfig config = new AmazonSQSConfig();
                //config.ProxyHost = "proxy";
                //config.ProxyPort = 80;
                //config.ProxyCredentials = CredentialCache.DefaultNetworkCredentials;

                config.RegionEndpoint = RegionEndpoint.SAEast1;

                AmazonSQSClient amazonSQSClient = new AmazonSQSClient(awsCreds, config);

                var request = new ReceiveMessageRequest
                {
                    AttributeNames = { "SentTimestamp" },
                    MaxNumberOfMessages = 1,
                    MessageAttributeNames = { "All" },
                    QueueUrl = queueUrl,
                    WaitTimeSeconds = 20
                };

                var response = amazonSQSClient.ReceiveMessageAsync(request).Result;

                var sqsEvent = new SQSEvent();
                sqsEvent.Records = new List<SQSEvent.SQSMessage>();
                foreach (Amazon.SQS.Model.Message message in response.Messages)
                {
                    sqsEvent.Records.Add(new SQSEvent.SQSMessage
                    {
                        Attributes = message.Attributes,
                        Body = message.Body,
                        MessageId = message.MessageId
                    });
                }

                var logger = new TestLambdaLogger();
                var context = new TestLambdaContext
                {
                    Logger = logger
                };

                var function = new Function();
                await function.FunctionHandler(sqsEvent, context);

                //Assert.Contains("Processed message", logger.Buffer.ToString());
                Assert.True(true);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public Dictionary<String, String> GetSecret(String secretName)
        {
            MemoryStream memoryStream = new MemoryStream();

            AmazonSecretsManagerConfig config = new AmazonSecretsManagerConfig();

            //config.ProxyHost = "proxy";
            //config.ProxyPort = 80;
            //config.ProxyCredentials = CredentialCache.DefaultNetworkCredentials;

            config.RegionEndpoint = RegionEndpoint.SAEast1;

            IAmazonSecretsManager client = new AmazonSecretsManagerClient(config);

            GetSecretValueRequest request = new GetSecretValueRequest
            {
                SecretId = secretName,
                VersionStage = "AWSCURRENT"
            };

            try
            {
                return JsonConvert.DeserializeObject<Dictionary<string, string>>(client.GetSecretValueAsync(request).Result.SecretString);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
