﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Lambda.Document.ViewModel.DocumentViewModel
{
    public class ResponseViewModel
    {
        public int dealerID { get; set; }
        public string dealerName { get; set; }
        //public int requisitionID { get; set; }
        public string document { get; set; }
        public string description { get; set; }
        public string fileURL { get; set; }
        public string value { get; set; }
        public string barCode { get; set; }
        public int documentId { get; set; }
        public string dealerImageURL { get; set; }
        public string fileName { get; set; }
        public DateTime datePay { get; set; }
        public DateTime dueDateInvoice { get; set; }
        public int paymentStatus { get; set; }
        //public DateTime dateProcess { get; set; }
        //public DateTime dateSend { get; set; }
    }
}
