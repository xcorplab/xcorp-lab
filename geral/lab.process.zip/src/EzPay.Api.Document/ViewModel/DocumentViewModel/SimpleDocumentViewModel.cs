﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EzPay.Api.Document.ViewModel.DocumentViewModel
{
    public class SimpleDocumentViewModel
    {
        public int documentId { get; set; }
        public string identifiier { get; set; }
        public int dealerId { get; set; }
    }
}
