﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EzPay.Api.Document.ViewModel.DocumentViewModel
{
    public class PaymentViewModel
    {
        public int paymentMethod { get; set; }
        public int documentId { get; set; }
    }
}
