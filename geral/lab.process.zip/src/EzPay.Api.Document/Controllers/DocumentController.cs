﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EzPay.ApplicationCore.Entity.EzPay;
using EzPay.ApplicationCore.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using EzPay.Lambda.Document.ViewModel.DocumentViewModel;
using System.Security.Claims;
using EzPay.Api.Document.ViewModel.DocumentViewModel;

namespace EzPay.Api.Document.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize()]
    public class DocumentController : Controller
    {
        private readonly IDocumentService _documentService;
        private readonly IStorageService _storageService;

        public DocumentController(IDocumentService documentService, IStorageService storageService)
        {
            _documentService = documentService;
            _storageService = storageService;
        }

        [HttpGet]
        [Route("CountDocuments")]
        [AllowAnonymous]
        public IActionResult CountDocuments()
        {
            var identity = User.Identity as ClaimsIdentity;
            int countDocs = _documentService.SelectByIdentifier(identity.Claims.FirstOrDefault(claim => claim.Type == "identifier").Value.ToString()).Count();
            return Ok(countDocs);
        }

        [HttpGet]
        [Route("FindDocument")]
        [AllowAnonymous]
        public IActionResult FindDocument(int documentId)
        {
            var identity = User.Identity as ClaimsIdentity;

            var doc = _documentService.SelectById(documentId);

            string url = _storageService.GeneratePreSignedURL(string.Format("{0}",
                   "com.printlaser.poc"), "BOLETO_PRINTLASER.PDF");

            return Ok(new ResponseViewModel()
            {
                barCode = doc.barCode,
                datePay = doc.payDate,
                dealerID = doc.job.application.dealershipId,
                description = doc.job.application.name,
                fileURL = url,
                value = doc.value,
                document = doc.identifier,
                dealerName = doc.job.application.dealership.name,
                fileName = doc.file,
                documentId = doc.documentId,
                dealerImageURL = doc.job.application.dealership.image,
                paymentStatus = doc.paymentStatus,
                dueDateInvoice = doc.dueDateInvoice
            });
        }

        [HttpGet]
        [Route("ListDocuments")]
        //[AllowAnonymous]
        public IActionResult ListDocuments()
        {
            var identity = User.Identity as ClaimsIdentity;

            var documents = _documentService.SelectByIdentifier(identity.Claims.FirstOrDefault(claim => claim.Type == "identifier").Value.ToString()).ToList();

            List<ResponseViewModel> responses = new List<ResponseViewModel>();

            documents.ForEach(d =>
            {
                string url = _storageService.GeneratePreSignedURL(string.Format("{0}",
                    "com.printlaser.poc"), "BOLETO_PRINTLASER.PDF");

                //string url = _storageService.GeneratePreSignedURL(string.Format("{0}/{1}/{2}/{3}/{4}",
                //    "ez-storage",
                //    d.job.application.client.hash,
                //    d.job.application.hash,
                //    d.job.hash,
                //    "output"), d.file);

                responses.Add(new ResponseViewModel()
                {
                    barCode = d.barCode,
                    datePay = d.payDate,
                    dealerID = d.job.application.dealershipId,
                    description = d.job.application.name,
                    fileURL = url,
                    value = d.value,
                    document = d.identifier,
                    dealerName = d.job.application.dealership.name,
                    fileName = d.file,
                    documentId = d.documentId,
                    dealerImageURL = d.job.application.dealership.image,
                    paymentStatus = d.paymentStatus
                });
            });

            return Ok(responses);
        }

        [HttpGet]
        [Route("ListPaidDocuments")]
        //[AllowAnonymous]
        public IActionResult ListPaidDocuments()
        {
            var identity = User.Identity as ClaimsIdentity;

            var documents = _documentService.SelectPaidByIdentifier(identity.Claims.FirstOrDefault(claim => claim.Type == "identifier").Value.ToString()).ToList();

            List<ResponseViewModel> responses = new List<ResponseViewModel>();

            documents.ForEach(d =>
            {
                string url = _storageService.GeneratePreSignedURL(string.Format("{0}",
                    "com.printlaser.poc"), "BOLETO_PRINTLASER.PDF");

                //string url = _storageService.GeneratePreSignedURL(string.Format("{0}/{1}/{2}/{3}/{4}",
                //    "ez-storage",
                //    d.job.application.client.hash,
                //    d.job.application.hash,
                //    d.job.hash,
                //    "output"), d.file);

                responses.Add(new ResponseViewModel()
                {
                    barCode = d.barCode,
                    datePay = d.payDate,
                    dealerID = d.job.application.dealershipId,
                    description = d.job.application.name,
                    fileURL = url,
                    value = d.value,
                    document = d.identifier,
                    dealerName = d.job.application.dealership.name,
                    fileName = d.file,
                    documentId = d.documentId,
                    dealerImageURL = d.job.application.dealership.image,
                    paymentStatus = d.paymentStatus
                });
            });

            return Ok(responses);
        }

        [HttpGet]
        [Route("ListUnpaidDocuments")]
        //[AllowAnonymous]
        public IActionResult ListUnpaidDocuments()
        {
            var identity = User.Identity as ClaimsIdentity;

            var documents = _documentService.SelectUnpaidByIdentifier(identity.Claims.FirstOrDefault(claim => claim.Type == "identifier").Value.ToString()).ToList();

            List<ResponseViewModel> responses = new List<ResponseViewModel>();

            documents.ForEach(d =>
            {
                string url = _storageService.GeneratePreSignedURL(string.Format("{0}",
                    "com.printlaser.poc"), "BOLETO_PRINTLASER.PDF");

                //string url = _storageService.GeneratePreSignedURL(string.Format("{0}/{1}/{2}/{3}/{4}",
                //    "ez-storage",
                //    d.job.application.client.hash,
                //    d.job.application.hash,
                //    d.job.hash,
                //    "output"), d.file);

                responses.Add(new ResponseViewModel()
                {
                    barCode = d.barCode,
                    datePay = d.payDate,
                    dealerID = d.job.application.dealershipId,
                    description = d.job.application.name,
                    fileURL = url,
                    value = d.value,
                    document = d.identifier,
                    dealerName = d.job.application.dealership.name,
                    fileName = d.file,
                    documentId = d.documentId,
                    dealerImageURL = d.job.application.dealership.image,
                    paymentStatus = d.paymentStatus
                });
            });

            return Ok(responses);
        }

        [HttpGet]
        [Route("PayDocument")]
        public IActionResult PayDocument(int documentId, int paymentMethod)//int documentId, int paymentMethod)
        {
            var identity = User.Identity as ClaimsIdentity;

            var document = _documentService.SelectById(documentId);

            document.payDate = DateTime.Now;
            document.updated = DateTime.Now;
            document.paymentStatus = paymentMethod;
            _documentService.Update(document);

            return Ok();
        }

        [HttpGet]
        [Route("GetDocumentByDocumentIdRange")]
        //[AllowAnonymous]
        public IActionResult GetDocumentByDocumentIdRange(int documentId,int size)
        {
            var identity = User.Identity as ClaimsIdentity;

            var documents = _documentService.SelectByIdRange(documentId,size);

            List<SimpleDocumentViewModel> responses = new List<SimpleDocumentViewModel>();

            foreach (ApplicationCore.Entity.EzPay.Document document in documents)
            {
                responses.Add(new SimpleDocumentViewModel()
                {
                    documentId = document.documentId,
                    identifiier = document.identifier,
                    dealerId = document.job.application.dealershipId
                });
            }



            return Ok(responses);
        }

    }
}