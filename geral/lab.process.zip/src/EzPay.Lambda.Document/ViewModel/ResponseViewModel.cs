﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Lambda.Document.ViewModel
{
    public class ResponseViewModel
    {
        public int dealerID { get; set; }
        public int requisitionID { get; set; }
        public string document { get; set; }
        public string description { get; set; }
        public string fileURL { get; set; }
        public string value { get; set; }
        public string barCode { get; set; }
        public DateTime datePay { get; set; }
        public DateTime dateProcess { get; set; }
        public DateTime dateSend { get; set; }
    }
}
