﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Lambda.Document.ViewModel
{
    public class RequestViewModel
    {
        public int DealerId { get; set; }
        public int RequisitionID { get; set; }
        public string Document { get; set; }
        public DateTime DateRequisition { get; set; }
    }
}
