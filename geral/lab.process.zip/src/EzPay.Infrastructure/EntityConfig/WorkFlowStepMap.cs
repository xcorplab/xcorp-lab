﻿using EzPay.ApplicationCore.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Infrastructure.EntityConfig
{
    public class WorkFlowStepMap : IEntityTypeConfiguration<WorkFlowStep>
    {
        public void Configure(EntityTypeBuilder<WorkFlowStep> builder)
        {
            //builder.HasKey(ws => new { ws., ws. });

            builder.HasKey(ws => new { ws.workFlowId, ws.stepId });
            
            
            //builder.HasMany(w => w.steps)
            //        .WithMany(w => w.jobs)
            //        .HasForeignKey(j => j.applicationId)
            //        .HasPrincipalKey(j => j.applicationId);



        }
    }
}
