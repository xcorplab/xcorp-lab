﻿using EzPay.ApplicationCore.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Infrastructure.EntityConfig
{
    public class InputMap : IEntityTypeConfiguration<Input>
    {
        public void Configure(EntityTypeBuilder<Input> builder)
        {
            builder.HasKey(i => i.inputId);

            builder.HasOne(i => i.job)
                .WithMany(i => i.inputs)
                .HasForeignKey(i => i.jobId)
                .HasPrincipalKey(i => i.jobId);

            builder.Property(i => i.name)
                .HasColumnType("VARCHAR(200)")
                .IsRequired();

            builder.Property(i => i.hash)
                  .HasColumnType("VARCHAR(50)")
                  .IsRequired();

            builder.Property(i => i.size)
                 .HasColumnType("BIGINT(30)")
                 .IsRequired();

            builder.Property(i => i.secret)
                  .HasColumnType("VARCHAR(300)")
                  .IsRequired();

            builder.Property(j => j.statusRow)
                 .HasColumnType("INT(11)")
                 .IsRequired();

            builder.Property(j => j.created)
                .HasColumnType("DATETIME")
                .IsRequired();

            builder.Property(j => j.updated)
                .HasColumnType("DATETIME")
                .HasDefaultValue(null);
        }
    }
}
