﻿using EzPay.ApplicationCore.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Infrastructure.EntityConfig
{
    public class WorkFlowMap : IEntityTypeConfiguration<WorkFlow>
    {
        public void Configure(EntityTypeBuilder<WorkFlow> builder)
        {
            builder.HasKey(w => w.workFlowId);

            builder.Property(w => w.applicationId)
                  .HasColumnType("INT(11)")
                  .IsRequired();

            //builder.Property(w => w.jobId)
            //      .HasColumnType("INT(11)")
            //      .IsRequired();

        }
    }
}
