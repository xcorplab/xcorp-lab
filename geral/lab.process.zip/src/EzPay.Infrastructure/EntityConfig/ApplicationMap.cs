﻿using EzPay.ApplicationCore.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Net.Mime;
using System.Text;

namespace EzPay.Infrastructure.EntityConfig
{
    public class ApplicationMap : IEntityTypeConfiguration<Application>
    {
        public void Configure(EntityTypeBuilder<Application> builder)
        {
            builder.HasKey(a => a.applicationId);

            builder.HasOne(a => a.client)
                .WithMany(a => a.applications)
                .HasForeignKey(a => a.clientId)
                .HasPrincipalKey(a => a.clientId);

            builder.HasOne(a => a.dealership)
                .WithMany(a => a.applications)
                .HasForeignKey(a => a.dealershipId)
                .HasPrincipalKey(a => a.dealershipId);

            builder.Property(a => a.name)
               .HasColumnType("VARCHAR(200)")
               .IsRequired();

            builder.Property(a => a.hash)
               .HasColumnType("VARCHAR(50)")
               .IsRequired();

            builder.Property(j => j.daysExpiration)
                   .HasColumnType("INT(11)")
                   .IsRequired();
        }
    }
}
