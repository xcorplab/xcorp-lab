﻿using EzPay.ApplicationCore.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Infrastructure.EntityConfig
{
    public class JobMap : IEntityTypeConfiguration<Job>
    {
        public void Configure(EntityTypeBuilder<Job> builder)
        {
            builder.HasKey(j => j.jobId);

            builder.HasOne(j => j.application)
                    .WithMany(j => j.jobs)
                    .HasForeignKey(j => j.applicationId)
                    .HasPrincipalKey(j => j.applicationId);

            builder.HasMany(j => j.historyJobs)
                    .WithOne(j => j.job)
                    .HasForeignKey(j => j.jobId)
                    .HasPrincipalKey(j => j.jobId);

            builder.HasMany(j => j.inputs)
                  .WithOne(j => j.job)
                  .HasForeignKey(j => j.jobId)
                  .HasPrincipalKey(j => j.jobId);

            builder.HasMany(j => j.documents)
                  .WithOne(j => j.job)
                  .HasForeignKey(j => j.jobId)
                  .HasPrincipalKey(j => j.jobId);

            builder.HasMany(j => j.processes)
               .WithOne(j => j.job)
               .HasForeignKey(j => j.jobId)
               .HasPrincipalKey(j => j.jobId);

            builder.Property(j => j.hash)
                    .HasColumnType("VARCHAR(50)")
                    .IsRequired();

            builder.Property(j => j.aggregateName)
                   .HasColumnType("VARCHAR(100)")
                   .IsRequired();

            builder.Property(j => j.expiration)
                   .HasColumnType("DATETIME")
                   .IsRequired();

            builder.Property(j => j.startDate)
                .HasColumnType("DATETIME")
                .HasDefaultValue(null);

            builder.Property(j => j.created)
                   .HasColumnType("DATETIME")
                   .IsRequired();

            builder.Property(j => j.statusRow)
                  .HasColumnType("INT(11)")
                  .IsRequired();

            builder.Property(j => j.endDate)
                    .HasColumnType("DATETIME")
                    .HasDefaultValue(null);

            builder.Property(j => j.updated)
                    .HasColumnType("DATETIME")
                    .HasDefaultValue(null);
        }
    }
}
