﻿using EzPay.ApplicationCore.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Infrastructure.EntityConfig
{
    public class CommandMap : IEntityTypeConfiguration<Command>
    {
        public void Configure(EntityTypeBuilder<Command> builder)
        {
            builder.HasKey(c => c.commandId);

            builder.Property(c => c.stepId)
                    .HasColumnType("INT(11)")
                    .IsRequired();

            builder.Property(c => c.value)
                    .HasColumnType("VARCHAR(300)")
                    .IsRequired();
        }
    }
}
