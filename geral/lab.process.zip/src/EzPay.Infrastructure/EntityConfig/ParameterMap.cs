﻿using EzPay.ApplicationCore.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Infrastructure.EntityConfig
{
    public class ParameterMap : IEntityTypeConfiguration<Parameter>
    {
        public void Configure(EntityTypeBuilder<Parameter> builder)
        {
            builder.HasKey(p => p.parameterId);

            builder.HasOne(w => w.workFlow)
                  .WithMany(w => w.parameters)
                  .HasForeignKey(j => j.workFlowId);

            builder.Property(p => p.name)
                  .HasColumnType("VARCHAR(100)")
                  .IsRequired();

            builder.Property(p => p.value)
                  .HasColumnType("VARCHAR(200)")
                  .IsRequired();
        }
    }
}
