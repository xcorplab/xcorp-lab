﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Entity.EzPay;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Infrastructure.EntityConfig
{
    public class DealershipMap : IEntityTypeConfiguration<Dealership>
    {
        public void Configure(EntityTypeBuilder<Dealership> builder)
        {
            builder.HasKey(i => i.dealershipId);

            builder.Property(i => i.name)
                .HasColumnType("VARCHAR(60)")
                .IsRequired();

            builder.Property(i => i.created)
                  .HasColumnType("DATETIME")
                  .IsRequired();
        }
    }
}
