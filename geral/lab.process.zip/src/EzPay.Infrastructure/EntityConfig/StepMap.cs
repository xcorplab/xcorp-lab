﻿using EzPay.ApplicationCore.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Infrastructure.EntityConfig
{
    public class StepMap : IEntityTypeConfiguration<Step>
    {
        public void Configure(EntityTypeBuilder<Step> builder)
        {
            builder.HasKey(s => s.stepId);

            builder.Property(s => s.name)
                   .HasColumnType("VARCHAR(100)")
                   .IsRequired();

            builder.Property(s => s.jobQueue)
                  .HasColumnType("VARCHAR(100)")
                  .IsRequired();

            builder.Property(s => s.jobName)
                  .HasColumnType("VARCHAR(100)")
                  .IsRequired();

            builder.Property(s => s.jobDefinition)
                  .HasColumnType("VARCHAR(100)")
                  .IsRequired();

            //builder.Property(j => j.start)
            //   .HasColumnType("DATETIME")
            //   .HasDefaultValue(null);

            //builder.Property(j => j.end)
            //   .HasColumnType("DATETIME")
            //   .HasDefaultValue(null);
        }
    }
}
