﻿using EzPay.ApplicationCore.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Infrastructure.EntityConfig
{
    public class ClientMap : IEntityTypeConfiguration<Client>
    {
        public void Configure(EntityTypeBuilder<Client> builder)
        {

            builder.HasKey(c => c.clientId);

            builder.HasMany(c => c.applications)
                .WithOne(c => c.client)
                .HasForeignKey(c => c.clientId)
                .HasPrincipalKey(c => c.clientId);

            builder.Property(c => c.name)
                .HasColumnType("VARCHAR(200)")
                .IsRequired();

            builder.Property(c => c.hash)
               .HasColumnType("VARCHAR(50)")
               .IsRequired();

        }
    }
}
