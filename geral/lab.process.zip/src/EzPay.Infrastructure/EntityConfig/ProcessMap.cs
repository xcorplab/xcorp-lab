﻿using EzPay.ApplicationCore.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Infrastructure.EntityConfig
{
    public class ProcessMap : IEntityTypeConfiguration<Process>
    {
        public void Configure(EntityTypeBuilder<Process> builder)
        {
            builder.HasKey(p => p.processId);

            builder.Property(p => p.jobId)
                 .HasColumnType("INT(11)")
                 .IsRequired();

            builder.Property(p => p.stepId)
                 .HasColumnType("INT(11)")
                 .IsRequired();

            builder.Property(p => p.identifier)
                   .HasColumnType("VARCHAR(150)")
                   .IsRequired();

            builder.Property(p => p.created)
                  .HasColumnType("DATETIME")
                  .IsRequired();
        }
    }
}
