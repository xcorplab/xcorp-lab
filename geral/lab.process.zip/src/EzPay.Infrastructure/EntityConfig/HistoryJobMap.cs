﻿using EzPay.ApplicationCore.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Infrastructure.EntityConfig
{
    class HistoryJobMap : IEntityTypeConfiguration<HistoryJob>
    {
        public void Configure(EntityTypeBuilder<HistoryJob> builder)
        {
            builder.HasKey(h => h.historyJobId);

            builder.HasOne(h => h.job)
                .WithMany(h => h.historyJobs)
                .HasForeignKey(h => h.jobId)
                .HasPrincipalKey(h => h.jobId);

            builder.Property(h => h.info)
                .HasColumnType("VARCHAR(200)")
                .IsRequired();

            builder.Property(h => h.level)
               .HasColumnType("VARCHAR(30)")
               .IsRequired();

            builder.Property(h => h.source)
              .HasColumnType("VARCHAR(200)")
              .IsRequired();

            builder.Property(h => h.created)
              .HasColumnType("DATETIME")
              .IsRequired();
        }
    }
}
