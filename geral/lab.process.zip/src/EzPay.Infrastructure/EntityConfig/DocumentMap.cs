﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Entity.EzPay;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Net.Mime;
using System.Text;

namespace EzPay.Infrastructure.EntityConfig
{
    public class DocumentMap : IEntityTypeConfiguration<Document>
    {
        public void Configure(EntityTypeBuilder<Document> builder)
        {

            builder.HasKey(d => d.documentId);

            builder.HasOne(d => d.job)
                .WithMany(d => d.documents)
                .HasForeignKey(d => d.jobId)
                .HasPrincipalKey(d => d.jobId);

            builder.Property(d => d.jobId)
               .HasColumnType("INT(11)")
               .IsRequired();

            builder.Property(d => d.identifier)
               .HasColumnType("VARCHAR(60)")
               .IsRequired();

            builder.Property(d => d.name)
                   .HasColumnType("VARCHAR(200)")
                   .IsRequired();

            builder.Property(d => d.file)
                   .HasColumnType("VARCHAR(200)")
                   .IsRequired();

            builder.Property(d => d.value)
                   .HasColumnType("VARCHAR(60)")
                   .IsRequired();

            builder.Property(d => d.barCode)
                .HasColumnType("VARCHAR(100)")
                .IsRequired();

            builder.Property(d => d.dueDateInvoice)
                   .HasColumnType("DATETIME")
                   .IsRequired();

            builder.Property(d => d.paymentStatus)
                   .HasColumnType("INT(11)")
                   .IsRequired();

            builder.Property(d => d.payDate)
                   .HasColumnType("DATETIME")
                   .HasDefaultValue(null);

            builder.Property(d => d.statusRow)
                  .HasColumnType("INT(11)")
                  .IsRequired();

            builder.Property(d => d.created)
                   .HasColumnType("DATETIME")
                   .IsRequired();

            builder.Property(d => d.updated)
                .HasColumnType("DATETIME")
                .HasDefaultValue(null);


        }
    }
}