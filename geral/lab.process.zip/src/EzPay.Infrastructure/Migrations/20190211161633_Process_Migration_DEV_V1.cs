﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace EzPay.Infrastructure.Migrations
{
    public partial class Process_Migration_DEV_V1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Client",
                columns: table => new
                {
                    clientId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    name = table.Column<string>(type: "VARCHAR(200)", nullable: false),
                    hash = table.Column<string>(type: "VARCHAR(50)", nullable: false),
                    statusRow = table.Column<int>(nullable: false),
                    created = table.Column<DateTime>(nullable: false),
                    updated = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Client", x => x.clientId);
                });

            migrationBuilder.CreateTable(
                name: "Dealership",
                columns: table => new
                {
                    dealershipId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    name = table.Column<string>(type: "VARCHAR(60)", nullable: false),
                    image = table.Column<string>(nullable: true),
                    created = table.Column<DateTime>(type: "DATETIME", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Dealership", x => x.dealershipId);
                });

            migrationBuilder.CreateTable(
                name: "Status",
                columns: table => new
                {
                    statusId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    name = table.Column<string>(nullable: true),
                    created = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Status", x => x.statusId);
                });

            migrationBuilder.CreateTable(
                name: "Step",
                columns: table => new
                {
                    stepId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    name = table.Column<string>(type: "VARCHAR(100)", nullable: false),
                    jobQueue = table.Column<string>(type: "VARCHAR(100)", nullable: false),
                    jobName = table.Column<string>(type: "VARCHAR(100)", nullable: false),
                    jobDefinition = table.Column<string>(type: "VARCHAR(100)", nullable: false),
                    created = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Step", x => x.stepId);
                });

            migrationBuilder.CreateTable(
                name: "Application",
                columns: table => new
                {
                    applicationId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    clientId = table.Column<int>(nullable: false),
                    dealershipId = table.Column<int>(nullable: false),
                    name = table.Column<string>(type: "VARCHAR(200)", nullable: false),
                    hash = table.Column<string>(type: "VARCHAR(50)", nullable: false),
                    daysExpiration = table.Column<int>(type: "INT(11)", nullable: false),
                    statusRow = table.Column<int>(nullable: false),
                    created = table.Column<DateTime>(nullable: false),
                    updated = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Application", x => x.applicationId);
                    table.ForeignKey(
                        name: "FK_Application_Client_clientId",
                        column: x => x.clientId,
                        principalTable: "Client",
                        principalColumn: "clientId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Application_Dealership_dealershipId",
                        column: x => x.dealershipId,
                        principalTable: "Dealership",
                        principalColumn: "dealershipId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Command",
                columns: table => new
                {
                    commandId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    stepId = table.Column<int>(type: "INT(11)", nullable: false),
                    value = table.Column<string>(type: "VARCHAR(300)", nullable: false),
                    created = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Command", x => x.commandId);
                    table.ForeignKey(
                        name: "FK_Command_Step_stepId",
                        column: x => x.stepId,
                        principalTable: "Step",
                        principalColumn: "stepId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Job",
                columns: table => new
                {
                    jobId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    applicationId = table.Column<int>(nullable: false),
                    statusId = table.Column<int>(nullable: false),
                    aggregateName = table.Column<string>(type: "VARCHAR(100)", nullable: false),
                    hash = table.Column<string>(type: "VARCHAR(50)", nullable: false),
                    startDate = table.Column<DateTime>(type: "DATETIME", nullable: true),
                    endDate = table.Column<DateTime>(type: "DATETIME", nullable: true),
                    expiration = table.Column<DateTime>(type: "DATETIME", nullable: false),
                    statusRow = table.Column<int>(type: "INT(11)", nullable: false),
                    created = table.Column<DateTime>(type: "DATETIME", nullable: false),
                    updated = table.Column<DateTime>(type: "DATETIME", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Job", x => x.jobId);
                    table.ForeignKey(
                        name: "FK_Job_Application_applicationId",
                        column: x => x.applicationId,
                        principalTable: "Application",
                        principalColumn: "applicationId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Job_Status_statusId",
                        column: x => x.statusId,
                        principalTable: "Status",
                        principalColumn: "statusId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "WorkFlow",
                columns: table => new
                {
                    workFlowId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    applicationId = table.Column<int>(type: "INT(11)", nullable: false),
                    created = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WorkFlow", x => x.workFlowId);
                    table.ForeignKey(
                        name: "FK_WorkFlow_Application_applicationId",
                        column: x => x.applicationId,
                        principalTable: "Application",
                        principalColumn: "applicationId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Document",
                columns: table => new
                {
                    documentId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    jobId = table.Column<int>(type: "INT(11)", nullable: false),
                    identifier = table.Column<string>(type: "VARCHAR(60)", nullable: false),
                    name = table.Column<string>(type: "VARCHAR(200)", nullable: false),
                    file = table.Column<string>(type: "VARCHAR(200)", nullable: false),
                    value = table.Column<string>(type: "VARCHAR(60)", nullable: false),
                    barCode = table.Column<string>(type: "VARCHAR(100)", nullable: false),
                    paymentStatus = table.Column<int>(type: "INT(11)", nullable: false),
                    payDate = table.Column<DateTime>(type: "DATETIME", nullable: false),
                    statusRow = table.Column<int>(type: "INT(11)", nullable: false),
                    created = table.Column<DateTime>(type: "DATETIME", nullable: false),
                    updated = table.Column<DateTime>(type: "DATETIME", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Document", x => x.documentId);
                    table.ForeignKey(
                        name: "FK_Document_Job_jobId",
                        column: x => x.jobId,
                        principalTable: "Job",
                        principalColumn: "jobId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "HistoryJob",
                columns: table => new
                {
                    historyJobId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    jobId = table.Column<int>(nullable: false),
                    info = table.Column<string>(type: "VARCHAR(200)", nullable: false),
                    level = table.Column<string>(type: "VARCHAR(30)", nullable: false),
                    source = table.Column<string>(type: "VARCHAR(200)", nullable: false),
                    created = table.Column<DateTime>(type: "DATETIME", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HistoryJob", x => x.historyJobId);
                    table.ForeignKey(
                        name: "FK_HistoryJob_Job_jobId",
                        column: x => x.jobId,
                        principalTable: "Job",
                        principalColumn: "jobId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Input",
                columns: table => new
                {
                    inputId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    jobId = table.Column<int>(nullable: false),
                    hash = table.Column<string>(type: "VARCHAR(50)", nullable: false),
                    name = table.Column<string>(type: "VARCHAR(200)", nullable: false),
                    size = table.Column<long>(type: "BIGINT(30)", nullable: false),
                    secret = table.Column<string>(type: "VARCHAR(300)", nullable: false),
                    statusRow = table.Column<int>(type: "INT(11)", nullable: false),
                    created = table.Column<DateTime>(type: "DATETIME", nullable: false),
                    updated = table.Column<DateTime>(type: "DATETIME", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Input", x => x.inputId);
                    table.ForeignKey(
                        name: "FK_Input_Job_jobId",
                        column: x => x.jobId,
                        principalTable: "Job",
                        principalColumn: "jobId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Process",
                columns: table => new
                {
                    processId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    jobId = table.Column<int>(type: "INT(11)", nullable: false),
                    stepId = table.Column<int>(type: "INT(11)", nullable: false),
                    identifier = table.Column<string>(type: "VARCHAR(150)", nullable: false),
                    created = table.Column<DateTime>(type: "DATETIME", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Process", x => x.processId);
                    table.ForeignKey(
                        name: "FK_Process_Job_jobId",
                        column: x => x.jobId,
                        principalTable: "Job",
                        principalColumn: "jobId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Parameter",
                columns: table => new
                {
                    parameterId = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    workFlowId = table.Column<int>(nullable: false),
                    name = table.Column<string>(type: "VARCHAR(100)", nullable: false),
                    value = table.Column<string>(type: "VARCHAR(200)", nullable: false),
                    created = table.Column<DateTime>(nullable: false),
                    updated = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Parameter", x => x.parameterId);
                    table.ForeignKey(
                        name: "FK_Parameter_WorkFlow_workFlowId",
                        column: x => x.workFlowId,
                        principalTable: "WorkFlow",
                        principalColumn: "workFlowId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "WorkFlowStep",
                columns: table => new
                {
                    workFlowId = table.Column<int>(nullable: false),
                    stepId = table.Column<int>(nullable: false),
                    order = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WorkFlowStep", x => new { x.workFlowId, x.stepId });
                    table.ForeignKey(
                        name: "FK_WorkFlowStep_Step_stepId",
                        column: x => x.stepId,
                        principalTable: "Step",
                        principalColumn: "stepId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_WorkFlowStep_WorkFlow_workFlowId",
                        column: x => x.workFlowId,
                        principalTable: "WorkFlow",
                        principalColumn: "workFlowId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Application_clientId",
                table: "Application",
                column: "clientId");

            migrationBuilder.CreateIndex(
                name: "IX_Application_dealershipId",
                table: "Application",
                column: "dealershipId");

            migrationBuilder.CreateIndex(
                name: "IX_Command_stepId",
                table: "Command",
                column: "stepId");

            migrationBuilder.CreateIndex(
                name: "IX_Document_jobId",
                table: "Document",
                column: "jobId");

            migrationBuilder.CreateIndex(
                name: "IX_HistoryJob_jobId",
                table: "HistoryJob",
                column: "jobId");

            migrationBuilder.CreateIndex(
                name: "IX_Input_jobId",
                table: "Input",
                column: "jobId");

            migrationBuilder.CreateIndex(
                name: "IX_Job_applicationId",
                table: "Job",
                column: "applicationId");

            migrationBuilder.CreateIndex(
                name: "IX_Job_statusId",
                table: "Job",
                column: "statusId");

            migrationBuilder.CreateIndex(
                name: "IX_Parameter_workFlowId",
                table: "Parameter",
                column: "workFlowId");

            migrationBuilder.CreateIndex(
                name: "IX_Process_jobId",
                table: "Process",
                column: "jobId");

            migrationBuilder.CreateIndex(
                name: "IX_WorkFlow_applicationId",
                table: "WorkFlow",
                column: "applicationId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_WorkFlowStep_stepId",
                table: "WorkFlowStep",
                column: "stepId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Command");

            migrationBuilder.DropTable(
                name: "Document");

            migrationBuilder.DropTable(
                name: "HistoryJob");

            migrationBuilder.DropTable(
                name: "Input");

            migrationBuilder.DropTable(
                name: "Parameter");

            migrationBuilder.DropTable(
                name: "Process");

            migrationBuilder.DropTable(
                name: "WorkFlowStep");

            migrationBuilder.DropTable(
                name: "Job");

            migrationBuilder.DropTable(
                name: "Step");

            migrationBuilder.DropTable(
                name: "WorkFlow");

            migrationBuilder.DropTable(
                name: "Status");

            migrationBuilder.DropTable(
                name: "Application");

            migrationBuilder.DropTable(
                name: "Client");

            migrationBuilder.DropTable(
                name: "Dealership");
        }
    }
}
