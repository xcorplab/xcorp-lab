﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace EzPay.Infrastructure.Migrations
{
    public partial class Process_Migration_DEV_V2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "dueDateInvoice",
                table: "Document",
                type: "DATETIME",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "dueDateInvoice",
                table: "Document");
        }
    }
}
