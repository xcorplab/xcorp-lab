﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using System;
using System.Collections.Generic;
using System.Text;

namespace EzPay.Infrastructure.Data
{
    public class EzPayContextFactory : IDesignTimeDbContextFactory<EzPayContext>
    {
        public EzPayContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<EzPayContext>();
            return new EzPayContext(optionsBuilder.Options);
        }
    }
}
