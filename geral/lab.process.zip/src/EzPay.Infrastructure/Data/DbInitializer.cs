﻿using EzPay.ApplicationCore.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EzPay.Infrastructure.Data
{
    public static class DbInitializer
    {
        public static void Initialize(EzPayContext context)
        {

            if (context.Clients.Any())
                return;

            var clients = new Client[]
            {
                new Client
                {
                    created = DateTime.Now,
                    hash = "0be43f70-74e9-47f4-954c-a0100c68ed0c",
                    name = "PrintLaser",
                    statusRow = 1,
                    updated = DateTime.Now
                }
            };

            context.AddRange(clients);

            var applications = new Application[]
            {
                new Application
                {
                    created = DateTime.Now,
                    hash = "b830c185-d8ff-4507-82ae-84f092b742dc",
                    name = "Fatura",
                    statusRow = 1,
                    client = clients[0],
                    updated = DateTime.Now
                }
            };

            context.AddRange(applications);

            context.SaveChanges();

        }

    }
}
