﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Entity.EzPay;
using EzPay.ApplicationCore.Interfaces.Services.Common;
using EzPay.Commons.Repository;
using EzPay.Infrastructure.EntityConfig;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace EzPay.Infrastructure.Data
{
    public class EzPayContext : DbContext
    {
        public EzPayContext(DbContextOptions<EzPayContext> options) : base(options)
        {
          
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //optionsBuilder.UseMySql(new SecretRepository().GetSecret("connection")["aurora-ezpay-connection"]);
            optionsBuilder.UseMySql(new SecretRepository().GetSecret("connection")["aurora-ezpay-process-connection"]);
            optionsBuilder.EnableSensitiveDataLogging(true);
        }

        public DbSet<Client> Clients { get; set; }
        public DbSet<Application> Applications { get; set; }
        public DbSet<HistoryJob> HistoryJobs { get; set; }
        public DbSet<Input> Inputs { get; set; }
        public DbSet<Job> Jobs { get; set; }
        public DbSet<Step> Steps { get; set; }
        public DbSet<WorkFlow> WorkFlows { get; set; }
        public DbSet<Parameter> Parameters { get; set; }
        public DbSet<Command> Commands { get; set; }
        public DbSet<WorkFlowStep> WorkFlowSteps { get; set; }
        public DbSet<Process> Processes { get; set; }
        public DbSet<Document> Documents { get; set; }
        public DbSet<Dealership> Dealerships { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Client>().ToTable("Client");
            modelBuilder.Entity<Application>().ToTable("Application");
            modelBuilder.Entity<HistoryJob>().ToTable("HistoryJob");
            modelBuilder.Entity<Input>().ToTable("Input");
            modelBuilder.Entity<Job>().ToTable("Job");
            modelBuilder.Entity<Step>().ToTable("Step")
                .Ignore(s => s.order)
                .Ignore(s => s.status)
                .Ignore(s => s.start)
                .Ignore(s => s.end);
            modelBuilder.Entity<WorkFlow>().ToTable("WorkFlow");
            modelBuilder.Entity<Parameter>().ToTable("Parameter");
            modelBuilder.Entity<Command>().ToTable("Command");
            modelBuilder.Entity<WorkFlowStep>().ToTable("WorkFlowStep");
            modelBuilder.Entity<Process>().ToTable("Process");
            modelBuilder.Entity<Document>().ToTable("Document");
            modelBuilder.Entity<Dealership>().ToTable("Dealership");

            modelBuilder.ApplyConfiguration(new ClientMap());
            modelBuilder.ApplyConfiguration(new ApplicationMap());
            modelBuilder.ApplyConfiguration(new JobMap());
            modelBuilder.ApplyConfiguration(new HistoryJobMap());
            modelBuilder.ApplyConfiguration(new InputMap());
            modelBuilder.ApplyConfiguration(new StepMap());
            modelBuilder.ApplyConfiguration(new WorkFlowMap());
            modelBuilder.ApplyConfiguration(new WorkFlowStepMap());
            modelBuilder.ApplyConfiguration(new ParameterMap());
            modelBuilder.ApplyConfiguration(new CommandMap());
            modelBuilder.ApplyConfiguration(new ProcessMap());
            modelBuilder.ApplyConfiguration(new DocumentMap());
            modelBuilder.ApplyConfiguration(new DealershipMap());
        }
    }
}
