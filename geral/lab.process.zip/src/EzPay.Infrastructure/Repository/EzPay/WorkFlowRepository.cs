﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.Infrastructure.Repository
{
    public class WorkFlowRepository : EFRepository<WorkFlow>, IWorkFlowRepository
    {
        public WorkFlowRepository(EzPayContext context) : base(context)
        {

        }

        public IEnumerable<WorkFlow> find(Expression<Func<WorkFlow, bool>> expression)
        {
            throw new NotImplementedException();
        }

        public WorkFlow findById(int workFlowId)
        {
            return _dbContext.WorkFlows
                .Include(workFlow => workFlow.parameters)
                .Include(workFlow => workFlow.workFlowSteps)
                    .ThenInclude(workFlowSteps => workFlowSteps.step)
                    .ThenInclude(step => step.commands)
                .AsNoTracking()
                .Where(c => c.workFlowId == workFlowId).FirstOrDefault();
        }

        public WorkFlow Insert(WorkFlow entity)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<WorkFlow> InsertMany(IEnumerable<WorkFlow> entity)
        {
            throw new NotImplementedException();
        }

        public void Update(WorkFlow entity)
        {
            throw new NotImplementedException();
        }

        IEnumerable<WorkFlow> IEzPayRepository<WorkFlow>.SelectAll()
        {
            throw new NotImplementedException();
        }
    }
}
