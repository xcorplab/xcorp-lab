﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EzPay.Infrastructure.Repository
{
    public class ApplicationRepository : EFRepository<Application>, IApplicationRepository
    {
        public ApplicationRepository(EzPayContext context) : base(context)
        {

        }

        public Application SelectByHash(string hash)
        {
            return _dbContext.Applications
                .Include(application => application.client)
                .AsNoTracking()
                .Where(c => c.hash == hash).FirstOrDefault();
        }
    }
}
