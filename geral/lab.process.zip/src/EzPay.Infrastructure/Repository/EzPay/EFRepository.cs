﻿using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace EzPay.Infrastructure.Repository
{
    public class EFRepository<TEntity> : IEzPayRepository<TEntity> where TEntity : class
    {
        protected readonly EzPayContext _dbContext;

        public EFRepository(EzPayContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IEnumerable<TEntity> find(Expression<Func<TEntity, bool>> expression)
        {
            return _dbContext.Set<TEntity>().Where(expression).AsEnumerable();
        }

        public virtual TEntity Insert(TEntity entity)
        {
            _dbContext.Set<TEntity>().Add(entity);
            _dbContext.SaveChanges();
            return entity;
        }

        public IEnumerable<TEntity> InsertMany(IEnumerable<TEntity> entity)
        {
            _dbContext.Set<TEntity>().AddRange(entity);
            _dbContext.SaveChanges();
            return entity;
        }

        public IEnumerable<TEntity> SelectAll()
        {
            return _dbContext.Set<TEntity>().AsEnumerable();
        }

        public virtual void Update(TEntity entity)
        {
            _dbContext.Entry(entity).State = EntityState.Modified;
            _dbContext.SaveChanges();
        }

        public virtual void DeleteMany(IEnumerable<TEntity> entities)
        {
            _dbContext.RemoveRange(entities);
            _dbContext.SaveChanges();
        }
    }
}
