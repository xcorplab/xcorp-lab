﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EzPay.Infrastructure.Repository
{
    public class HistoryJobRepository : EFRepository<HistoryJob>, IHistoryJobRepository
    {
        public HistoryJobRepository(EzPayContext context) : base(context)
        {

        }

    }
}
