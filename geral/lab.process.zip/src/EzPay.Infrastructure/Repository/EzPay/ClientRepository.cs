﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EzPay.Infrastructure.Repository
{
    public class ClientRepository : EFRepository<Client>, IClientRepository
    {
        public ClientRepository(EzPayContext context) : base(context)
        {

        }

        public Client SelectByHash(string hash)
        {
            return _dbContext.Clients
                .Include(client => client.applications)
                .AsNoTracking()
                .Where(c => c.hash == hash).FirstOrDefault();
        }
    }
}
