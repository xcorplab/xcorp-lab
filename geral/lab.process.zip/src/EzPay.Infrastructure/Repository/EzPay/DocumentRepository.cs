﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Entity.EzPay;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EzPay.Infrastructure.Repository
{
    public class DocumentRepository : EFRepository<Document>, IDocumentRepository
    {
        public DocumentRepository(EzPayContext context) : base(context)
        {

        }

        public IEnumerable<Document> SelectByIdentifier(string identifier)
        {
            return _dbContext.Documents
                .Include(client => client.job)
                    .ThenInclude(job => job.application)
                    .ThenInclude(application => application.client)
                .Include(client => client.job)
                    .ThenInclude(job => job.application)
                    .ThenInclude(application => application.dealership)
                .AsNoTracking()
                .Where(d => d.identifier == identifier);
        }

        public IEnumerable<Document> SelectPaidByIdentifier(string identifier)
        {
            return _dbContext.Documents
                .Include(client => client.job)
                    .ThenInclude(job => job.application)
                    .ThenInclude(application => application.client)
                .Include(client => client.job)
                    .ThenInclude(job => job.application)
                    .ThenInclude(application => application.dealership)
                .AsNoTracking()
                .Where(d => d.identifier == identifier && d.paymentStatus != 0);
        }
        public IEnumerable<Document> SelectUnpaidByIdentifier(string identifier)
        {
            return _dbContext.Documents
                .Include(client => client.job)
                    .ThenInclude(job => job.application)
                    .ThenInclude(application => application.client)
                .Include(client => client.job)
                    .ThenInclude(job => job.application)
                    .ThenInclude(application => application.dealership)
                .AsNoTracking()
                .Where(d => d.identifier == identifier && d.paymentStatus == 0);
        }

        public Document SelectById(int documentId)
        {
            return _dbContext.Documents
                .Include(client => client.job)
                    .ThenInclude(job => job.application)
                    .ThenInclude(application => application.dealership)
                .AsNoTracking()
                .Where(w => w.documentId == documentId).FirstOrDefault();
        }

        public IEnumerable<Document> SelectByIdRange(int documentId,int size)
        {

            return _dbContext.Documents
                .Include(client => client.job)
                    .ThenInclude(job => job.application)
                    .ThenInclude(application => application.client)
                .Include(client => client.job)
                    .ThenInclude(job => job.application)
                    .ThenInclude(application => application.dealership)
                .AsNoTracking()
                .Where(d => d.documentId > documentId && d.paymentStatus == 0 && d.statusRow==1).Take(size)
                .OrderBy(o=>o.documentId);
        }
    }
}
