﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EzPay.Infrastructure.Repository
{
    public class ProcessRepository : EFRepository<Process>, IProcessRepository
    {
        public ProcessRepository(EzPayContext context) : base(context)
        {

        }

        public Process SelectByIdentificador(string identificador)
        {
            return _dbContext.Processes
                .Include(job => job)
                .AsNoTracking()
                .Where(p => p.identifier == identificador).FirstOrDefault();
        }
    }
}
