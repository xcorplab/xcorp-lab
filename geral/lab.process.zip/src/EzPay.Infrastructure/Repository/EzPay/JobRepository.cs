﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EzPay.Infrastructure.Repository
{
    public class JobRepository : EFRepository<Job>, IJobRepository
    {
        public JobRepository(EzPayContext context) : base(context)
        {

        }

        public Job SelectByHash(string hash)
        {
            return _dbContext.Jobs
                .Include(job => job.application)
                    .ThenInclude(application => application.client)
                //.Include(job => job.historyJobs)
                .Include(job => job.inputs)
                //.Include(job => job.status)
                .Include(job => job.application.workFlow)
                    .ThenInclude(workFlow => workFlow.workFlowSteps)
                .Include(job => job.processes)
                .AsNoTracking()
                .Where(c => c.hash == hash).FirstOrDefault();

            //return find(j => j.hash == hash).FirstOrDefault();
            //return _dbContext.Jobs.Where(j => j.hash == hash).FirstOrDefault();
        }

        public void Cancel(string hash)
        {
            Job job = SelectByHash(hash);
            job.statusRow = 2; //Cancelado
            Update(job);
            _dbContext.SaveChanges();
        }

        #region --Exemplo--

        //Insert Customizado/Especifico.
        public override Job Insert(Job entity)
        {
            string validacao = null;

            _dbContext.Set<Job>().Add(entity);
            _dbContext.SaveChanges();

            return entity;
        }

        #endregion
    }
}
