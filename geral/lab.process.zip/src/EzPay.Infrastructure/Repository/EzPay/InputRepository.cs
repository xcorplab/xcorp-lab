﻿using EzPay.ApplicationCore.Entity;
using EzPay.ApplicationCore.Interfaces.Repository;
using EzPay.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EzPay.Infrastructure.Repository
{
    public class InputRepository : EFRepository<Input>, IInputRepository
    {
        public InputRepository(EzPayContext context) : base(context)
        {

        }

        public void Cancel(string hash)
        {
            Input input = find(c => c.hash == hash).FirstOrDefault();
            input.statusRow = 2; //Cancelado
            Update(input);
            _dbContext.SaveChanges();
        }
    }
}
