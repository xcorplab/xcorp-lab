﻿using System;
using System.Collections.Generic;
using System.IO;
using Amazon;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using Newtonsoft.Json;

namespace pl.cmp.capture.Util
{
    public class Utility
    {

        public Dictionary<String, String> GetSecret(String secretName)
        {
            MemoryStream memoryStream = new MemoryStream();

            IAmazonSecretsManager client = new AmazonSecretsManagerClient(RegionEndpoint.SAEast1);

            GetSecretValueRequest request = new GetSecretValueRequest
            {
                SecretId = secretName,
                VersionStage = "AWSCURRENT"
            };

            try
            {
                return JsonConvert.DeserializeObject<Dictionary<string, string>>(client.GetSecretValueAsync(request).Result.SecretString);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
