﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pl.cmp.capture.Model
{
    public class Application
    {
        public Int32 IdApplication { get; set; }
        public Int32 IdAUCCMP { get; set; }
        public string filters { get; set; }
    }
}
