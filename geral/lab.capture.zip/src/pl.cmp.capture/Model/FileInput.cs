﻿using System;
using System.Collections.Generic;
using System.Text;

namespace pl.cmp.capture.Model
{
    public class FileInput
    {
        public Int32 IdFileInput { get; set; }
        public String Hash { get; set; }
        public String Name { get; set; }
        public String AggregateName { get; set; }
        public String SourceServer { get; set; }
        public String SourceFolder { get; set; }
        public String Password { get; set; }
        public Int32 StatusRow { get; set; }
        public DateTime Createdrow { get; set; }
        public DateTime Updatedrow { get; set; }

    }
}
