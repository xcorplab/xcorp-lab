﻿using System;
using System.Collections.Generic;
using Amazon.Lambda.Core;
using Amazon.Runtime;
using Amazon.SQS.Model;
using MySql.Data.MySqlClient;
using pl.cmp.capture.Model;
using pl.cmp.capture.Util;

namespace pl.cmp.capture.MySql
{
    public class Data
    {

        public void InputFiles(List<FileInput> inputs,ILambdaContext context)
        {

            MySqlTransaction mySqlTransaction = null;

            try
            {
                Utility utility = new Utility();

                Dictionary<String, String> dictConnection = utility.GetSecret("connection");
                String urlQueue = utility.GetSecret("queue")["pl-inputfile-in"];
                Dictionary<String, String> dictKeys = utility.GetSecret("key");
                BasicAWSCredentials awsCreds = new BasicAWSCredentials(dictKeys["access-key"], dictKeys["secret-key"]);
                Amazon.SQS.AmazonSQSClient amazonSQSClient = new Amazon.SQS.AmazonSQSClient(awsCreds, Amazon.RegionEndpoint.SAEast1);
                foreach (FileInput fileInput in inputs)
                {
                    using (MySqlConnection connection = new MySqlConnection(dictConnection["aurora-controlfile-connection"]))
                    {
                        connection.Open();

                        MySqlCommand command = new MySqlCommand($"select count(*) as Total from controlfile.FileInput where name='{fileInput.Name}' and aggregateName = '{fileInput.AggregateName}' and hash = '{fileInput.Hash}'  ", connection);

                        MySqlDataReader reader = command.ExecuteReader();
                        Int32 countRows = 0;
                        while (reader.Read())
                        {
                            countRows = reader.GetInt32(0);
                        }
                        reader.Close();
                        if (countRows < 1)
                        {
                            mySqlTransaction = connection.BeginTransaction();
                            command = new MySqlCommand($"INSERT INTO controlfile.FileInput (hash, name, aggregateName, sourceServer, sourceFolder,password,statusrow,createdrow,updatedrow) VALUES('{fileInput.Hash}', '{fileInput.Name}', '{fileInput.AggregateName}', '{fileInput.SourceServer}', '{fileInput.SourceFolder}','{fileInput.Password}',1,NOW(),NOW());SELECT LAST_INSERT_ID(); ", connection);
                            reader = command.ExecuteReader();
                            Int32 id = 0;
                            while (reader.Read())
                            {
                                id = reader.GetInt32(0);
                            }
                            reader.Close();
                            
                            SendMessageRequest sendMessageRequest = new SendMessageRequest
                            {
                                MessageBody = id.ToString(),
                                QueueUrl = urlQueue
                            };

                            var sendMessageResponse = amazonSQSClient.SendMessageAsync(sendMessageRequest).Result;
                            if (sendMessageResponse.HttpStatusCode != System.Net.HttpStatusCode.OK)
                            {
                                throw new Exception("Erro na gravação na fila");
                            }
                            mySqlTransaction.Commit();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (mySqlTransaction !=null)
                {
                    mySqlTransaction.Rollback();
                }
                throw ex;
            }


        }

        public List<Application> ListApplication(ILambdaContext context)
        {

            try
            {

                Utility utility = new Utility();
                List<Application> listApplication = new List<Application>();
                Dictionary<String, String> dictConnection = utility.GetSecret("connection");
                using (MySqlConnection connection = new MySqlConnection(dictConnection["aurora-controlfile-connection"]))
                {
                    connection.Open();

                    MySqlCommand command = new MySqlCommand($"select idApplication,idAUCCMP,filters from controlfile.Application where statusrow=1 ", connection);

                    MySqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        listApplication.Add(new Application
                        {
                            IdApplication = reader.GetInt32(0),
                            IdAUCCMP = reader.GetInt32(1),
                            filters = reader.IsDBNull(2) ? null : reader.GetString(2)
                        });
                    }
                    reader.Close();
                }
                return listApplication;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
