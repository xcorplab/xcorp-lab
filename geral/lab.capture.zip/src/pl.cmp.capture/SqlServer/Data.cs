﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using pl.cmp.capture.Model;
using pl.cmp.capture.Util;

namespace pl.cmp.capture.SqlServer
{
    public class Data
    {
        public List<FileInput> ListTarefa(Application application)
        {

            List<FileInput> files = new List<FileInput>();
            try
            {
                Utility utility = new Utility();
                Dictionary<String, String> dictConnection = utility.GetSecret("connection");

                using (SqlConnection connection = new SqlConnection(dictConnection["sqlserver-cmp-connection"]))
                {
                    connection.Open();
                    StringBuilder sb = new StringBuilder();
                    sb.Append("SELECT HASH,AGGREGATENAME,NAME,SOURCESERVER,SOURCEFOLDER, PASSWORD FROM ( ");
                    sb.Append("SELECT   CONVERT(NVARCHAR(32),hashbytes('MD5', REPLACE(ClienteERP.Nome,' ','') +  REPLACE(UnidadeCliente.Nome,' ','') + REPLACE(Aplicacao.Nome,' ','')),2) AS 'HASH',");
                    sb.Append("        CAST(Tarefa.idTarefa AS VARCHAR(10)) +'_' +   Tarefa.NomeCiclo AS 'AGGREGATENAME', ");
                    sb.Append("		ArquivoDados.Nome + IIF( ArquivoDados.SenhaCompactacao = '','','.7z' ) AS 'NAME', ");
                    sb.Append(@"		'FTP|&10.10.101.32|&21|&usrbkp|&3FcdMpUOZZV6Z' AS 'SOURCESERVER', ");
                    sb.Append("		'/' + CAST(ClienteERP.idClienteERP AS VARCHAR(10)) + '/' + CAST(UnidadeCliente.idUnidadeCliente AS VARCHAR(10)) + '/' ");
                    sb.Append("		    + CAST(AplicacaoUnidadeCliente.idAplicacaoUnidadeCliente AS VARCHAR(10)) + '/ciclo_' + CAST(Ciclo.idCiclo AS VARCHAR(10)) + '/' ");
                    sb.Append("			+ 'tarefa_' + CAST(Tarefa.idTarefa AS VARCHAR(10)) + '/' AS 'SOURCEFOLDER', ");
                    sb.Append("			ArquivoDados.SenhaCompactacao as 'PASSWORD' ");
                    sb.Append("FROM		tarefa					WITH(NOLOCK) ");
                    sb.Append("INNER JOIN	ciclo					WITH(NOLOCK) on ciclo.idCiclo = tarefa.idCiclo ");
                    sb.Append("INNER JOIN	AplicacaoUnidadeCliente WITH(NOLOCK) on AplicacaoUnidadeCliente.idAplicacaoUnidadeCliente = Ciclo.idAplicacaoUnidadeCliente ");
                    sb.Append("INNER JOIN	Aplicacao				WITH(NOLOCK) on Aplicacao.idAplicacao = AplicacaoUnidadeCliente.idAplicacao ");
                    sb.Append("INNER JOIN	UnidadeCliente			WITH(NOLOCK) on UnidadeCliente.idUnidadeCliente = AplicacaoUnidadeCliente.idUnidadeCliente ");
                    sb.Append("INNER JOIN	ClienteERP				WITH(NOLOCK) on ClienteERP.idClienteERP = UnidadeCliente.idClienteERP ");
                    sb.Append("INNER JOIN	ArquivoDados			WITH(NOLOCK) on ArquivoDados.idTarefa = Tarefa.idTarefa ");
                    sb.Append("INNER JOIN	Lote					WITH(NOLOCK) on lote.idTarefa = ArquivoDados.idTarefa ");
                    sb.Append("INNER JOIN	OrdemServico			WITH(NOLOCK) on OrdemServico.idOrdemServico = lote.idOrdemServico ");
                    sb.Append($"WHERE AplicacaoUnidadeCliente.idAplicacaoUnidadeCliente = {application.IdAUCCMP.ToString()} ");
                    sb.Append("AND tarefa.teste = 0 ");
                    sb.Append("AND lote.idOrdemServico IS NOT NULL ");
                    sb.Append("AND OrdemServico.DataOrdemServico > GETDATE()-25) AS TMP ");

                    sb.Append("GROUP BY HASH,AGGREGATENAME,NAME,SOURCESERVER,SOURCEFOLDER,PASSWORD");

                    using (SqlCommand command = new SqlCommand(sb.ToString(), connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                bool filterValid = false;

                                if (!string.IsNullOrEmpty(application.filters))
                                {
                                    foreach (var filter in application.filters.Split('#').ToList())
                                    {
                                        if (reader.GetString(2).Contains(filter))
                                            filterValid = true;
                                    }
                                }
                               

                                if (filterValid)
                                {
                                    files.Add(new FileInput
                                    {
                                        Hash = reader.GetString(0),
                                        AggregateName = reader.GetString(1),
                                        Name = reader.GetString(2),
                                        SourceServer = reader.GetString(3),
                                        SourceFolder = reader.GetString(4),
                                        Password = reader.GetString(5)
                                    });
                                }
                            }
                        }
                    }
                }
                return files;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
