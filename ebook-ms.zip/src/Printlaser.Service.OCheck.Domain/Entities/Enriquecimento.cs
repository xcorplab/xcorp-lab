﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Printlaser.Service.OCheck.Domain.Entities
{
    [Table("Enriquecimento", Schema = "dbo")]
    public class Enriquecimento
    {
        [Key]
        public int IdEnriquecimento { get; set; }
        //public string IdObjeto { get; set; }
        public string Objeto { get; set; }
        public string Dados { get; set; }
        public string Pesquisa { get; set; }
        public string Dataset { get; set; }
        public int Visualizado { get; set; }
        [NotMapped]
        public bool ObjetoValido { get; set; }
        [NotMapped]
        public bool ObjetoExpirado { get; set; }
        public DateTime Criado { get; set; }
        public Nullable<DateTime> Expiracao { get; set; }
        public Nullable<DateTime> Modificado { get; set; }

    }
}
