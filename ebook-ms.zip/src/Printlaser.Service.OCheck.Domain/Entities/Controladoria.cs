﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Printlaser.Service.OCheck.Domain.Entities
{
    [Table("Controladoria", Schema = "dbo")]
    public class Controladoria
    {
        [Key]
        public int IdControladoria { get; set; }
        public string IdLogAcesso { get; set; }
        public int TotalEnvio { get; set; }
        public int TotalFila { get; set; }
        public int TotalReaproveitado { get; set; }
        //public string Controle { get; set; }
        public DateTime Criado { get; set; }
    }
}
