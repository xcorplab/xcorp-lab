﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Printlaser.Service.OCheck.Domain.Entities
{
    [Table("LogAcessoValidacao", Schema = "dbo")]
    public class LogAcessoValidacao
    {
        [Key]
        public int IdLogAcessoValidacao { get; set; }
        public string IdLogAcesso { get; set; }
        public string Objeto { get; set; }
        public string Pesquisa { get; set; }
        public string Dataset { get; set; }
        public DateTime Criacao { get; set; }
    }
}
