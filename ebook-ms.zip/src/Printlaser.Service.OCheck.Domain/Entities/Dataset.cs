﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Printlaser.Service.OCheck.Domain.Entities
{
    [Table("Dataset", Schema = "dbo")]
    public class Dataset
    {
        [Key]
        public int IdDataset { get; set; }
        public string DatasetName { get; set; }
        public string Descricao { get; set; }
        public int Tipo { get; set; }
        public string Pesquisa { get; set; }
        public string Fornecedor { get; set; }
        public bool Ativo { get; set; }
        public DateTime Criacao { get; set; }
    }
}
