﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Printlaser.Service.OCheck.Domain.Entities
{
    public class Objeto
    {
        public string Dado { get; set; }
        public string Pesquisa { get; set; }
        public string Datasets { get; set; }
    }
}
