﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Printlaser.Service.OCheck.Domain.Entities
{
    public class AdditionalValidationDetails
    {
        public string Account { get; set; }
        public string Domain { get; set; }
        public string Disposable { get; set; }
        public string RoleAddress { get; set; }
    }

    public class OnlineCertificate
    {
        public string Origin { get; set; }
        public string InputParameters { get; set; }
        public string NormalizedInputs { get; set; }
        public string ValidationType { get; set; }
        public string MainValidationStatus { get; set; }
        public AdditionalValidationDetails AdditionalValidationDetails { get; set; }
        public DateTime QueryDate { get; set; }
    }

    public class Result
    {
        public List<OnlineCertificate> OnlineCertificates { get; set; }
    }

    public class OndemandEmail
    {
        public int Code { get; set; }
        public string Message { get; set; }
    }

    public class Status
    {
        public List<OndemandEmail> ondemand_email { get; set; }
    }

    public class RootObject
    {
        public List<Result> Result { get; set; }
        public string QueryId { get; set; }
        public double ElapsedMilliseconds { get; set; }
        public Status Status { get; set; }
    }
}
