﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Printlaser.Service.OCheck.Domain.Entities
{
    [Table("LogAcesso", Schema = "dbo")]
    public class LogAcesso
    {
        [Key]
        public string IdLogAcesso { get; set; }
        public string Identificador { get; set; }
        public string ClienteId { get; set; }
        public int Tipo { get; set; }
        public string AppName { get; set; }
        public string IPAddress { get; set; }
        public string UserAgent { get; set; }
        public string EndPoint { get; set; }
        public string Referencia { get; set; }
        public string Situacao { get; set; }
        public DateTime Criado { get; set; }
        public DateTime Modificado { get; set; }
    }
}
