﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Printlaser.Service.OCheck.Domain.Entities
{
    [Table("AppClient", Schema = "dbo")]
    public class AppClient
    {
        [Key]
        public int IdAppClient { get; set; }
        public string Nome { get; set; }
        public string ReturnUrl { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string StatusRow { get; set; }
        public DateTime Modificado { get; set; }
        public int IdUserInsert { get; set; }
        public Nullable<int> IdUserUpdate { get; set; }
    }
}
