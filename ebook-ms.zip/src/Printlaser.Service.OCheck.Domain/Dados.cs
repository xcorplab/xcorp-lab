﻿using Printlaser.Service.OCheck.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Printlaser.Service.OCheck.Domain.Entities.RetornoBigDataCorpCompanies;

namespace Printlaser.Service.OCheck.Domain
{
    public class Dados
    {
        public object JsonConvert { get; private set; }

        public List<Validacao> AplicarRegraValidacaoObjeto(List<Validacao> resultDB, List<Objeto> entrada)
        {
            List<Validacao> objetos = new List<Validacao>();

            entrada.ForEach(e =>
            {
                var result = resultDB.Where(r => r.Objeto == e.Dado).ToList();

                Validacao objeto = new Validacao();

                if (result.Count() != 0)
                {
                    var date = result.FirstOrDefault().Expiracao;

                    if (date > DateTime.Now)
                    {
                        objeto.ObjetoValido = true;
                        objeto.ObjetoExpirado = false;
                    }
                    else
                    {
                        objeto.ObjetoValido = false;
                        objeto.ObjetoExpirado = true;
                    }

                    objeto.Criado = result.FirstOrDefault().Criado;
                    objeto.Expiracao = result.FirstOrDefault().Expiracao;
                    objeto.Modificado = result.FirstOrDefault().Modificado;
                    objeto.Situacao = objeto.ObjetoExpirado == true ? null : result.FirstOrDefault().Situacao;
                    objeto.Visualizado = result.FirstOrDefault().Visualizado++;
                    objeto.Objeto = result.FirstOrDefault().Objeto;
                    objeto.IdValidacao = result.FirstOrDefault().IdValidacao;
                    objeto.Pesquisa = result.FirstOrDefault().Pesquisa;
                    objeto.Dataset = result.FirstOrDefault().Dataset;
                }
                else
                {
                    objeto.ObjetoValido = false;
                    objeto.ObjetoExpirado = true;
                    objeto.Criado = DateTime.Now;
                    objeto.Expiracao = null;
                    objeto.Visualizado = 1;
                    objeto.Objeto = e.Dado;
                    objeto.Pesquisa = e.Pesquisa;
                    objeto.Dataset = string.IsNullOrEmpty(e.Datasets) ? "ondemand_email" : e.Datasets;
                }
                objetos.Add(objeto);
            });

            return objetos;
        }

        public List<Enriquecimento> AplicarRegraEnriquecimentoObjeto(List<Enriquecimento> resultDB, List<Objeto> entrada)
        {
            List<Enriquecimento> objetos = new List<Enriquecimento>();

            entrada.ForEach(e =>
            {
                var result = resultDB.Where(r => r.Objeto == e.Dado).ToList();

                Enriquecimento objeto = new Enriquecimento();

                if (result.Count() != 0)
                {
                    var date = Convert.ToDateTime(result.FirstOrDefault().Expiracao);

                    if (date > DateTime.Now)
                    {
                        objeto.ObjetoValido = true;
                        objeto.ObjetoExpirado = false;
                    }
                    else
                    {
                        objeto.ObjetoValido = false;
                        objeto.ObjetoExpirado = true;
                    }

                    objeto.Criado = result.FirstOrDefault().Criado;
                    objeto.Expiracao = result.FirstOrDefault().Expiracao;
                    objeto.Modificado = result.FirstOrDefault().Modificado;
                    objeto.Dados = result.FirstOrDefault().Dados;
                    objeto.Visualizado = result.FirstOrDefault().Visualizado++;
                    objeto.Objeto = result.FirstOrDefault().Objeto;
                    objeto.Pesquisa = result.FirstOrDefault().Pesquisa;

                    if (result.FirstOrDefault().Dataset != e.Datasets)
                    {
                        objeto.ObjetoValido = false;
                        objeto.ObjetoExpirado = true;
                    }
                    objeto.Dataset = string.IsNullOrEmpty(result.FirstOrDefault().Dataset) ? "basic_data,emails,phones,addresses" : result.FirstOrDefault().Dataset;
                }
                else
                {
                    objeto.ObjetoValido = false;
                    objeto.ObjetoExpirado = true;
                    objeto.Criado = DateTime.Now;
                    objeto.Expiracao = null;
                    objeto.Visualizado = 1;
                    objeto.Objeto = e.Dado;
                    objeto.Dataset = string.IsNullOrEmpty(e.Datasets) ? "basic_data,emails,phones,addresses" : e.Datasets;
                    objeto.Pesquisa = e.Pesquisa;
                }
                objetos.Add(objeto);
            });

            return objetos;
        }

        public string RetornaStatus(RetornoBigDataCorp retorno)
        {
            var result = retorno.Result.FirstOrDefault().Emails.ToList();

            if (result.Count == 0)
                return "NL";

            return result.FirstOrDefault().ValidationStatus;
            //return retorno.OperationResult.People.First().ExtraInformation.First(p => p.Name == "status").Value;
        }

        public string RetornaDados()
        {


            return "";
        }
    }
}
