﻿namespace Printlaser.Service.OCheck
{
    internal interface IIssuerSecurityTokenProvider
    {
    }
}