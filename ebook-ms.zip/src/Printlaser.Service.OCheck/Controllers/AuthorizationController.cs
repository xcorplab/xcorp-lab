﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Printlaser.Service.OCheck.Infra.DataBase.Context;
using Printlaser.Service.OCheck.ViewModel;

namespace Printlaser.Service.OCheck.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthorizationController : ControllerBase 
    {
        private readonly YodaDigitalContext _OYodaDigitalContext;

        public IConfiguration Configuration { get; }

        public AuthorizationController(YodaDigitalContext oYodaDigitalContext, IConfiguration configuration)
        {
            _OYodaDigitalContext = oYodaDigitalContext;
            Configuration = configuration;
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Post([FromBody] AuthorizationViewModel req)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var result = _OYodaDigitalContext.AppClients.Where(a => a.ClientId == req.ClientId && a.ClientSecret == req.ClientSecret).ToList();

                if (result.Count > 0)
                {
                    var claims = new[]
                    {
                        new Claim("Name", result.FirstOrDefault().Nome),
                        new Claim("ClientId", result.FirstOrDefault().ClientId)
                    };

                    //recebe uma instancia da classe SymmetricSecurityKey 
                    //armazenando a chave de criptografia usada na criação do token
                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["SecurityKey"]));

                    //recebe um objeto do tipo SigninCredentials contendo a chave de 
                    //criptografia e o algoritmo de segurança empregados na geração 
                    // de assinaturas digitais para tokens
                    var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                    var token = new JwtSecurityToken(
                         issuer: "login.printlaser.com",
                         audience: "login.printlaser.com",
                         claims: claims,
                         expires: DateTime.Now.AddHours(24),
                         signingCredentials: creds);

                    return Ok(new
                    {
                        token = new JwtSecurityTokenHandler().WriteToken(token)
                    });
                }
                return BadRequest("Credenciais inválidas...");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}