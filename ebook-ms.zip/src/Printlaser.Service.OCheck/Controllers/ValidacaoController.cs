﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Newtonsoft.Json;
using Printlaser.Service.OCheck.Domain;
using Printlaser.Service.OCheck.Domain.Entities;
using Printlaser.Service.OCheck.Infra.Cache;
using Printlaser.Service.OCheck.Infra.DataBase;
using Printlaser.Service.OCheck.Infra.DataBase.Context;
using Printlaser.Service.OCheck.Infra.Queue;
using Printlaser.Service.OCheck.ViewModel;

namespace Printlaser.Service.OCheck.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize()]
    public class ValidacaoController : ControllerBase
    {
        private readonly OCheckContext _OCheckContext;
        public IConfiguration Configuration { get; }
        Dados dados = new Dados();
        Fila fila = new Fila();
        Redis redis = new Redis();

        public ValidacaoController(OCheckContext oCheckContext, IConfiguration configuration)
        {
            _OCheckContext = oCheckContext;
            Configuration = configuration;
        }

        [HttpGet]
        [Route("GetDatasets")]
        public IActionResult GetDatasets()
        {
            try
            {
                var datasets = _OCheckContext.Datasets.Where(d => d.Tipo == 1 && d.Ativo == true).ToList();
                if (datasets.Count() == 0)
                    return BadRequest("Datasets não localizados.");

                _OCheckContext.Dispose();

                return Ok(datasets.Select(s => new
                {
                    Nome = s.DatasetName,
                    Descricao = s.Descricao,
                    Pesquisa = s.Pesquisa
                }).ToList());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetResult")]
        public async Task<IActionResult> GetResultAsync(string Rastreio)
        {
            try
            {
                var logAcessos = _OCheckContext.LogAcessos.Where(v => v.IdLogAcesso == Rastreio).ToList();
                CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=ocheck;AccountKey=0/Mf128DrE/iM38im8ZnOARTkNIlKTKw1WAcLEzMhtHRlHnjs4QYd1AzXVtN3owajJMOyAYTAtr/QoIeTEupjw==;EndpointSuffix=core.windows.net");
                CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

                CloudTable retornoTable = tableClient.GetTableReference("retorno");
                TableQuery<QueueRetornoViewModel> query = new TableQuery<QueueRetornoViewModel>().Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, Rastreio));

                TableContinuationToken token = null;
                List<DadosRetornoValidacao> retornos = new List<DadosRetornoValidacao>();
                do
                {
                    TableQuerySegment<QueueRetornoViewModel> resultSegment = await retornoTable.ExecuteQuerySegmentedAsync(query, token);

                    foreach (QueueRetornoViewModel entity in resultSegment.Results)
                    {
                        //var a = JsonConvert.DeserializeObject<RootObject>(entity.RetornoObjeto).Result.FirstOrDefault().OnlineCertificates.FirstOrDefault().MainValidationStatus;

                        retornos.Add(new DadosRetornoValidacao()
                        {
                            Dado = entity.Objeto,
                            //Retorno = entity.RetornoObjeto.Contains("\"ExecutionError\":true") ? entity.RetornoObjeto : JsonConvert.DeserializeObject<RootObject>(entity.RetornoObjeto).Result.FirstOrDefault().OnlineCertificates.FirstOrDefault().MainValidationStatus,
                            Retorno = entity.RetornoObjeto.Contains("UNEXPECTED ERROR") ? "VALID" : JsonConvert.DeserializeObject<RootObject>(entity.RetornoObjeto).Result.FirstOrDefault().OnlineCertificates.FirstOrDefault().MainValidationStatus,
                            Datasets = entity.Datasets,
                            Pesquisa = entity.Pesquisa
                        });
                    }

                    token = resultSegment.ContinuationToken;
                }
                while (token != null);

                return Ok(new RetornoValidacaoViewModel()
                {
                    Referencia = logAcessos.FirstOrDefault().Referencia,
                    Identificador = logAcessos.FirstOrDefault().Identificador,
                    Rastreio = Rastreio,
                    Objetos = retornos
                });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> PostAsync([FromBody] EntradaViewModel req)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);
                //_OCheckContext.SaveChanges();
                var acesso = _OCheckContext.LogAcessos.Where(w => w.Identificador == req.Identificador && w.Situacao == "VALD").ToList();

                if (acesso.Count() > 0)
                {
                    //var resultBatchId = _OCheckContext.Validacoes.Where(v => req.Objetos.Select(s => s.Dado).Contains(v.Objeto)).ToList();

                    //var validacoesBatchId = await BuscarCache(req);

                    //var objetosBatchId = dados.AplicarRegraValidacaoObjeto(validacoesBatchId, req.Objetos);

                    //return Ok(new RetornoValidacaoViewModel()
                    //{
                    //    Referencia = req.Referencia,
                    //    Identificador = req.Identificador,
                    //    Rastreio = acesso.FirstOrDefault().IdLogAcesso,
                    //    Objetos = objetosBatchId.Where(w => !string.IsNullOrEmpty(w.Situacao)).ToList().Select(s => new DadosRetornoValidacao()
                    //    {
                    //        Dado = s.Objeto,
                    //        Retorno = string.IsNullOrEmpty(s.Situacao) ? null : s.Situacao,
                    //        Datasets = s.Dataset,
                    //        Pesquisa = s.Pesquisa
                    //    }).ToList()
                    //});

                    return Ok(new RetornoValidacaoViewModel()
                    {
                        Referencia = req.Referencia,
                        Identificador = req.Identificador,
                        Rastreio = acesso.FirstOrDefault().IdLogAcesso,
                        Objetos = new List<DadosRetornoValidacao>()
                    });
                }

                var identity = User.Identity as ClaimsIdentity;

                if (req.Objetos.GroupBy(g => g.Dado).Count() != req.Objetos.Count)
                    return BadRequest("Objetos duplicados!");

                string BatchId = Guid.NewGuid().ToString();

                //var result = _OCheckContext.Validacoes.AsNoTracking().Where(v => req.Objetos.Select(s => s.Dado).Contains(v.Objeto)).ToList();

                var validacoes = new List<Validacao>();//await BuscarCache(req);

                var objetos = dados.AplicarRegraValidacaoObjeto(validacoes, req.Objetos);
                //var objetos = dados.AplicarRegraValidacaoObjeto(result, req.Objetos);

                dbConnection db = new dbConnection();

                //List<LogAcessoValidacao> logAcessoValidacoes = new List<LogAcessoValidacao>();
                //objetos.ForEach(o =>
                //{
                //    logAcessoValidacoes.Add(new LogAcessoValidacao()
                //    {
                //        Criacao = DateTime.Now,
                //        IdLogAcesso = BatchId,
                //        Dataset = o.Dataset,
                //        Pesquisa = o.Pesquisa,
                //        Objeto = o.Objeto
                //    });
                //});
                //bool insLogAcessoValidacao = await db.InserirLogAcessoValidacaoAsync(logAcessoValidacoes);

                bool insLogAcesso = await db.InserirLogAcessoAsync(new LogAcesso()
                {
                    AppName = "",//identity.Claims.FirstOrDefault(claim => claim.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value.ToString(),
                    ClienteId = identity.Claims.FirstOrDefault(claim => claim.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value.ToString(),
                    Criado = DateTime.Now,
                    Tipo = 1,
                    EndPoint = "",
                    IdLogAcesso = BatchId,
                    IPAddress = "",
                    Referencia = req.Referencia,
                    UserAgent = "",
                    Identificador = req.Identificador,
                    Situacao = "VALD",
                    Modificado = DateTime.Now
                });

                if (!insLogAcesso)
                    return BadRequest();
                //if (!insLogAcessoValidacao)
                //    return BadRequest();

                //Insere msg na fila
                var validacao = fila.ObterFila("validacao", Configuration.GetConnectionString("ConnectionQueue")).Result;
                int count = 0;

                foreach (var o in objetos.Where(o => o.ObjetoValido == false && o.ObjetoExpirado == true).ToList())
                {
                    fila.InserirMensagemAsync(validacao, JsonConvert.SerializeObject(new QueueViewModel()
                    {
                        BatchId = BatchId,
                        Objeto = o.Objeto,
                        Datasets = o.Dataset,
                        Pesquisa = o.Pesquisa,
                        Tentativas = 0
                    }));
                    count++;
                }

                bool insControladoria = await db.InserirControladoriaAsync(new Controladoria()
                {
                    Criado = DateTime.Now,
                    IdLogAcesso = BatchId,
                    TotalEnvio = req.Objetos.Count(),
                    TotalFila = count,
                    TotalReaproveitado = objetos.Where(o => o.ObjetoValido == true).Count()
                });

                //var retorno = fila.ObterFila("retorno", Configuration.GetConnectionString("ConnectionQueue")).Result;
                //fila.InserirMensagemAsync(retorno, JsonConvert.SerializeObject(new Requisicao()
                //{
                //    batchId = BatchId,
                //    tentativas = 0,
                //    totalObjetosEnviados = objetos.Where(o => o.ObjetoValido == false && o.ObjetoExpirado == true).ToList().Count(),
                //    totalObjetosProcessados = 0
                //}));

                if (!insControladoria)
                    return BadRequest();

                return Ok(new RetornoValidacaoViewModel()
                {
                    Referencia = req.Referencia,
                    Identificador = req.Identificador,
                    Rastreio = BatchId,
                    Objetos = objetos.Where(w => !string.IsNullOrEmpty(w.Situacao)).ToList().Select(s => new DadosRetornoValidacao()
                    {
                        Dado = s.Objeto,
                        Retorno = string.IsNullOrEmpty(s.Situacao) ? null : s.Situacao,
                        Datasets = s.Dataset,
                        Pesquisa = s.Pesquisa
                    }).ToList()
                });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //public async Task<List<Validacao>> BuscarCache(EntradaViewModel req)
        //{
        //    List<string> querys = new List<string>();

        //    req.Objetos.ForEach(o =>
        //    {
        //        querys.Add(string.Format("RowKey eq '{0}'", o.Dado));
        //    });

        //    CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=ocheck;AccountKey=0/Mf128DrE/iM38im8ZnOARTkNIlKTKw1WAcLEzMhtHRlHnjs4QYd1AzXVtN3owajJMOyAYTAtr/QoIeTEupjw==;EndpointSuffix=core.windows.net");
        //    CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

        //    CloudTable retornoTable = tableClient.GetTableReference("retorno");

        //    TableContinuationToken token = null;
        //    List<Validacao> validacoes = new List<Validacao>();

        //    var totExec = Math.Ceiling(Convert.ToDecimal(querys.Count) / Convert.ToDecimal(200));

        //    int executados = 0;

        //    for (int i = 0; i < totExec; i++)
        //    {
        //        var execution = querys.Skip(executados).Take(200);

        //        StringBuilder sb = new StringBuilder();

        //        int cont = 0;
        //        execution.ToList().ForEach(e =>
        //        {
        //            cont++;
        //            sb.Append(e);

        //            if (cont < execution.ToList().Count)
        //                sb.Append(" or ");
        //        });

        //        TableQuery<QueueRetornoViewModel> query = new TableQuery<QueueRetornoViewModel>().Where(sb.ToString());

        //        do
        //        {
        //            TableQuerySegment<QueueRetornoViewModel> resultSegment = await retornoTable.ExecuteQuerySegmentedAsync(query, token);

        //            foreach (QueueRetornoViewModel entity in resultSegment.Results)
        //            {
        //                var ret = JsonConvert.DeserializeObject<RootObject>(entity.RetornoObjeto).Result.FirstOrDefault().OnlineCertificates.FirstOrDefault().MainValidationStatus;

        //                validacoes.Add(new Validacao()
        //                {
        //                    Criado = entity.DataInicio,
        //                    Dataset = entity.Datasets,
        //                    Objeto = entity.Objeto,
        //                    Pesquisa = entity.Pesquisa,
        //                    Visualizado = 1,
        //                    ObjetoExpirado = false,
        //                    ObjetoValido = false,
        //                    Modificado = entity.DataRetorno,
        //                    Situacao = ret,
        //                    Expiracao = entity.DataInicio.AddDays(45)
        //                });
        //            }

        //            token = resultSegment.ContinuationToken;
        //        }
        //        while (token != null);
        //        executados += 200;
        //    }
        //    return validacoes;
        //}

    }
}