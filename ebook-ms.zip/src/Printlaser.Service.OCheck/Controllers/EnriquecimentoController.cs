﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Newtonsoft.Json;
using Printlaser.Service.OCheck.Domain;
using Printlaser.Service.OCheck.Domain.Entities;
using Printlaser.Service.OCheck.Domain.Entities.RetornoBigDataCorpCompanies;
using Printlaser.Service.OCheck.Infra.Cache;
using Printlaser.Service.OCheck.Infra.DataBase;
using Printlaser.Service.OCheck.Infra.DataBase.Context;
using Printlaser.Service.OCheck.Infra.Queue;
using Printlaser.Service.OCheck.ViewModel;
using StackExchange.Redis;

namespace Printlaser.Service.OCheck.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize()]
    public class EnriquecimentoController : ControllerBase
    {
        private readonly OCheckContext _OCheckContext;
        public IConfiguration Configuration { get; }
        Dados dados = new Dados();
        Fila fila = new Fila();
        Redis redis = new Redis();

        public EnriquecimentoController(OCheckContext oCheckContext, IConfiguration configuration)
        {
            _OCheckContext = oCheckContext;
            Configuration = configuration;
        }

        [HttpGet]
        [Route("GetDatasets")]
        public IActionResult GetDatasets()
        {
            try
            {
                var datasets = _OCheckContext.Datasets.Where(d => d.Tipo == 2 && d.Ativo == true).ToList();
                if (datasets.Count() == 0)
                    return BadRequest("Datasets não localizados.");

                return Ok(datasets.Select(s => new
                {
                    Nome = s.DatasetName,
                    Descricao = s.Descricao,
                    Pesquisa = s.Pesquisa
                }).ToList());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetResult")]
        public async Task<IActionResult> GetAsync(string Rastreio)
        {
            try
            {
                var logAcessos = _OCheckContext.LogAcessos.Where(v => v.IdLogAcesso == Rastreio).ToList();
                CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=ocheck;AccountKey=0/Mf128DrE/iM38im8ZnOARTkNIlKTKw1WAcLEzMhtHRlHnjs4QYd1AzXVtN3owajJMOyAYTAtr/QoIeTEupjw==;EndpointSuffix=core.windows.net");
                CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

                CloudTable retornoTable = tableClient.GetTableReference("retorno");

                TableQuery<QueueRetornoViewModel> query = new TableQuery<QueueRetornoViewModel>().Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, Rastreio));

                TableContinuationToken token = null;
                List<DadosRetornoEnriquecimento> retornos = new List<DadosRetornoEnriquecimento>();
                do
                {
                    TableQuerySegment<QueueRetornoViewModel> resultSegment = await retornoTable.ExecuteQuerySegmentedAsync(query, token);

                    foreach (QueueRetornoViewModel entity in resultSegment.Results)
                    {
                        retornos.Add(new DadosRetornoEnriquecimento()
                        {
                            Dado = entity.Objeto,
                            Retorno = JsonConvert.DeserializeObject<RetornoBigDataCorp>(entity.RetornoObjeto),
                            Datasets = entity.Datasets,
                            Pesquisa = entity.Pesquisa
                        });
                    }

                    token = resultSegment.ContinuationToken;
                }
                while (token != null);

                return Ok(new RetornoEnriquecimentoViewModel()
                {
                    Referencia = logAcessos.FirstOrDefault().Referencia,
                    Identificador = logAcessos.FirstOrDefault().Identificador,
                    Rastreio = Rastreio,
                    Objetos = retornos
                });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST: api/Objetos
        [HttpPost]
        public async Task<IActionResult> PostAsync([FromBody] EntradaViewModel req)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var acesso = _OCheckContext.LogAcessos.Where(w => w.Identificador == req.Identificador && w.Situacao == "VALD").ToList();

                if (acesso.Count() > 0)
                {
                    //var resultBatchId = _OCheckContext.Enriquecimentos.Where(e => req.Objetos.Select(s => s.Dado).Contains(e.Objeto) && req.Objetos.Select(s => s.Datasets).Contains(e.Dataset)).ToList();
                    //var resultBatchId = await BuscarCache(req);
                    //var objetosBatchId = dados.AplicarRegraEnriquecimentoObjeto(resultBatchId, req.Objetos);

                    return Ok(new RetornoEnriquecimentoViewModel
                    {
                        Identificador = acesso.FirstOrDefault().Identificador,
                        Rastreio = acesso.FirstOrDefault().IdLogAcesso,
                        Referencia = acesso.FirstOrDefault().Referencia,
                        Objetos = new List<DadosRetornoEnriquecimento>()
                        //Objetos = objetosBatchId.Where(w => !string.IsNullOrEmpty(w.Dados)).ToList().Select(s => new DadosRetornoEnriquecimento()
                        //{
                        //    Dado = s.Objeto,
                        //    Retorno = string.IsNullOrEmpty(s.Dados) ? null : JsonConvert.DeserializeObject<RetornoBigDataCorp>(s.Dados),
                        //    Datasets = s.Dataset,
                        //    Pesquisa = s.Pesquisa
                        //}).ToList()
                    });
                }

                var identity = User.Identity as ClaimsIdentity;

                string BatchId = Guid.NewGuid().ToString();

                //var result = _OCheckContext.Enriquecimentos.Where(e => req.Objetos.Select(s => s.Dado).Contains(e.Objeto) && req.Objetos.Select(s => s.Datasets).Contains(e.Dataset)).ToList();
                //var result = await BuscarCache(req);
                var result = new List<Enriquecimento>();

                var objetos = dados.AplicarRegraEnriquecimentoObjeto(result, req.Objetos);

                dbConnection db = new dbConnection();

                List<LogAcessoEnriquecimento> logAcessoEnriquecimentos = new List<LogAcessoEnriquecimento>();
                objetos.ForEach(o =>
                {
                    logAcessoEnriquecimentos.Add(new LogAcessoEnriquecimento()
                    {
                        Criacao = DateTime.Now,
                        IdLogAcesso = BatchId,
                        Dataset = o.Dataset,
                        Pesquisa = o.Pesquisa,
                        Objeto = o.Objeto
                    });
                });
                bool insLogAcessoEnriquecimento = await db.InserirLogAcessoEnriquecimentoAsync(logAcessoEnriquecimentos);

                bool insLogAcesso = await db.InserirLogAcessoAsync(new LogAcesso()
                {
                    AppName = "",//identity.Claims.FirstOrDefault(claim => claim.Type == "Name").Value.ToString(),
                    ClienteId = identity.Claims.FirstOrDefault(claim => claim.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value.ToString(),
                    Criado = DateTime.Now,
                    EndPoint = "",
                    IdLogAcesso = BatchId,
                    Tipo = 2,
                    IPAddress = "",
                    Referencia = req.Referencia,
                    UserAgent = "",
                    Identificador = req.Identificador,
                    Situacao = "VALD",
                    Modificado = DateTime.Now
                });

                if (!insLogAcesso)
                    return BadRequest();
                if (!insLogAcessoEnriquecimento)
                    return BadRequest();

                await _OCheckContext.SaveChangesAsync();

                //Insere msg na fila
                var enriquecimento = fila.ObterFila("enriquecimento", Configuration.GetConnectionString("ConnectionQueue")).Result;
                int count = 0;

                foreach (var o in objetos.Where(o => o.ObjetoValido == false && o.ObjetoExpirado == true).ToList())
                {
                    fila.InserirMensagemAsync(enriquecimento, JsonConvert.SerializeObject(new QueueViewModel()
                    {
                        BatchId = BatchId,
                        Objeto = o.Objeto,
                        Datasets = o.Dataset,
                        Pesquisa = o.Pesquisa,
                        Tentativas = 0
                    }));
                    count++;
                }
           
                bool insControladoria = await db.InserirControladoriaAsync(new Controladoria()
                {
                    Criado = DateTime.Now,
                    IdLogAcesso = BatchId,
                    TotalEnvio = req.Objetos.Count(),
                    TotalFila = count,
                    TotalReaproveitado = objetos.Where(o => o.ObjetoValido == true).Count()
                });

                if (!insControladoria)
                    return BadRequest();

                await _OCheckContext.SaveChangesAsync();

                //var retorno = fila.ObterFila("retorno", Configuration.GetConnectionString("ConnectionQueue")).Result;
                //fila.InserirMensagemAsync(retorno, JsonConvert.SerializeObject(new Requisicao()
                //{
                //    batchId = BatchId,
                //    tentativas = 0,
                //    totalObjetosEnviados = objetos.Where(o => o.ObjetoValido == false && o.ObjetoExpirado == true).ToList().Count(),
                //    totalObjetosProcessados = 0
                //}));

                return Ok(new RetornoEnriquecimentoViewModel()
                {
                    Referencia = req.Referencia,
                    Rastreio = BatchId,
                    Identificador = req.Identificador,
                    Objetos = objetos.Where(w => !string.IsNullOrEmpty(w.Dados)).ToList().Select(s => new DadosRetornoEnriquecimento()
                    {
                        Dado = s.Objeto,
                        Retorno = string.IsNullOrEmpty(s.Dados) ? null : JsonConvert.DeserializeObject<RetornoBigDataCorp>(s.Dados),
                        Datasets = s.Dataset,
                        Pesquisa = s.Pesquisa
                    }).ToList()
                });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("BuscarCache")]
        public async Task<List<Enriquecimento>> BuscarCache(EntradaViewModel req)
        {
            List<string> querys = new List<string>();

            req.Objetos.ForEach(o =>
            {
                querys.Add(string.Format("RowKey eq '{0}' and Datasets eq '{1}'", o.Dado, o.Datasets));
            });

            CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=ocheck;AccountKey=0/Mf128DrE/iM38im8ZnOARTkNIlKTKw1WAcLEzMhtHRlHnjs4QYd1AzXVtN3owajJMOyAYTAtr/QoIeTEupjw==;EndpointSuffix=core.windows.net");
            CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

            CloudTable retornoTable = tableClient.GetTableReference("retorno");

            TableContinuationToken token = null;
            List<Enriquecimento> validacoes = new List<Enriquecimento>();
            int totalPorPesquisa = 20;
            var totExec = Math.Ceiling(Convert.ToDecimal(querys.Count) / Convert.ToDecimal(totalPorPesquisa));

            int executados = 0;

            for (int i = 0; i < totExec; i++)
            {
                var execution = querys.Skip(executados).Take(totalPorPesquisa);

                StringBuilder sb = new StringBuilder();

                int cont = 0;
                execution.ToList().ForEach(e =>
                {
                    cont++;
                    sb.Append(e);

                    if (cont < execution.ToList().Count)
                        sb.Append(" or ");
                });

                TableQuery<QueueRetornoViewModel> query = new TableQuery<QueueRetornoViewModel>().Where(sb.ToString());

                do
                {
                    TableQuerySegment<QueueRetornoViewModel> resultSegment = await retornoTable.ExecuteQuerySegmentedAsync(query, token);

                    foreach (QueueRetornoViewModel entity in resultSegment.Results)
                    {
                        //var ret = JsonConvert.DeserializeObject<RetornoBigDataCorp>(entity.RetornoObjeto);

                        validacoes.Add(new Enriquecimento()
                        {
                            Criado = entity.DataInicio,
                            Dataset = entity.Datasets,
                            Objeto = entity.Objeto,
                            Pesquisa = entity.Pesquisa,
                            Visualizado = 1,
                            ObjetoExpirado = false,
                            ObjetoValido = false,
                            Modificado = entity.DataRetorno,
                            Dados = entity.RetornoObjeto,
                            Expiracao = entity.DataInicio.AddDays(30)
                        });
                    }

                    token = resultSegment.ContinuationToken;
                }
                while (token != null);
                executados += totalPorPesquisa;
            }
            return validacoes;
        }
    }
}