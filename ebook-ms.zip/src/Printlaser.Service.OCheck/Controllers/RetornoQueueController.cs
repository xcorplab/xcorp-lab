﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Printlaser.Service.OCheck.Domain;
using Printlaser.Service.OCheck.Domain.Entities;
using Printlaser.Service.OCheck.Domain.Entities.RetornoBigDataCorpCompanies;
using Printlaser.Service.OCheck.Infra.Cache;
using Printlaser.Service.OCheck.Infra.DataBase.Context;
using Printlaser.Service.OCheck.Infra.Queue;
using Printlaser.Service.OCheck.ViewModel;
using StackExchange.Redis;

namespace Printlaser.Service.OCheck.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class RetornoQueueController : ControllerBase
    {
        private readonly OCheckContext _OCheckContext;
        public IConfiguration Configuration { get; }

        Dados dados = new Dados();
        Redis redis = new Redis();

        public RetornoQueueController(OCheckContext oCheckContext, IConfiguration configuration)
        {
            _OCheckContext = oCheckContext;
            Configuration = configuration;
        }

        [HttpPost]
        public async Task<IActionResult> PostRetornoQueueAsync([FromBody] List<QueueRetornoViewModel> req)
        {
            try
            {
                List<Validacao> lstValidacao = new List<Validacao>();
                List<Enriquecimento> lstEnriquecimento = new List<Enriquecimento>();
                List<Retorno> lstRetorno = new List<Retorno>();
                req.ForEach(item =>
                {
                    switch (item.Tipo)
                    {
                        case 1://Validação
                            var validacao = _OCheckContext.Validacoes.Where(w => w.Objeto == item.Objeto).ToList();

                            if (validacao.Count() > 0)
                            {
                                var val = validacao.FirstOrDefault();
                                val.Expiracao = DateTime.Now.AddDays(30);
                                val.Modificado = DateTime.Now;
                                val.Situacao = JsonConvert.DeserializeObject<RetornoBigBoost>(item.RetornoObjeto).OperationResult.People.First().ExtraInformation.First(p => p.Name == "status").Value;
                                val.Dataset = item.Datasets;
                                val.Pesquisa = item.Pesquisa;
                                lstValidacao.Add(val);
                            }
                            else
                            {
                                lstValidacao.Add(new Validacao()
                                {
                                    Objeto = item.Objeto,
                                    Situacao = JsonConvert.DeserializeObject<RetornoBigBoost>(item.RetornoObjeto).OperationResult.People.First().ExtraInformation.First(p => p.Name == "status").Value,
                                    Visualizado = 1,
                                    Dataset = item.Datasets,
                                    Pesquisa = item.Pesquisa,
                                    Modificado = DateTime.Now,
                                    Expiracao = DateTime.Now.AddDays(30),
                                    Criado = DateTime.Now,
                                    IdValidacao = 0
                                });
                            }
                            break;
                        case 2://Enriquecimento
                            var enriquecimento = _OCheckContext.Enriquecimentos.Where(w => w.Objeto == item.Objeto).ToList();

                            if (enriquecimento.Count() > 0)
                            {
                                var enr = enriquecimento.FirstOrDefault();
                                enr.Expiracao = DateTime.Now.AddDays(30);
                                enr.Modificado = DateTime.Now;
                                enr.Dados = item.RetornoObjeto;
                                enr.Dataset = string.IsNullOrEmpty(item.Datasets) ? null : item.Datasets;
                                enr.Pesquisa = item.Pesquisa;
                                lstEnriquecimento.Add(enr);
                            }
                            else
                            {
                                lstEnriquecimento.Add(new Enriquecimento()
                                {
                                    Objeto = item.Objeto,
                                    Dados = item.RetornoObjeto,
                                    Visualizado = 2,
                                    Dataset = string.IsNullOrEmpty(item.Datasets) ? null : item.Datasets,
                                    Pesquisa = item.Pesquisa,
                                    Modificado = DateTime.Now,
                                    Expiracao = DateTime.Now.AddDays(30),
                                    Criado = DateTime.Now,
                                    IdEnriquecimento = 0
                                });
                            }
                            break;
                    }
                    var retorno = _OCheckContext.Retornos.Where(w => w.Objeto == item.Objeto).ToList();

                    TimeSpan ts = item.DataRetorno - item.DataInicio;

                    if (retorno.Count() > 0)
                    {
                        var ret = retorno.FirstOrDefault();
                        ret.RetornoObjeto = item.RetornoObjeto;
                        ret.Modificado = DateTime.Now;
                        ret.Datasets = item.Datasets;
                        ret.Pesquisa = item.Pesquisa;
                        ret.TempoRetorno = ts.TotalSeconds.ToString();
                        lstRetorno.Add(ret);
                    }
                    else
                    {
                        lstRetorno.Add(new Retorno()
                        {
                            Criado = DateTime.Now,
                            Modificado = DateTime.Now,
                            Objeto = item.Objeto,
                            Datasets = item.Datasets,
                            Pesquisa = item.Pesquisa,
                            RetornoObjeto = item.RetornoObjeto,
                            TempoRetorno = ts.TotalSeconds.ToString(),
                            Tipo = item.Tipo,
                            IdRetorno = 0
                        });
                    }
                });

                if (lstValidacao.Where(w => w.IdValidacao == 0).Count() > 0)
                    await _OCheckContext.Validacoes.AddRangeAsync(lstValidacao.Where(w => w.IdValidacao == 0).ToList());

                if (lstValidacao.Where(w => w.IdValidacao > 0).Count() > 0)
                    _OCheckContext.Validacoes.UpdateRange(lstValidacao.Where(w => w.IdValidacao > 0));

                if (lstEnriquecimento.Where(w => w.IdEnriquecimento == 0).Count() > 0)
                    await _OCheckContext.Enriquecimentos.AddRangeAsync(lstEnriquecimento.Where(w => w.IdEnriquecimento == 0));

                if (lstEnriquecimento.Where(w => w.IdEnriquecimento > 0).Count() > 0)
                    _OCheckContext.Enriquecimentos.UpdateRange(lstEnriquecimento.Where(w => w.IdEnriquecimento > 0));

                if (lstRetorno.Where(w => w.IdRetorno == 0).Count() > 0)
                    await _OCheckContext.Retornos.AddRangeAsync(lstRetorno.Where(w => w.IdRetorno == 0));

                if (lstRetorno.Where(w => w.IdRetorno > 0).Count() > 0)
                    _OCheckContext.Retornos.UpdateRange(lstRetorno.Where(w => w.IdRetorno > 0));

                await _OCheckContext.SaveChangesAsync();

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
    }
}