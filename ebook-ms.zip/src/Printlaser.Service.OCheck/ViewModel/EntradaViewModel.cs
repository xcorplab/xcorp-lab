﻿using Printlaser.Service.OCheck.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Printlaser.Service.OCheck.ViewModel
{
    public class EntradaViewModel
    {
        public string Referencia { get; set; }
        public string Identificador { get; set; }
        public string BatchId { get; set; }
        public List<Objeto> Objetos { get; set; }
    }
}
