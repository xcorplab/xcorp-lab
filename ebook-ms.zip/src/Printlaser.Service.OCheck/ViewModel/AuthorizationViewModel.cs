﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Printlaser.Service.OCheck.ViewModel
{
    public class AuthorizationViewModel
    {
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
    }
}
