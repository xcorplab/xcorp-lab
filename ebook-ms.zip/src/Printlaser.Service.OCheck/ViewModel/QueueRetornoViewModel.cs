﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Printlaser.Service.OCheck.ViewModel
{
    public class QueueRetornoViewModel : TableEntity
    {
        public string BatchId { get; set; }
        //public string IdObjeto { get; set; }
        public string Objeto { get; set; }
        public string Datasets { get; set; }
        public string Pesquisa { get; set; }
        public int Tipo { get; set; }
        public string RetornoObjeto { get; set; }
        public DateTime DataInicio { get; set; }
        public DateTime DataRetorno { get; set; }
        public DateTime DataExpiracaoCache { get; set; }
    }
}
