﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Printlaser.Service.OCheck.ViewModel
{
    public class AppClientViewModel
    {
        public int IdAppClient { get; set; }
        public string ClientId { get; set; }
        public string Secret { get; set; }
        public string IP { get; set; }
    }
}
