﻿using Printlaser.Service.OCheck.Domain.Entities.RetornoBigDataCorpCompanies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Printlaser.Service.OCheck.ViewModel
{
    public class RetornoValidacaoViewModel
    {
        public string Referencia { get; set; }
        public string Identificador { get; set; }
        public string Rastreio { get; set; }
        public List<DadosRetornoValidacao> Objetos { get; set; }
    }

    public class DadosRetornoValidacao
    {
        //public int IdValidacao { get; set; }
        //public string IdObjeto { get; set; }
        public string Dado { get; set; }
        public string Retorno { get; set; }
        public string Pesquisa { get; set; }
        public string Datasets { get; set; }
    }
}
