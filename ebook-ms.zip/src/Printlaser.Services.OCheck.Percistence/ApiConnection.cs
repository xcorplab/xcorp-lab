﻿using Newtonsoft.Json;
using Printlaser.Service.OCheck.Processing.ViewModel;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Printlaser.Service.OCheck.Processing
{
    public class ApiConnection
    {

        public async Task<IRestResponse> PesquisarValidacaoAsync(string objeto)
        {
            var client = new RestClient("https://upgrademe.bigdatacorp.com.br/upgrademe/api/singlesource?username=PRINTLASER_PROD&password=ddb9y66r&source=VerifyMe&searchkey=OP=EMAIL_VALIDATION|EMAIL=" + objeto);
            var request = new RestRequest(Method.GET);
            request.Timeout = 1000 * 60 * 10;

            return await client.ExecuteGetTaskAsync(request);
        }

        public async Task<IRestResponse> PesquisarEnriquecimentoAsync(QueueViewModel itemQueue)
        {
            string endPoint = string.Empty;

            if (itemQueue.Pesquisa.ToLower() == "cpf")
                endPoint = "https://bigboost.bigdatacorp.com.br/peoplev2";
            else if (itemQueue.Pesquisa.ToLower() == "cnpj")
                endPoint = "https://bigboost.bigdatacorp.com.br/companies";

            var client = new RestClient(endPoint);

            var request = new RestRequest(Method.POST);
            var body = JsonConvert.SerializeObject(new
            {
                Datasets = string.IsNullOrEmpty(itemQueue.Datasets) ? "basic_data,emails,phones,addresses" : itemQueue.Datasets.Trim(),
                q = String.Format("doc{0}{1}{2}", "{", itemQueue.Objeto.Replace(".", "").Replace("\\", "").Replace("/", "").Replace("-", "").Trim(), "}"),
                AccessToken = "7ab154c8-8fb3-46c5-a7f7-c93d7226519f"
            });

            request.AddHeader("Accept", "application/json");
            request.Parameters.Clear();
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            request.Timeout = 1000 * 60 * 10;

            var response = await client.ExecutePostTaskAsync(request);
            return response;
        }

        public async Task<IRestResponse> AtualizarObjetosAsync(QueueRetornoViewModel queueRetorno)
        {
            var client = new RestClient("https://pl-digital-api-ocheck.azurewebsites.net/api/RetornoQueue");

            var request = new RestRequest(Method.POST);
            var body = JsonConvert.SerializeObject(queueRetorno);

            request.AddHeader("Accept", "application/json");
            request.Parameters.Clear();
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            request.Timeout = 1000 * 60 * 10;

            var response = await client.ExecutePostTaskAsync(request);
            return response;
        }
    }
}
