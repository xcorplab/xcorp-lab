using System;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Newtonsoft.Json;
using Printlaser.Service.OCheck.Processing;
using Printlaser.Service.OCheck.Processing.ViewModel;
//using StackExchange.Redis;
using System.Linq;
using Microsoft.WindowsAzure.Storage.Table;
using Microsoft.WindowsAzure.Storage;

namespace Printlaser.Services.OCheck.Percistence
{
    public static class OCheckPercistenceCache
    {
        [FunctionName("OCheckPercistenceCache")]
        public static async Task RunAsync([QueueTrigger("retorno", Connection = "AzureWebJobsStorage")]QueueRetornoViewModel myQueueItem, TraceWriter log)
        {
            //log.Info($"C# Queue trigger function processed: {myQueueItem}");
            try
            {
                myQueueItem.PartitionKey = myQueueItem.BatchId;
                myQueueItem.Timestamp = DateTime.Now;
                myQueueItem.RowKey = DateTime.Now.AddHours(6).ToString("yyyy-MM-dd HH:mm:ss");
                myQueueItem.ETag = myQueueItem.Pesquisa;

                CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=ocheck;AccountKey=0/Mf128DrE/iM38im8ZnOARTkNIlKTKw1WAcLEzMhtHRlHnjs4QYd1AzXVtN3owajJMOyAYTAtr/QoIeTEupjw==;EndpointSuffix=core.windows.net");
                CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

                CloudTable retornoTable = tableClient.GetTableReference("retorno");
                await retornoTable.CreateIfNotExistsAsync();

                // Create the TableOperation that inserts the customer entity.
                TableOperation insertOperation = TableOperation.Insert(myQueueItem);

                // Execute the insert operation.
                await retornoTable.ExecuteAsync(insertOperation);
            }
            catch (Exception ex)
            {

            }
            //ApiConnection api = new ApiConnection();
            //var result = await api.AtualizarObjetosAsync(myQueueItem);
        }
    }
}