﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Text;

namespace Printlaser.Service.OCheck.Processing.ViewModel
{
    public class QueueRetornoViewModel : TableEntity
    {
        public string BatchId { get; set; }
        public string Objeto { get; set; }
        public string Pesquisa { get; set; }
        public string Datasets { get; set; }
        public int Tipo { get; set; }
        public string RetornoObjeto { get; set; }
        public DateTime DataRetorno { get; set; }
        public DateTime DataInicio { get; set; }
    }
}
