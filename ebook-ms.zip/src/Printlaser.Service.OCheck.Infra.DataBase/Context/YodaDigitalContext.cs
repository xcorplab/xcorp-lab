﻿using Microsoft.EntityFrameworkCore;
using Printlaser.Service.OCheck.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Printlaser.Service.OCheck.Infra.DataBase.Context
{
    public class YodaDigitalContext : DbContext
    {
        public YodaDigitalContext(DbContextOptions<YodaDigitalContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AppClient>().Property(t => t.IdAppClient).IsRequired();
        }

        public DbSet<AppClient> AppClients { get; set; }
    }
}
