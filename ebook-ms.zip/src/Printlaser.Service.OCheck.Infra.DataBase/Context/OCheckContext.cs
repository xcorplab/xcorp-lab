﻿using Microsoft.EntityFrameworkCore;
using Printlaser.Service.OCheck.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Printlaser.Service.OCheck.Infra.DataBase.Context
{
    public class OCheckContext : DbContext
    {
        public OCheckContext(DbContextOptions<OCheckContext> options) : base(options)
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<LogAcesso>().Property(t => t.IdLogAcesso).IsRequired();
            modelBuilder.Entity<Controladoria>().Property(t => t.IdControladoria).IsRequired();
            modelBuilder.Entity<Retorno>().Property(t => t.IdRetorno).IsRequired();
            //modelBuilder.Entity<Validacao>().Property(t => t.IdValidacao).IsRequired();
            modelBuilder.Entity<Enriquecimento>().Property(t => t.IdEnriquecimento).IsRequired();
            //modelBuilder.Entity<LogAcessoValidacao>().Property(t => t.IdLogAcessoValidacao).IsRequired();
            modelBuilder.Entity<LogAcessoEnriquecimento>().Property(t => t.IdLogAcessoEnriquecimento).IsRequired();
            modelBuilder.Entity<Dataset>().Property(t => t.IdDataset).IsRequired();
            modelBuilder.Entity<AppClient>().Property(t => t.IdAppClient).IsRequired();
        }

        public DbSet<LogAcesso> LogAcessos { get; set; }
        public DbSet<Retorno> Retornos { get; set; }
        public DbSet<Validacao> Validacoes { get; set; }
        public DbSet<Controladoria> Controladorias { get; set; }
        public DbSet<Enriquecimento> Enriquecimentos { get; set; }
        public DbSet<LogAcessoValidacao> LogAcessoValidacoes { get; set; }
        public DbSet<LogAcessoEnriquecimento> LogAcessoEnriquecimentos { get; set; }
        public DbSet<Dataset> Datasets { get; set; }
        
    }
    
}
