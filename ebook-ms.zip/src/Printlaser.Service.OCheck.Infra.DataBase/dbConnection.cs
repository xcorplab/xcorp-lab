﻿using Printlaser.Service.OCheck.Domain.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace Printlaser.Service.OCheck.Infra.DataBase
{
    public class dbConnection
    {
        string connectionString = "Server=tcp:pl-digital-oservices.database.windows.net,1433;Initial Catalog=OCheck;Persist Security Info=False;User ID=sysadmindigital;Password=84yR0PQa176z;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        public async Task<bool> InserirLogAcessoAsync(LogAcesso logAcesso)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                StringBuilder sbQuery = new StringBuilder();

                sbQuery.Append(" INSERT INTO [dbo].[LogAcesso] ([IdLogAcesso],[Identificador],[ClienteId],[Tipo],[AppName],[IPAddress],[UserAgent],[EndPoint],[Referencia],[Situacao],[Criado],[Modificado])");
                sbQuery.Append(string.Format(" VALUES ('{0}','{1}','{2}',{3},'{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}')",
                    logAcesso.IdLogAcesso,
                    logAcesso.Identificador,
                    logAcesso.ClienteId,
                    logAcesso.Tipo,
                    logAcesso.AppName,
                    logAcesso.IPAddress,
                    logAcesso.UserAgent,
                    logAcesso.EndPoint,
                    logAcesso.Referencia,
                    logAcesso.Situacao,
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")));

                SqlCommand command = new SqlCommand(sbQuery.ToString(), connection);

                connection.Open();
                try
                {
                    await command.ExecuteNonQueryAsync();
                }
                catch (Exception ex)
                {
                    return false;
                }
                return true;
            }
        }

        //public bool DeletarValidacao(List<Validacao> validacao)
        //{

        //    return true;
        //}

        public async Task<bool> InserirLogAcessoValidacaoAsync(List<LogAcessoValidacao> logAcessoValidacoes)
        {
            using (SqlConnection destinationConnection = new SqlConnection(connectionString))
            {
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(destinationConnection))
                {
                    destinationConnection.Open();
                    bulkCopy.DestinationTableName = "LogAcessoValidacao";
                    try
                    {
                        await bulkCopy.WriteToServerAsync(ToDataTable(logAcessoValidacoes));
                    }
                    catch (Exception)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        public async Task<bool> InserirLogAcessoEnriquecimentoAsync(List<LogAcessoEnriquecimento> logAcessoEnriquecimentos)
        {
            using (SqlConnection destinationConnection = new SqlConnection(connectionString))
            {
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(destinationConnection))
                {
                    destinationConnection.Open();
                    bulkCopy.DestinationTableName = "LogAcessoEnriquecimento";
                    try
                    {
                        await bulkCopy.WriteToServerAsync(ToDataTable(logAcessoEnriquecimentos));
                    }
                    catch (Exception)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        public async Task<bool> InserirControladoriaAsync(Controladoria controladoria)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                StringBuilder sbQuery = new StringBuilder();

                sbQuery.Append(" INSERT INTO [dbo].[Controladoria] ([IdLogAcesso],[TotalEnvio],[TotalFila],[TotalReaproveitado],[Criado])");
                sbQuery.Append(string.Format(" VALUES ('{0}','{1}','{2}','{3}','{4}')",
                    controladoria.IdLogAcesso,
                    controladoria.TotalEnvio,
                    controladoria.TotalFila,
                    controladoria.TotalReaproveitado,
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")));

                SqlCommand command = new SqlCommand(sbQuery.ToString(), connection);

                connection.Open();
                try
                {
                    await command.ExecuteNonQueryAsync();
                }
                catch (Exception)
                {
                    return false;
                }
                return true;
            }
        }

        public static DataTable ToDataTable<T>(IList<T> data)
        {
            try
            {
                PropertyDescriptorCollection props =
                    TypeDescriptor.GetProperties(typeof(T));
                DataTable table = new DataTable();
                for (int i = 0; i < props.Count; i++)
                {
                    PropertyDescriptor prop = props[i];
                    table.Columns.Add(prop.Name, prop.PropertyType);
                }
                object[] values = new object[props.Count];
                foreach (T item in data)
                {
                    for (int i = 0; i < values.Length; i++)
                    {
                        values[i] = props[i].GetValue(item);
                    }
                    table.Rows.Add(values);
                }
                return table;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
