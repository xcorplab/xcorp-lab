﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Printlaser.Service.OCheck.Infra.Queue
{
    public class Fila
    {
        public async Task<CloudQueue> ObterFila(string nome, string ConnectionQueue)
        {
            CloudStorageAccount _storageAccount =
            CloudStorageAccount.Parse(ConnectionQueue);

            var queueClient = _storageAccount.CreateCloudQueueClient();
            var queue = queueClient.GetQueueReference(nome);

            await queue.CreateIfNotExistsAsync();
            return queue;
        }

        public async void InserirMensagemAsync(CloudQueue queue, string mensagem)
        {
            try
            {
                var result = queue.AddMessageAsync(new CloudQueueMessage(mensagem));
                while (!result.IsCompleted)
                {
                    await result;
                }
            }
            catch (Exception)
            {
                var result = queue.AddMessageAsync(new CloudQueueMessage(mensagem));
                while (!result.IsCompleted)
                {
                    await result;
                }
            }
        }

        public async void ExcliurFilaAsync(CloudQueue queue)
        {
            await queue.DeleteAsync();
        }

        public async Task<List<CloudQueueMessage>> RecuperarMensagemAsync(CloudQueue queue, int total)
        {
            List<CloudQueueMessage> cloudQueueMessages = new List<CloudQueueMessage>();
            for (int i = 0; i < total; i++)
            {
                var result = await queue.GetMessageAsync();
                cloudQueueMessages.Add(result);
            }
           

            return cloudQueueMessages;
        }

        public async Task<int> ContabilizarMensagemAsync(CloudQueue queue)
        {
            await queue.FetchAttributesAsync();
            var result = queue.ApproximateMessageCount;
            return result.Value;
        }
    }
}
