using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Printlaser.Service.OCheck.Persistence.ViewModel;

namespace Printlaser.Service.OCheck.Persistence
{
    public static class OCheckPercistence
    {
        [FunctionName("OCheckPercistence")]
        public static void Run([QueueTrigger("validacao", Connection = "AzureWebJobsStorage")]QueueViewModel myQueueItem, TraceWriter log)
        {
            try
            {
                log.Info($"C# Queue trigger function processed: {myQueueItem}");


            }
            catch (Exception ex)
            {
                log.Info(ex.Message);
            }
        }
    }
}
