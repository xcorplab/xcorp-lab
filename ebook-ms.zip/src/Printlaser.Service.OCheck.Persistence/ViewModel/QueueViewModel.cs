﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Printlaser.Service.OCheck.Persistence.ViewModel
{
    public class QueueViewModel
    {
        public string BatchId { get; set; }
        //public string IdObjeto { get; set; }
        public string Objeto { get; set; }
    }
}
