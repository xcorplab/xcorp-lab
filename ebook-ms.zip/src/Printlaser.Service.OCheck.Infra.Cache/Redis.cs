﻿using ServiceStack.Redis;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Printlaser.Service.OCheck.Infra.Cache
{
    public class Redis
    {
        //public IRedisClientsManager RedisManager = new PooledRedisClientManager("ockeck.redis.cache.windows.net:6379");
        public Lazy<ConnectionMultiplexer> GetConnection()
        {
            var lazyConnection = new Lazy<ConnectionMultiplexer>(() =>
            {
                string cacheConnection = "ockeck.redis.cache.windows.net:6380,password=j4P7oyvjgBFF8G8aY0FqxyVREADYElV0NbESfhzXRM8=,ssl=True,abortConnect=False";
                var connection = ConnectionMultiplexer.Connect(cacheConnection);
                return connection;
            });
            return lazyConnection;
        }

        //public static Lazy<ConnectionMultiplexer> GetConnection = new Lazy<ConnectionMultiplexer>(() =>
        //{
        //    string cacheConnection = "ockeck.redis.cache.windows.net:6380,password=j4P7oyvjgBFF8G8aY0FqxyVREADYElV0NbESfhzXRM8=,ssl=True,abortConnect=False";
        //    return ConnectionMultiplexer.Connect(cacheConnection);
        //});

        //public static ConnectionMultiplexer Connection
        //{
        //    get
        //    {
        //        return GetConnection.Value;
        //    }
        //}

        //public ConnectionMultiplexer GetConnection()
        //{
        //    string cacheConnection = "ockeck.redis.cache.windows.net:6380,password=j4P7oyvjgBFF8G8aY0FqxyVREADYElV0NbESfhzXRM8=,ssl=True,abortConnect=False";


        //    return ConnectionMultiplexer.Connect(cacheConnection); ;
        //}

        public async Task SetMessageAsync(IDatabase cache, string Key, string Message)
        {
            await cache.StringSetAsync(Key, Message);
            await cache.KeyExpireAsync(Key, DateTime.Now.AddHours(12));
        }

        public async Task<RedisValue> GetMessageAsync(IDatabase cache, string Key)
        {
            return await cache.StringGetAsync(Key);
        }
    }
}
