using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Newtonsoft.Json;
using Printlaser.Service.OCheck.Domain.Entities.RetornoBigDataCorpCompanies;
using Printlaser.Service.OCheck.Infra.Queue;
using Printlaser.Service.OCheck.Processing.Entities;
using Printlaser.Service.OCheck.Processing.ViewModel;
using System.Linq;

namespace Printlaser.Service.OCheck.Processing
{
    public static class OCheckProcessingEnriquecimento
    {
        [FunctionName("OCheckProcessingEnriquecimento")]
        public static async Task RunAsync([QueueTrigger("enriquecimento", Connection = "AzureWebJobsStorage")]QueueViewModel myQueueItem, TraceWriter log)
        {
            //log.Info($"C# Queue trigger function processed: {myQueueItem}");
            try
            {
                ApiConnection api = new ApiConnection();
                var dataInicioProcessamento = DateTime.Now;
                var response = await api.PesquisarEnriquecimentoAsync(myQueueItem);

                Fila fila = new Fila();

                if (response.StatusCode != HttpStatusCode.OK && myQueueItem.Tentativas < 5)
                {
                    var enriquecimento = fila.ObterFila("enriquecimento", GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                    fila.InserirMensagemAsync(enriquecimento, JsonConvert.SerializeObject(new QueueViewModel()
                    {
                        BatchId = myQueueItem.BatchId,
                        Objeto = myQueueItem.Objeto,
                        Datasets = myQueueItem.Datasets,
                        Pesquisa = myQueueItem.Pesquisa,
                        Tentativas = myQueueItem.Tentativas + 1
                    }));
                }
                else if (response.StatusCode != HttpStatusCode.OK && myQueueItem.Tentativas >= 5)
                {
                    List<Monitoramento> monitoramentos = new List<Monitoramento>();
                    monitoramentos.Add(new Monitoramento()
                    {
                        dateRegister = DateTime.Now,
                        description = response.ErrorMessage,
                        functionName = "OCheckProcessingEnriquecimento",
                        batchId = myQueueItem.BatchId,
                        objeto = myQueueItem.Objeto,
                        statusID = 1,
                        systemID = 35
                    });

                    var filaMonitoramento = fila.ObterFila("monitoramento", GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                    fila.InserirMensagemAsync(filaMonitoramento, JsonConvert.SerializeObject(monitoramentos));
                }
                else
                {
                    var ret = JsonConvert.DeserializeObject<RetornoBigDataCorp>(response.Content);

                    if (ret.Result[0].Emails == null)
                        ret.Result[0].Emails = new List<Email>();

                    if (ret.Result[0].Phones == null)
                        ret.Result[0].Phones = new List<Phone>();

                    if (ret.Result[0].Addresses == null)
                        ret.Result[0].Addresses = new List<Address>();


                    var emails = ret.Result[0].Emails.Take(30).ToList();
                    ret.Result[0].Emails.Clear();
                    ret.Result[0].Emails.AddRange(emails);

                    var phones = ret.Result[0].Phones.Take(30).ToList();
                    ret.Result[0].Phones.Clear();
                    ret.Result[0].Phones.AddRange(phones);

                    var addresses = ret.Result[0].Addresses.Take(30).ToList();
                    ret.Result[0].Addresses.Clear();
                    ret.Result[0].Addresses.AddRange(addresses);

                    var retorno = new QueueRetornoViewModel()
                    {
                        PartitionKey = myQueueItem.BatchId,
                        Timestamp = DateTime.Now,
                        RowKey = myQueueItem.Objeto,
                        ETag = myQueueItem.Pesquisa,
                        BatchId = myQueueItem.BatchId,
                        Objeto = myQueueItem.Objeto,
                        RetornoObjeto = JsonConvert.SerializeObject(ret),
                        Datasets = myQueueItem.Datasets,
                        Pesquisa = myQueueItem.Pesquisa,
                        DataRetorno = DateTime.Now,
                        DataInicio = dataInicioProcessamento,
                        Tipo = 2
                    };

                    var retornoQueue = fila.ObterFila("retorno", GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                    //var retornoQueue = fila.ObterFila(myQueueItem.BatchId, GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                    fila.InserirMensagemAsync(retornoQueue, JsonConvert.SerializeObject(retorno));
                }
            }
            catch (Exception ex)
            {
                Fila fila = new Fila();
                if (myQueueItem.Tentativas < 5)
                {
                    var enriquecimento = fila.ObterFila("enriquecimento", GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                    fila.InserirMensagemAsync(enriquecimento, JsonConvert.SerializeObject(new QueueViewModel()
                    {
                        BatchId = myQueueItem.BatchId,
                        Objeto = myQueueItem.Objeto,
                        Datasets = myQueueItem.Datasets,
                        Pesquisa = myQueueItem.Pesquisa,
                        Tentativas = myQueueItem.Tentativas + 1
                    }));
                }
                else
                {
                    List<Monitoramento> monitoramentos = new List<Monitoramento>();
                    monitoramentos.Add(new Monitoramento()
                    {
                        dateRegister = DateTime.Now,
                        description = ex.Message,
                        functionName = "OCheckProcessingEnriquecimento",
                        batchId = myQueueItem.BatchId,
                        objeto = myQueueItem.Objeto,
                        statusID = 2,
                        systemID = 35
                    });

                    var filaMonitoramento = fila.ObterFila("monitoramento", GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                    fila.InserirMensagemAsync(filaMonitoramento, JsonConvert.SerializeObject(monitoramentos));
                }
            }
        }
        public static string GetEnvironmentVariable(string name)
        {
            return Environment.GetEnvironmentVariable(name, EnvironmentVariableTarget.Process);
        }
    }
}
