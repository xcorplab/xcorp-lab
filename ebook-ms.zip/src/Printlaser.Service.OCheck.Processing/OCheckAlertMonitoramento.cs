using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Printlaser.Service.OCheck.Infra.Queue;
using Printlaser.Service.OCheck.Processing.Entities;

namespace Printlaser.Service.OCheck.Processing
{
    public static class OCheckAlertMonitoramento
    {
        //[FunctionName("OCheckAlertMonitoramento")]
        public static async Task RunAsync([QueueTrigger("monitoramento", Connection = "AzureWebJobsStorage")]Monitoramento monitoramentos, ILogger log)
        {
            try
            {
                ApiConnection api = new ApiConnection();
                var result = await api.InserirMonitoramentoAsync(monitoramentos);

                if (result.StatusCode != HttpStatusCode.OK)
                {
                    Fila fila = new Fila();
                    var filaMonitoramento = fila.ObterFila("monitoramento", GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                    fila.InserirMensagemAsync(filaMonitoramento, JsonConvert.SerializeObject(monitoramentos));
                }
            }
            catch (Exception ex)
            {
                Fila fila = new Fila();
                var filaMonitoramento = fila.ObterFila("monitoramento", GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                fila.InserirMensagemAsync(filaMonitoramento, JsonConvert.SerializeObject(monitoramentos));
            }
        }
        public static string GetEnvironmentVariable(string name)
        {
            return Environment.GetEnvironmentVariable(name, EnvironmentVariableTarget.Process);
        }
    }
}
