using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host.Triggers;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Newtonsoft.Json;
using Printlaser.Service.OCheck.Domain.Entities;
using Printlaser.Service.OCheck.Infra.Queue;
using Printlaser.Service.OCheck.Processing.Entities;
using Printlaser.Service.OCheck.Processing.ViewModel;
using RestSharp;
using System.Threading;

namespace Printlaser.Service.OCheck.Processing
{
    public static class OCheckProcessingValidacao
    {
        [FunctionName("OCheckProcessingValidacao")]
        public static async Task RunAsync([QueueTrigger("validacao", Connection = "AzureWebJobsStorage")]QueueViewModel myQueueItem, TraceWriter log)
        {
            try
            {
                ApiConnection api = new ApiConnection();
                var dataInicioProcessamento = DateTime.Now;

                Fila fila = new Fila();

                //QueueRetornoViewModel validacaoCache = BuscarCache(myQueueItem.Objeto);

                //if (!string.IsNullOrEmpty(validacaoCache.Objeto))
                //{
                //    var retorno = new QueueRetornoViewModel()
                //    {
                //        PartitionKey = myQueueItem.BatchId,
                //        Timestamp = DateTime.Now,
                //        RowKey = myQueueItem.Objeto,
                //        ETag = myQueueItem.Pesquisa,
                //        BatchId = myQueueItem.BatchId,
                //        Objeto = myQueueItem.Objeto,
                //        RetornoObjeto = validacaoCache.RetornoObjeto,
                //        Datasets = myQueueItem.Datasets,
                //        Pesquisa = myQueueItem.Pesquisa,
                //        DataRetorno = DateTime.Now,
                //        DataInicio = validacaoCache.DataExpiracaoCache,
                //        Tipo = 1
                //    };

                //    var retornoQueue = fila.ObterFila(myQueueItem.BatchId, GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                //    fila.InserirMensagemAsync(retornoQueue, JsonConvert.SerializeObject(retorno));
                //}
                //else
                //{
                var response = await api.PesquisarValidacaoAsync(myQueueItem);

                if (response.StatusCode != HttpStatusCode.OK && myQueueItem.Tentativas < 5)
                {
                    var validacao = fila.ObterFila("validacao", GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                    fila.InserirMensagemAsync(validacao, JsonConvert.SerializeObject(new QueueViewModel()
                    {
                        BatchId = myQueueItem.BatchId,
                        Objeto = myQueueItem.Objeto,
                        Datasets = myQueueItem.Datasets,
                        Pesquisa = myQueueItem.Pesquisa,
                        Tentativas = myQueueItem.Tentativas + 1
                    }));
                }
                else if (response.StatusCode != HttpStatusCode.OK && myQueueItem.Tentativas >= 5)
                {
                    List<Monitoramento> monitoramentos = new List<Monitoramento>();
                    monitoramentos.Add(new Monitoramento()
                    {
                        dateRegister = DateTime.Now,
                        description = response.ErrorMessage,
                        functionName = "OCheckProcessingValidacao",
                        batchId = myQueueItem.BatchId,
                        objeto = myQueueItem.Objeto,
                        statusID = 1,
                        systemID = 35
                    });

                    var filaMonitoramento = fila.ObterFila("monitoramento", GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                    fila.InserirMensagemAsync(filaMonitoramento, JsonConvert.SerializeObject(monitoramentos));
                }
                else
                {
                    var retorno = new QueueRetornoViewModel()
                    {
                        PartitionKey = myQueueItem.BatchId,
                        Timestamp = DateTime.Now,
                        RowKey = myQueueItem.Objeto,
                        ETag = myQueueItem.Pesquisa,
                        BatchId = myQueueItem.BatchId,
                        Objeto = myQueueItem.Objeto,
                        RetornoObjeto = response.Content,
                        Datasets = myQueueItem.Datasets,
                        Pesquisa = myQueueItem.Pesquisa,
                        DataRetorno = DateTime.Now,
                        DataInicio = dataInicioProcessamento,
                        Tipo = 1
                    };

                    var retornoQueue = fila.ObterFila("retorno", GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                    fila.InserirMensagemAsync(retornoQueue, JsonConvert.SerializeObject(retorno));
                }
                //}
            }
            catch (Exception ex)
            {
                Fila fila = new Fila();
                if (myQueueItem.Tentativas < 5)
                {
                    var validacao = fila.ObterFila("validacao", GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                    fila.InserirMensagemAsync(validacao, JsonConvert.SerializeObject(new QueueViewModel()
                    {
                        BatchId = myQueueItem.BatchId,
                        Objeto = myQueueItem.Objeto,
                        Datasets = myQueueItem.Datasets,
                        Pesquisa = myQueueItem.Pesquisa,
                        Tentativas = myQueueItem.Tentativas + 1
                    }));
                }
                else
                {
                    List<Monitoramento> monitoramentos = new List<Monitoramento>();
                    monitoramentos.Add(new Monitoramento()
                    {
                        dateRegister = DateTime.Now,
                        description = ex.Message,
                        functionName = "OCheckProcessingValidacao",
                        batchId = myQueueItem.BatchId,
                        objeto = myQueueItem.Objeto,
                        statusID = 2,
                        systemID = 35
                    });

                    var filaMonitoramento = fila.ObterFila("monitoramento", GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                    fila.InserirMensagemAsync(filaMonitoramento, JsonConvert.SerializeObject(monitoramentos));
                }
            }
        }

        public static string GetEnvironmentVariable(string name)
        {
            return Environment.GetEnvironmentVariable(name, EnvironmentVariableTarget.Process);
        }

        public static QueueRetornoViewModel BuscarCache(string objeto)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=ocheck;AccountKey=0/Mf128DrE/iM38im8ZnOARTkNIlKTKw1WAcLEzMhtHRlHnjs4QYd1AzXVtN3owajJMOyAYTAtr/QoIeTEupjw==;EndpointSuffix=core.windows.net");
            CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

            CloudTable retornoTable = tableClient.GetTableReference("retorno");

            TableContinuationToken token = null;

            QueueRetornoViewModel validacaoResult = new QueueRetornoViewModel();

            TableQuery<QueueRetornoViewModel> query = new TableQuery<QueueRetornoViewModel>().Where(string.Format("RowKey eq '{0}'", objeto));

            do
            {
                TableQuerySegment<QueueRetornoViewModel> resultSegment = retornoTable.ExecuteQuerySegmentedAsync(query, token).Result;

                foreach (QueueRetornoViewModel entity in resultSegment.Results.Where(w => w.DataExpiracaoCache > DateTime.Now).ToList())
                {
                    var ret = JsonConvert.DeserializeObject<RootObject>(entity.RetornoObjeto).Result.FirstOrDefault().OnlineCertificates.FirstOrDefault().MainValidationStatus;

                    validacaoResult = new QueueRetornoViewModel()
                    {
                        RetornoObjeto = entity.RetornoObjeto,
                        DataExpiracaoCache = entity.DataExpiracaoCache
                    };
                }

                token = resultSegment.ContinuationToken;
            }
            while (token != null);

            return validacaoResult;
        }
    }
}
