﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Printlaser.Service.OCheck.Processing.ViewModel
{
    public class QueueViewModel
    {
        public string BatchId { get; set; }
        //public string IdObjeto { get; set; }
        public string Datasets { get; set; }
        public string Pesquisa { get; set; }
        public string Objeto { get; set; }
        public int Tentativas { get; set; }
    }
}
