using System;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Newtonsoft.Json;
using Printlaser.Service.OCheck.Processing;
using Printlaser.Service.OCheck.Processing.ViewModel;
//using StackExchange.Redis;
using System.Linq;
using Microsoft.WindowsAzure.Storage.Table;
using Microsoft.WindowsAzure.Storage;
using Printlaser.Service.OCheck.Infra.Queue;
using Printlaser.Service.OCheck.Processing.Entities;
using System.Collections.Generic;
using Printlaser.Service.OCheck.Domain.Entities;
using System.Threading;

namespace Printlaser.Services.OCheck.Percistence
{
    public static class OCheckPersistenceCache
    {
        [FunctionName("OCheckPersistenceCache")]
        public static async Task RunAsync([QueueTrigger("retorno", Connection = "AzureWebJobsStorage")]QueueRetornoViewModel myQueueItem, TraceWriter log)
        {
            //log.Info($"C# Queue trigger function processed: {myQueueItem}");
            try
            {
                Fila fila = new Fila();
                //var queueBatchId = await fila.ObterFila(myQueueItem.batchId, GetEnvironmentVariable("AzureWebJobsStorage"));

                //int totalFila = await fila.ContabilizarMensagemAsync(queueBatchId);

                //if (myQueueItem.totalObjetosEnviados <= totalFila)
                //{
                //var result = await fila.RecuperarMensagemAsync(queueBatchId, totalFila);

                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(GetEnvironmentVariable("AzureWebJobsStorage"));
                CloudTableClient tableClient = storageAccount.CreateCloudTableClient();
                CloudTable retornoTable = tableClient.GetTableReference("Retorno");

                //int count = 0;
                //int countTotal = 0;

                TableBatchOperation batchOperation = new TableBatchOperation();
                await retornoTable.CreateIfNotExistsAsync();
                //foreach (var r in result.ToList())
                //{
                var retorno = myQueueItem;
                retorno.PartitionKey = retorno.BatchId;
                retorno.Timestamp = DateTime.Now;
                retorno.RowKey = retorno.Objeto;
                retorno.ETag = retorno.Pesquisa;
                retorno.DataExpiracaoCache = DateTime.Now.AddDays(45);

                //await retornoTable.CreateIfNotExistsAsync();
                TableOperation insertOperation = TableOperation.InsertOrReplace(retorno);

                try
                {
                    var resultInsert = await retornoTable.ExecuteAsync(insertOperation);
                }
                catch (Exception ex)
                {
                    //continue;
                    throw new Exception(ex.Message);
                }
                //batchOperation.InsertOrReplace(retorno);
                //count++;
                //countTotal++;
                //if (batchOperation.Count() == 100 || result.ToList().Count == count || result.ToList().Count == countTotal)
                //{
                //    try
                //    {
                //        var resTable = await retornoTable.ExecuteBatchAsync(batchOperation);
                //        batchOperation = new TableBatchOperation();
                //        count = 0;
                //    }
                //    catch (Exception ex)
                //    {
                //        batchOperation = new TableBatchOperation();
                //        count = 0;
                //    }
                //}
                //}

                //Thread.Sleep(10000);

                //int totalTable = 0;
                //TableContinuationToken token = null;
                //TableQuery<QueueRetornoViewModel> queryPesquisa = new TableQuery<QueueRetornoViewModel>().Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, myQueueItem.batchId));

                //do
                //{
                //    TableQuerySegment<QueueRetornoViewModel> resultSegment = await retornoTable.ExecuteQuerySegmentedAsync(queryPesquisa, token);
                //    totalTable = totalTable + resultSegment.Count();
                //    token = resultSegment.ContinuationToken;
                //}
                //while (token != null);

                //fila.ExcliurFilaAsync(queueBatchId);

                //if (totalTable == myQueueItem.totalObjetosEnviados)
                //{
                //    fila.ExcliurFilaAsync(queueBatchId);
                //}
                //else
                //{
                //    Thread.Sleep(1000 * 60 * 3);
                //    result.ToList().ForEach(async r =>
                //    {
                //        var retorno = JsonConvert.DeserializeObject<QueueRetornoViewModel>(r.AsString);
                //        await retornoTable.ExecuteAsync(TableOperation.Delete(retorno));
                //    });
                //    var retornoQueue = await fila.ObterFila("retorno", GetEnvironmentVariable("AzureWebJobsStorage"));
                //    fila.InserirMensagemAsync(retornoQueue, JsonConvert.SerializeObject(new Requisicao()
                //    {
                //        batchId = myQueueItem.batchId,
                //        totalObjetosEnviados = myQueueItem.totalObjetosEnviados,
                //        tentativas = myQueueItem.tentativas + 1,
                //        totalObjetosProcessados = totalFila
                //    }));
                //}
                //}
                //else
                //{
                //    Thread.Sleep(1000 * 60 * 3);

                //    var retorno = await fila.ObterFila("retorno-poison", GetEnvironmentVariable("AzureWebJobsStorage"));
                //    fila.InserirMensagemAsync(retorno, JsonConvert.SerializeObject(new Requisicao()
                //    {
                //        batchId = myQueueItem.batchId,
                //        totalObjetosEnviados = myQueueItem.totalObjetosEnviados,
                //        tentativas = myQueueItem.tentativas + 1,
                //        totalObjetosProcessados = totalFila
                //    }));
                //}
            }
            catch (Exception ex)
            {
                //Thread.Sleep(1000 * 60 * 3);
                Fila fila = new Fila();

                var retorno = await fila.ObterFila("retorno", GetEnvironmentVariable("AzureWebJobsStorage"));
                fila.InserirMensagemAsync(retorno, JsonConvert.SerializeObject(myQueueItem));
            }
        }
        public static string GetEnvironmentVariable(string name)
        {
            return Environment.GetEnvironmentVariable(name, EnvironmentVariableTarget.Process);
        }
    }
}