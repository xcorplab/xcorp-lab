using System;
using System.Data.SqlClient;
using System.Text;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace Printlaser.Service.OCheck.Processing
{
    public static class OCheckProcessingExpirado
    {
        [FunctionName("OCheckProcessingExpirado")]
        public static void Run([TimerTrigger("0 */5 * * * *")]TimerInfo myTimer, ILogger log)
        {
            //log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");
            string connectionString = "Server=tcp:pl-digital-oservices.database.windows.net,1433;Initial Catalog=OCheck;Persist Security Info=False;User ID=sysadmindigital;Password=84yR0PQa176z;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                StringBuilder sbQuery = new StringBuilder();

                sbQuery.Append(" DELETE FROM [dbo].[Validacao] ");
                sbQuery.Append(" WHERE Expiracao < GETDATE() ");
                SqlCommand command = new SqlCommand(sbQuery.ToString(), connection);

                connection.Open();
                try
                {
                    command.ExecuteNonQuery();
                }
                catch (Exception)
                {
                    
                }
            }
        }
    }
}
