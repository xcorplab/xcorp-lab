using System;
using System.Collections.Generic;
using System.Net;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Printlaser.Service.OCheck.Processing.ViewModel;
using System.Linq;
using System.Data;
using System.ComponentModel;
using System.Data.SqlClient;
using Newtonsoft.Json;
using Printlaser.Service.OCheck.Domain.Entities;
using Printlaser.Service.OCheck.Infra.Queue;
using Printlaser.Service.OCheck.Processing.Entities;

namespace Printlaser.Service.OCheck.Processing
{
    public static class OCheckPersistenceDataBase
    {
        [FunctionName("OCheckPersistenceDataBase")]
        public static async System.Threading.Tasks.Task RunAsync([TimerTrigger("0 */5 * * * *")]TimerInfo myTimer, TraceWriter log)
        {
            try
            {
                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(GetEnvironmentVariable("AzureWebJobsStorage"));
                CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

                CloudTable retornoTable = tableClient.GetTableReference("Retorno");

                DateTime dtFiltro = DateTime.Now.AddDays(28);
                TableQuery<QueueRetornoViewModel> query = new TableQuery<QueueRetornoViewModel>().Where(TableQuery.GenerateFilterConditionForDate("DataExpiracaoCache", QueryComparisons.LessThan, dtFiltro));

                TableContinuationToken token = null;
                ApiConnection api = new ApiConnection();

                do
                {
                    var resultSegment = await retornoTable.ExecuteQuerySegmentedAsync(query, token);

                    if (resultSegment.Results.Count > 0)
                    {
                        //List<Validacao> lstValidacao = new List<Validacao>();
                        //List<Enriquecimento> lstEnriquecimento = new List<Enriquecimento>();
                        //List<Retorno> lstRetorno = new List<Retorno>();
                        //List<Monitoramento> monitoramentos = new List<Monitoramento>();

                        //resultSegment.Results.ForEach(r =>
                        //{
                        //    switch (r.Tipo)
                        //    {
                        //        case 1:
                        //            lstValidacao.Add(new Validacao()
                        //            {
                        //                Objeto = r.Objeto,
                        //                Situacao = r.RetornoObjeto.Contains("\"Message\":\"UNEXPECTED ERROR.") ? "" : JsonConvert.DeserializeObject<RootObject>(r.RetornoObjeto).Result.FirstOrDefault().OnlineCertificates.FirstOrDefault().MainValidationStatus,
                        //                Visualizado = 1,
                        //                Dataset = r.Datasets,
                        //                Pesquisa = r.Pesquisa,
                        //                Modificado = DateTime.Now,
                        //                Expiracao = DateTime.Now.AddDays(45),
                        //                Criado = DateTime.Now,
                        //                IdValidacao = 0
                        //            });
                        //            break;

                        //        case 2:
                        //            lstEnriquecimento.Add(new Enriquecimento()
                        //            {
                        //                Objeto = r.Objeto,
                        //                Dados = r.RetornoObjeto,
                        //                Visualizado = 1,
                        //                Dataset = string.IsNullOrEmpty(r.Datasets) ? null : r.Datasets,
                        //                Pesquisa = r.Pesquisa,
                        //                Modificado = DateTime.Now,
                        //                Expiracao = DateTime.Now.AddDays(45),
                        //                Criado = DateTime.Now
                        //            });
                        //            break;
                        //    }

                        //    TimeSpan ts = r.DataRetorno - r.DataInicio;
                        //    lstRetorno.Add(new Retorno()
                        //    {
                        //        Criado = DateTime.Now,
                        //        Modificado = DateTime.Now,
                        //        Objeto = r.Objeto,
                        //        Datasets = r.Datasets,
                        //        Pesquisa = r.Pesquisa,
                        //        RetornoObjeto = r.RetornoObjeto,
                        //        TempoRetorno = ts.TotalSeconds.ToString(),
                        //        Tipo = r.Tipo,
                        //        IdRetorno = 0
                        //    });

                        //    monitoramentos.Add(new Monitoramento
                        //    {
                        //        dateRegister = DateTime.Now,
                        //        description = "Documento processado com sucesso.",
                        //        functionName = "OCheckPercistenceDataBase",
                        //        batchId = r.BatchId,
                        //        objeto = r.Objeto,
                        //        statusID = 3,
                        //        systemID = 35
                        //    });

                        //});

                        //var a = lstValidacao.Where(w => w.Situacao == null);

                        //string csDestination = "Server=tcp:pl-digital-oservices.database.windows.net,1433;Initial Catalog=OCheck;Persist Security Info=False;User ID=sysadmindigital;Password=84yR0PQa176z;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

                        //using (SqlConnection destinationConnection = new SqlConnection(csDestination))
                        //{
                        //    destinationConnection.Open();
                        //    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(destinationConnection))
                        //    {
                        //        if (lstValidacao.Count > 0)
                        //        {
                        //            bulkCopy.DestinationTableName = "Validacao";
                        //            bulkCopy.WriteToServer(ToDataTable(lstValidacao));
                        //        }

                        //        if (lstEnriquecimento.Count > 0)
                        //        {
                        //            bulkCopy.DestinationTableName = "Enriquecimento";
                        //            bulkCopy.WriteToServer(ToDataTable(lstEnriquecimento));
                        //        }

                        //        if (lstRetorno.Count > 0)
                        //        {
                        //            bulkCopy.DestinationTableName = "Retorno";
                        //            bulkCopy.WriteToServer(ToDataTable(lstRetorno));
                        //        }
                        //    }
                        //    destinationConnection.Close();
                        //}

                        //await retornoTable.ExecuteBatchAsync(TableBatchOperation.Delete(resultSegment.Results));
                        try
                        {
                            //await retornoTable.ExecuteBatchAsync(TableBatchOperation.Delete());

                            resultSegment.Results.ForEach(async r =>
                            {
                                await retornoTable.ExecuteAsync(TableOperation.Delete(r));
                            });
                        }
                        catch (Exception ex)
                        {

                        }
                        //Fila fila = new Fila();
                        //foreach (var item in monitoramentos)
                        //{
                        //    var filaMonitoramento = fila.ObterFila("monitoramento", GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                        //    fila.InserirMensagemAsync(filaMonitoramento, JsonConvert.SerializeObject(item));
                        //}
                    }

                    token = resultSegment.ContinuationToken;
                }
                while (token != null);
            }
            catch (Exception ex)
            {
                Fila fila = new Fila();
                List<Monitoramento> lst = new List<Monitoramento>();
                lst.Add(new Monitoramento()
                {
                    dateRegister = DateTime.Now,
                    description = ex.Message,
                    functionName = "OCheckPercistenceDataBase",
                    batchId = "",
                    objeto = "Falha carga de objetos",
                    statusID = 1,
                    systemID = 35
                });

                var filaMonitoramento = fila.ObterFila("monitoramento", GetEnvironmentVariable("AzureWebJobsStorage")).Result;
                fila.InserirMensagemAsync(filaMonitoramento, JsonConvert.SerializeObject(lst));
            }
        }

        public static string GetEnvironmentVariable(string name)
        {
            return Environment.GetEnvironmentVariable(name, EnvironmentVariableTarget.Process);
        }

        public static DataTable ToDataTable<T>(IList<T> data)
        {
            try
            {
                PropertyDescriptorCollection props =
                    TypeDescriptor.GetProperties(typeof(T));
                DataTable table = new DataTable();
                for (int i = 0; i < props.Count; i++)
                {
                    PropertyDescriptor prop = props[i];
                    table.Columns.Add(prop.Name, prop.PropertyType);
                }
                object[] values = new object[props.Count];
                foreach (T item in data)
                {
                    for (int i = 0; i < values.Length; i++)
                    {
                        values[i] = props[i].GetValue(item);
                    }
                    table.Rows.Add(values);
                }
                return table;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
