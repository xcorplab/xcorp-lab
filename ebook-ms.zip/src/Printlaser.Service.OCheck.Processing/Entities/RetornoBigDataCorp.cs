﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Printlaser.Service.OCheck.Domain.Entities.RetornoBigDataCorpCompanies
{
    public class AlternativeIdNumbers
    {
        public string VoterId { get; set; }
        public string SocialSecurityNumber { get; set; }
    }

    public class Aliases
    {
        public string SocialName { get; set; }
    }

    public class TaxRegimes
    {
        public bool Simples { get; set; }
    }

    public class Activities
    {
        public bool IsMain { get; set; }
        public string Code { get; set; }
        public string Activity { get; set; }
    }

    public class BasicData
    {
        public string TaxIdNumber { get; set; }
        public string TaxIdCountry { get; set; }
        public AlternativeIdNumbers AlternativeIdNumbers { get; set; }
        public string Name { get; set; }
        public Aliases Aliases { get; set; }
        public string Gender { get; set; }
        public double NameUniquenessScore { get; set; }
        public DateTime BirthDate { get; set; }
        public int Age { get; set; }
        public string ZodiacSign { get; set; }
        public string ChineseSign { get; set; }
        public string BirthCountry { get; set; }
        public string BirthState { get; set; }
        public string MotherName { get; set; }
        public string FatherName { get; set; }
        public string TaxIdStatus { get; set; }
        public string TaxIdOrigin { get; set; }
        public bool HasObitIndication { get; set; }
        public string ObitIndicationOrigin { get; set; }
        public string ObitIndicationYear { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime LastUpdateDate { get; set; }
    }

    public class ActivityIndicators
    {
        public string EmployeesRange { get; set; }
        public string IncomeRange { get; set; }
        public bool HasActivity { get; set; }
        public int NumberOfBranches { get; set; }
    }

    public class Relationship
    {
        public string RelatedEntityTaxIdNumber { get; set; }
        public string RelatedEntityTaxIdType { get; set; }
        public string RelatedEntityTaxIdCountry { get; set; }
        public string RelatedEntityName { get; set; }
        public string RelationshipType { get; set; }
        public string RelationshipName { get; set; }
        public string RelationshipLevel { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime LastUpdateDate { get; set; }
    }

    public class Relationships
    {
        public IList<Relationship> Relationship { get; set; }
        public int TotalRelationships { get; set; }
        public int TotalOwners { get; set; }
        public int TotalEmployees { get; set; }
    }

    public class Address
    {
        public string Typology { get; set; }
        public string Title { get; set; }
        public string AddressMain { get; set; }
        public string Number { get; set; }
        public string Complement { get; set; }
        public string Neighborhood { get; set; }
        public string ZipCode { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string Type { get; set; }
        public string HouseholdCode { get; set; }
        public string BuildingCode { get; set; }
        public int HouseholdTotalPassages { get; set; }
        public int HouseholdBadPassages { get; set; }
        public int HouseholdCrawlingPassages { get; set; }
        public int HouseholdValidationPassages { get; set; }
        public int HouseholdQueryPassages { get; set; }
        public int HouseholdMonthAveragePassages { get; set; }
        public int BuildingTotalPassages { get; set; }
        public int BuildingBadPassages { get; set; }
        public int BuildingCrawlingPassages { get; set; }
        public int BuildingValidationPassages { get; set; }
        public int BuildingQueryPassages { get; set; }
        public int BuildingMonthAveragePassages { get; set; }
        public int BuildingNumberOfHouseholds { get; set; }
        public int Priority { get; set; }
        public bool IsMain { get; set; }
        public bool IsRecent { get; set; }
        public bool IsActive { get; set; }
        public bool IsRatified { get; set; }
        public DateTime FirstPassageDate { get; set; }
        public DateTime LastPassageDate { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public bool HasOptIn { get; set; }
        public AdditionalOutputData AdditionalOutputData { get; set; }
    }
    public class AdditionalOutputData
    {
        public string IbgeCode { get; set; }
    }

    public class Email
    {
        public string EmailAddress { get; set; }
        public string Type { get; set; }
        public int EmailTotalPassages { get; set; }
        public int EmailBadPassages { get; set; }
        public int EmailCrawlingPassages { get; set; }
        public int EmailValidationPassages { get; set; }
        public int EmailQueryPassages { get; set; }
        public int EmailMonthAveragePassages { get; set; }
        public int EmailNumberOfEntities { get; set; }
        public int Priority { get; set; }
        public bool IsMain { get; set; }
        public bool IsRecent { get; set; }
        public bool IsActive { get; set; }
        public string ValidationStatus { get; set; }
        public DateTime LastValidationDate { get; set; }
        public DateTime FirstPassageDate { get; set; }
        public DateTime LastPassageDate { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime LastUpdateDate { get; set; }
    }

    public class Phone
    {
        public string Number { get; set; }
        public string AreaCode { get; set; }
        public string CountryCode { get; set; }
        public string Complement { get; set; }
        public string Type { get; set; }
        public int PhoneTotalPassages { get; set; }
        public int PhoneBadPassages { get; set; }
        public int PhoneCrawlingPassages { get; set; }
        public int PhoneValidationPassages { get; set; }
        public int PhoneQueryPassages { get; set; }
        public int PhoneMonthAveragePassages { get; set; }
        public int Priority { get; set; }
        public bool IsMain { get; set; }
        public bool IsRecent { get; set; }
        public bool IsActive { get; set; }
        public bool IsInDoNotCallList { get; set; }
        public string CurrentCarrier { get; set; }
        public string PlanType { get; set; }
        public DateTime FirstPassageDate { get; set; }
        public DateTime LastPassageDate { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public List<object> PortabilityHistory { get; set; }
        public bool HasOptIn { get; set; }
    }
    public class OnlineAd
    {
        public string Phone { get; set; }
        public DateTime FirstAdDate { get; set; }
        public DateTime LastAdDate { get; set; }
        public int TotalAds { get; set; }
        public int ActiveAds { get; set; }
        public int AdsLast30Days { get; set; }
        public int AdsLast90Days { get; set; }
        public int AdsLast180Days { get; set; }
        public int AdsLast365Days { get; set; }
        public int AdsInMainAdPortal { get; set; }
        public int AdsInMainAdCategory { get; set; }
        public int AdMaxValue { get; set; }
        public int AdMinValue { get; set; }
        public double AdAvgValue { get; set; }
        public int LastAdValue { get; set; }
        public string MainAdPortal { get; set; }
        public string MainAdCategory { get; set; }
        public IList<string> AdPortals { get; set; }
        public IList<string> AdCategories { get; set; }
        public DateTime CreationDate { get; set; }
    }

    public class Result
    {
        public string MatchKeys { get; set; }
        public BasicData BasicData { get; set; }
        public ActivityIndicators ActivityIndicators { get; set; }
        public Relationships Relationships { get; set; }
        public List<Address> Addresses { get; set; }
        public List<Email> Emails { get; set; }
        public List<Phone> Phones { get; set; }
        public List<OnlineAd> OnlineAds { get; set; }
    }

    public class RetornoBigDataCorp
    {
        public IList<Result> Result { get; set; }
    }
}
