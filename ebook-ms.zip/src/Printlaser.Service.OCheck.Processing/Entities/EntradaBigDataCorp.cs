﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Printlaser.Service.OCheck.Domain.Entities
{
    public class EntradaBigDataCorp
    {
        public string Datasets { get; set; }
        public string q { get; set; }
        public string AccessToken { get; set; }
    }
}
