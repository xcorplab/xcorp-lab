﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Printlaser.Service.OCheck.Processing.Entities
{

    public class Monitoramento
    {
        public int statusID { get; set; }
        public string description { get; set; }
        public string objeto { get; set; }
        public string functionName { get; set; }
        public string batchId { get; set; }
        public int systemID { get; set; }
        public DateTime dateRegister { get; set; }
    }
}
