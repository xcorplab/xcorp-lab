﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Printlaser.Service.OCheck.Domain.Entities
{
    [Table("Retorno", Schema = "dbo")]
    public class Retorno
    {
        [Key]
        public int IdRetorno { get; set; }
        //public string IdLogAcesso { get; set; }
        public string Objeto { get; set; }
        public string RetornoObjeto { get; set; }
        public string Datasets { get; set; }
        public string Pesquisa { get; set; }
        public int Tipo { get; set; }
        public string TempoRetorno { get; set; }
        public DateTime Criado { get; set; }
        public DateTime Modificado { get; set; }
    }
}
