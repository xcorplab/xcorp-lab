﻿using Newtonsoft.Json;
using Printlaser.Service.OCheck.Processing.Entities;
using Printlaser.Service.OCheck.Processing.ViewModel;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;

namespace Printlaser.Service.OCheck.Processing
{
    public class ApiConnection
    {
        public async Task<IRestResponse> PesquisarValidacaoAsync(QueueViewModel itemQueue)
        {
            //var client = new RestClient("https://upgrademe.bigdatacorp.com.br/upgrademe/api/singlesource?username=PRINTLASER_PROD&password=ddb9y66r&source=VerifyMe&searchkey=OP=EMAIL_VALIDATION|EMAIL=" + objeto);
            //var request = new RestRequest(Method.GET);
            //request.Timeout = 1000 * 60 * 10;

            var client = new RestClient("https://bigboost.bigdatacorp.com.br/validations");

            var request = new RestRequest(Method.POST);
            var body = JsonConvert.SerializeObject(new
            {
                Datasets = itemQueue.Datasets.Trim(),
                q = String.Format("{0}{1}{2}{3}", itemQueue.Pesquisa, "{", itemQueue.Objeto.Trim(), "}"),
                AccessToken = "10016d6e-5bcf-4515-843e-b6c35ad1048e"
            });

            request.AddHeader("Accept", "application/json");
            request.Parameters.Clear();
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            request.Timeout = 1000 * 60 * 10;

            return await client.ExecutePostTaskAsync(request);
        }

        public async Task<IRestResponse> PesquisarEnriquecimentoAsync(QueueViewModel itemQueue)
        {
            string endPoint = string.Empty;

            if (itemQueue.Pesquisa.ToLower() == "cpf")
                endPoint = "https://bigboost.bigdatacorp.com.br/peoplev2";
            else if (itemQueue.Pesquisa.ToLower() == "cnpj")
                endPoint = "https://bigboost.bigdatacorp.com.br/companies";

            var client = new RestClient(endPoint);

            var request = new RestRequest(Method.POST);
            var body = JsonConvert.SerializeObject(new
            {
                Datasets = string.IsNullOrEmpty(itemQueue.Datasets) ? "basic_data,emails,phones,addresses" : itemQueue.Datasets.Trim(),
                q = String.Format("doc{0}{1}{2}", "{", itemQueue.Objeto.Replace(".", "").Replace("\\", "").Replace("/", "").Replace("-", "").Trim(), "}"),
                AccessToken = "7ab154c8-8fb3-46c5-a7f7-c93d7226519f"
            });

            request.AddHeader("Accept", "application/json");
            request.Parameters.Clear();
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            request.Timeout = 1000 * 60 * 10;

            var response = await client.ExecutePostTaskAsync(request);
            return response;
        }

        public async Task<IRestResponse> InserirMonitoramentoAsync(Monitoramento monitoramento)
        {
            var client = new RestClient("https://apigateway.printlaser.io/logs/?api_key=ls2zK0rPdC8la3HKYWSdySempZH4NEAgtyRSYlVr");
            var request = new RestRequest(Method.POST);

            monitoramento.description = String.Format("{0} -- {1} -- {2} -- {3}", monitoramento.batchId, monitoramento.objeto, monitoramento.functionName, monitoramento.description);

            var body = JsonConvert.SerializeObject(monitoramento);

            request.AddHeader("Accept", "application/json");
            request.AddHeader("api_key", "ls2zK0rPdC8la3HKYWSdySempZH4NEAgtyRSYlVr");
            request.Parameters.Clear();
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            request.Timeout = 1000 * 60 * 10;

            var response = await client.ExecutePostTaskAsync(request);
            return response;
        }
    }
}
